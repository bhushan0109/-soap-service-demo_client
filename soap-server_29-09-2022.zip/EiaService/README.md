# soap-service-demo
soap web-service-demo-spring boot server

date=18/09/2022

approach to devlop soap(simple object access protocol) ws\
1) contract fist
wsdl-> java
2) contract last
java-> wsdl(Web Services Description Language)

we are using contact first approch
we did not write WSDL in sprong boot 
we need to write xsd(XML Schema Definition) file
==============================================================================
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-web-services</artifactId>
</dependency>

<dependency>
		<groupId>wsdl4j</groupId>
		<artifactId>wsdl4j</artifactId>
</dependency>
=============================================================================
we need to write xsd(XML Schema Definition) file
src/main/resources
and create 
new-other-xml-xml schema file
and give the file name 
loaneligibility.xsd


it will auto generated
<?xml version="1.0" encoding="UTF-8"?>
<schema xmlns="http://www.w3.org/2001/XMLSchema"
	targetNamespace="http://www.example.org/NewXMLSchema"
	xmlns:tns="http://www.example.org/NewXMLSchema"
	elementFormDefault="qualified">
</schema>


write your input request object and output request object in xsd file

for generating bi9ndi9ng classes we need to add one plugin -xjc plugin

============================================================================================
	<plugin>
				<groupId>org.springframework.boot</groupId>
				<artifactId>spring-boot-maven-plugin</artifactId>
			</plugin>
			<plugin>
				<groupId>org.codehaus.mojo</groupId>
				<artifactId>jaxb2-maven-plugin</artifactId>
				<version>1.6</version>
				<executions>
					<execution>
						<id>xjc</id>
						<goals>
							<goal>xjc</goal>
						</goals>
					</execution>
				</executions>
				<configuration>
					<schemaDirectory>${project.basedir}/src/main/resources/</schemaDirectory>
					<outputDirectory>${project.basedir}/src/main/java</outputDirectory>
					<clearOutputDir>false</clearOutputDir>
				</configuration>
			</plugin>
===============================================================================

mavn clean and maven install
.setting folder delete if error
auto all java object will created after maven install

new create  endpoint packege and service and config
now write own implementaion
in service class
next service endpoint


now next final step config
we only writing xsd file now for generation wsdl file do some config
java base config file


then last run the project
and hit the url
check wsdl generated or not
http://localhost:8080/ws/loanEligibility.wsdl
url-servlet path-bean name .wsdl

now if ALL IS OK THEN  TEST SOAP UI tool for testing
copy the url
http://localhost:8080/ws/loanEligibility.wsdl
click on soap- give the any project name
and paste the url
![image](https://user-images.githubusercontent.com/75246941/190923037-514239dd-9bb7-4000-be23-07f6cd5d880b.png)


![image](https://user-images.githubusercontent.com/75246941/190922938-5122169c-cea8-4574-9162-bdfa696e7620.png)


https://base64.guru/converter/decode/file
https://base64.guru/converter/encode/file
http://localhost:8080/ws/getEIA.wsdl
http://localhost:8080/ws/addition.wsdl
http://localhost:8080/ws/loanEligibility.wsdl




  private <T> JAXBElement<T> createJaxbElement(T object, Class<T> clazz) {
    return new JAXBElement<>(new QName(clazz.getSimpleName()), clazz, object);
  }


http://localhost:8080/ws/getEIA.wsdl
http://172.19.83.45:8080/ws/getEIA.wsdl
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:get="http://www.nsdl.com/Eia/dto">
    <soapenv:Header>
        <SecuredWebServiceHeader>
         <UserID>iTrex</UserID>
         <Password>iTrex</Password>
	<AuthenticatedToken></AuthenticatedToken>  
	<BussinessPartnerId>iTrex</BussinessPartnerId> 
	<RequestReferenceNumber>9999999999</RequestReferenceNumber>   
	</SecuredWebServiceHeader>
   </soapenv:Header>
   <soapenv:Body>
      <get:EiaRequest>
         <get:soapEncodingString>UEsDBBQAAAAIAMuah00wkYB3qgMAAIANAAAHAAAAeG1sLnhtbO1XXZOaMBR970z/g+N7jYi6uzNp2oh1ZVRgUDvdvjCsZFdmIaEBO7W/vgki4UPbTqd9K0+555ybj8vNvQDffYujzlfC05DRt12t1+92CN2xIKTPb7vbzezNbfcdev0KEhN7eLfzpiTzwyiV0CyMiDcnfkB4aYYBGkJQDHOUsxjIwdTPiGc/efeEEu5nYjk06GsjTdP7ELRJ6WIdYgk2l9YguMIUK6s9OeJgjEpdoRFgRzzQDMB5KMjCP0dyTExqiC09M36Uy1VMpdkcE2I/CUoqlKHmSBKLoWG/PxyOB7p2J6aRiBKYND1wn+6IZ8QJPXpGgDQRizZcupRBdMmOhEnWjKBizocDtdOd9xWFO59m1ZDkjMXkDCUvz9WAlLaEOpYfk7fdNYuIiD5Ps47DWcJSwru5utDnlCe1aIInHyBQQFW2CoMgIjkMqvjSP4vXfuxDUNq1NfxsT7g3P6SPPg3ak4jsknmxguA0qnJTe4K0u1tNPAMIhFUlHWwhvMbOQru5GywgEHaV3prT2jo4CDhJ0yIyIgdjnxKaneOhVMuQEg1Zpos/4s1862AXrxxzCcGZu+gxQAt7iS2z43TsUjq4KNXRxw/WPV4ubdstpXpdupSxWvn8BdRxI8yOaDO3p1tn+3mOIZBAXbLORNYhXQQsHzX82YFm/CjrQTGs845peQYLCBrfjsb9WwgKoPZKQRHL6+E1GBdWwsQLFXfmf4z/TowNFscHGu7yWlwvFOfyRyKS7BkVl/UQPxLeOBmOMu8XkhV7LAg0uhmPtf7gZjyCQMF1+Qx/akzg8DD2+dEjsdwdJXv/RX9P0yDq7VgvpBDUBK39EU5FQE8kqAXkyunP9IVyOPHpi1crtAo/1Sl9DEFpVSV2XrRKCtTcZSPYo/vOfce18VTMkAOFRKXQwjbm5il7mqvLBilTowz1UB/pw9FIF5O16avessHJhtACWx4r03DzHAMtypytjVP6mZPFsi8fTaRunasdTvbBKCKBZ+zJlwNBRwgamNIXE7Wb+SHbMx5+Fx4uSUSmi1os3uxXcqU/rbfuA/7jBnWh44BGowGN3gL+YjNZzx7czcPmf3n7t+WtUqTufqN2uSTKl0r3YYJuIKja15VeXhp+WvSsD3O8eG+tp8ueYfdMq1Hzfr+qtYIyi/xn9KC8FFq5cL++WkV5a69mTj3xocieZFEpx+28L4hR+RrbyvoXgNdy/BnfuJlqS8pQp20cpdEMFCHhS38eAm7+sfwAUEsBAj8AFAAAAAgAy5qHTTCRgHeqAwAAgA0AAAcAJAAAAAAAAAAgAAAAAAAAAHhtbC54bWwKACAAAAAAAAEAGACy48YSNI7UAcLxZVYzjtQBwvFlVjOO1AFQSwUGAAAAAAEAAQBZAAAAzwMAAAAA</get:soapEncodingString>
      </get:EiaRequest>
   </soapenv:Body>
</soapenv:Envelope>