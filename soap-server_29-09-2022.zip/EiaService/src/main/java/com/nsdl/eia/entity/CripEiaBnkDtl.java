package com.nsdl.eia.entity;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the CRIP_EIA_BNK_DTLS database table.
 */
@Entity
@Table(name = "NIR.CRIP_EIA_BNK_DTLS")
public class CripEiaBnkDtl implements Serializable, Auditable {
	private static final long serialVersionUID = 1L;

	public String[] getId() {
		String[] id = new String[1];
		id[0] = "CEBD_EIA_ACCT_ID:" + cebdEiaAcctId;
		return id;
	}

	@Id
	@Column(name = "CEBD_EIA_ACCT_ID")
	private String cebdEiaAcctId;

	@Column(name = "CEBD_BNK_ACCT_NO")
	private String cebdBnkAcctNo;

	@Column(name = "CEBD_BNK_ACCT_TYPE")
	private String cebdBnkAcctType;

	@Column(name = "CEBD_BNK_BLK_TLUK_SUB_DIV_TWN")
	private String cebdBnkBlkTlukSubDivTwn;

	@Column(name = "cebd_city")
	private String cebdCity;

	@Column(name = "CEBD_BNK_NAME")
	private String cebdBnkName;

	@Column(name = "CEBD_BNK_PIN_CD")
	private String cebdBnkPinCd;

	@Column(name = "cebd_branch_nm")
	private String cebdBranchNm;

	@Column(name = "CEBD_BNK_RD_STREET_LN")
	private String cebdBnkRdStreetLn;

	@Column(name = "CEBD_BNK_VILL_AR_LOCLTY")
	private String cebdBnkVillArLoclty;

	@Column(name = "CEBD_CRT_BY")
	private String cebdCrtBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEBD_CRT_DATE")
	private Calendar cebdCrtDate;

	@Column(name = "CEBD_IFSC_CD")
	private String cebdIfscCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEBD_LST_UPD_TMSTMP")
	private Calendar cebdLstUpdTmstmp;

	@Column(name = "CEBD_MICR_CD")
	private String cebdMicrCd;

	@Column(name = "CEBD_MODF_BY")
	private String cebdModfBy;

	@Column(name = "cebd_cancelled_cheque")
	private String cebdCancelledCheque;

	@Column(name = "CEBD_TRANSACTION_ID")
	private Long cebdTxId;

	@Column(name = "CEBD_IPADDRESS")
	private String cebdIpaddress;

	@Column(name = "CEBD_FILEID")
	private String cebdFileid;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEBD_MODF_DATE")
	private Calendar cebdModfDate;

	@OneToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "CEBD_EIA_ACCT_ID", referencedColumnName = "CEA_EIA_ACCT_ID", insertable = false, updatable = false) })
	private CripEiaAcct cripEiaAcct;

	public CripEiaBnkDtl() {
		super();
	}

	public String getCebdEiaAcctId() {
		return this.cebdEiaAcctId;
	}

	public void setCebdEiaAcctId(String cebdEiaAcctId) {
		this.cebdEiaAcctId = cebdEiaAcctId;
	}

	public String getCebdBnkAcctNo() {
		return this.cebdBnkAcctNo;
	}

	public void setCebdBnkAcctNo(String cebdBnkAcctNo) {
		this.cebdBnkAcctNo = cebdBnkAcctNo;
	}

	public String getCebdBnkAcctType() {
		return this.cebdBnkAcctType;
	}

	public void setCebdBnkAcctType(String cebdBnkAcctType) {
		this.cebdBnkAcctType = cebdBnkAcctType;
	}

	public String getCebdBnkBlkTlukSubDivTwn() {
		return this.cebdBnkBlkTlukSubDivTwn;
	}

	public void setCebdBnkBlkTlukSubDivTwn(String cebdBnkBlkTlukSubDivTwn) {
		this.cebdBnkBlkTlukSubDivTwn = cebdBnkBlkTlukSubDivTwn;
	}

	public String getCebdBnkName() {
		return this.cebdBnkName;
	}

	public void setCebdBnkName(String cebdBnkName) {
		this.cebdBnkName = cebdBnkName;
	}

	public String getCebdBnkPinCd() {
		return this.cebdBnkPinCd;
	}

	public void setCebdBnkPinCd(String cebdBnkPinCd) {
		this.cebdBnkPinCd = cebdBnkPinCd;
	}

	public String getCebdBnkRdStreetLn() {
		return this.cebdBnkRdStreetLn;
	}

	public void setCebdBnkRdStreetLn(String cebdBnkRdStreetLn) {
		this.cebdBnkRdStreetLn = cebdBnkRdStreetLn;
	}

	public String getCebdBnkVillArLoclty() {
		return this.cebdBnkVillArLoclty;
	}

	public void setCebdBnkVillArLoclty(String cebdBnkVillArLoclty) {
		this.cebdBnkVillArLoclty = cebdBnkVillArLoclty;
	}

	public String getCebdCrtBy() {
		return this.cebdCrtBy;
	}

	public void setCebdCrtBy(String cebdCrtBy) {
		this.cebdCrtBy = cebdCrtBy;
	}

	public Calendar getCebdCrtDate() {
		return this.cebdCrtDate;
	}

	public void setCebdCrtDate(Calendar cebdCrtDate) {
		this.cebdCrtDate = cebdCrtDate;
	}

	public String getCebdIfscCd() {
		return this.cebdIfscCd;
	}

	public void setCebdIfscCd(String cebdIfscCd) {
		this.cebdIfscCd = cebdIfscCd;
	}

	public Calendar getCebdLstUpdTmstmp() {
		return this.cebdLstUpdTmstmp;
	}

	public void setCebdLstUpdTmstmp(Calendar cebdLstUpdTmstmp) {
		this.cebdLstUpdTmstmp = cebdLstUpdTmstmp;
	}

	public String getCebdMicrCd() {
		return this.cebdMicrCd;
	}

	public void setCebdMicrCd(String cebdMicrCd) {
		this.cebdMicrCd = cebdMicrCd;
	}

	public String getCebdModfBy() {
		return this.cebdModfBy;
	}

	public void setCebdModfBy(String cebdModfBy) {
		this.cebdModfBy = cebdModfBy;
	}

	public Calendar getCebdModfDate() {
		return this.cebdModfDate;
	}

	public void setCebdModfDate(Calendar cebdModfDate) {
		this.cebdModfDate = cebdModfDate;
	}

	public void setCripEiaAcct(CripEiaAcct cripEiaAcct) {
		this.cripEiaAcct = cripEiaAcct;
	}

	public CripEiaAcct getCripEiaAcct() {
		return cripEiaAcct;
	}

	public void setCebdCity(String cebdCity) {
		this.cebdCity = cebdCity;
	}

	public String getCebdCity() {
		return cebdCity;
	}

	public void setCebdBranchNm(String cebdBranchNm) {
		this.cebdBranchNm = cebdBranchNm;
	}

	public String getCebdBranchNm() {
		return cebdBranchNm;
	}

	public String getCebdCancelledCheque() {
		return cebdCancelledCheque;
	}

	public void setCebdCancelledCheque(String cebdCancelledCheque) {
		this.cebdCancelledCheque = cebdCancelledCheque;
	}

	public void setCebdTxId(Long cebdTxId) {
		this.cebdTxId = cebdTxId;
	}

	public Long getCebdTxId() {
		return cebdTxId;
	}

	public String getCebdIpaddress() {
		return cebdIpaddress;
	}

	public void setCebdIpaddress(String cebdIpaddress) {
		this.cebdIpaddress = cebdIpaddress;
	}

	public String getCebdFileid() {
		return cebdFileid;
	}

	public void setCebdFileid(String cebdFileid) {
		this.cebdFileid = cebdFileid;
	}
}