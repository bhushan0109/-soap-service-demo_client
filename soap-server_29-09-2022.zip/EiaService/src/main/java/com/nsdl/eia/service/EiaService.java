package com.nsdl.eia.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.persistence.EntityNotFoundException;
import javax.persistence.NoResultException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.StringBuilders;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.context.MessageContext;

import com.nsdl.eia.SoapDemoApplication;
import com.nsdl.eia.api.add.AddRequest;
import com.nsdl.eia.api.add.Result;
import com.nsdl.eia.api.loaneligibility.Acknowledgement;
import com.nsdl.eia.api.loaneligibility.CustomerRequest;
import com.nsdl.eia.constants.NIRConstants;
import com.nsdl.eia.dto.EIAAccDetails;
import com.nsdl.eia.dto.EiaRequest;
import com.nsdl.eia.eiaxml.dto.SecuredWebServiceHeader;
import com.nsdl.eia.entity.CripEiaAcct;
import com.nsdl.eia.entity.CripEiaBnkDtl;
import com.nsdl.eia.entity.CripEiaPrpAthrpAddr;
import com.nsdl.eia.entity.CripEiaPrpsrAthrp;
import com.nsdl.eia.entity.CripUsrMstr;
import com.nsdl.eia.entity.NirPartnerTxnEiaCreation;
import com.nsdl.eia.otherentity.CripSeqGnrtr;
import com.nsdl.eia.otherentity.NirPartnerMstr;
import com.nsdl.eia.repository.CripSeqGnrtrRepository;
import com.nsdl.eia.repository.CripSysParamRepository;
import com.nsdl.eia.repository.CripUsrMstrRepo;
import com.nsdl.eia.repository.NirPartnerMstrRepository;
import com.nsdl.eia.repository.NirPartnerTxnEiaCreationRepository;
import com.nsdl.eia.utility.Encryption;
import com.nsdl.eia.utility.PopCommonUtility;
import com.nsdl.eia.xmBean.AccountOpeningFormBean;
import com.nsdl.eia.xmBean.FileBean;
//import com.nsdl.eia.xmBean.MainClass;
import com.nsdl.eia.xmBean.NJEiaService;
import com.nsdl.eia.xmBean.ProposalDetailBean;

@Service
public class EiaService {

	@Value("${file.path.eia.zip}")
	private String filePath;

	@Autowired
	NirPartnerMstrRepository nirPartnerMstrRepo;

	@Autowired
	NirPartnerTxnEiaCreationRepository nirPartnerTxnEiaCreationRepo;

	@Autowired
	CripSeqGnrtrRepository cripSeqGnrtrRepo;

	@Autowired
	CripSysParamRepository cripSysParamRepo;

	// @Autowired
	// SessionFactory SESSIONFACTORY;
	@Autowired
	CripUsrMstrRepo cripUsrMstrRepo;

	private static Logger LOGGER = LogManager.getLogger(EiaService.class);

	public EIAAccDetails getEia(EiaRequest request, SecuredWebServiceHeader securedWebServiceHeader)
			throws Exception {

		// pending header value validation

		EIAAccDetails eIAAccDetails = new EIAAccDetails();
		String soapEncodingString = request.getSoapEncodingString();

		// encoded string converted to decoded and extract zip (.xml file)
		byte[] zipData = Base64.decodeBase64(soapEncodingString);
//		String value = extractZipEntries(zipData);
		//System.out.println("Output : " + value);
		
		String value = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
				"<eIA_Acc_Details>\n" + 
				"<File_Header>\n" + 
				"<File_id>4</File_id>\n" + 
				"<From/>\n" + 
				"<Date_Of_Generation>20220928</Date_Of_Generation>\n" + 
				"<Num_Of_eIA_Acc_Details>1</Num_Of_eIA_Acc_Details></File_Header>\n" + 
				"<Person_eIA_Detail>\n" + 
				"    <Id/>\n" + 
				"    <eIADetails>\n" + 
				"      <AccCategory>1</AccCategory>\n" + 
				"      <TypeOfAcc>1</TypeOfAcc>\n" + 
				"      <AppNo>4004462319</AppNo>\n" + 
				"      <Insurance_Cmpny_Cd>10</Insurance_Cmpny_Cd>\n" + 
				"      <Date_Of_Receipt>20151130</Date_Of_Receipt>\n" + 
				"    </eIADetails>\n" + 
				"    <Applicant_Detail>\n" + 
				"      <No_Of_Applicant>1</No_Of_Applicant>\n" + 
				"      <Applicant Name=\"Sole/First Proposer\">\n" + 
				"        <First_Name>bhushan</First_Name>\n" + 
				"        <Middle_Name/>\n" + 
				"        <Last_Name>patil</Last_Name>\n" + 
				"        <Father_Husband_Name/>\n" + 
				"        <Gender>M</Gender>\n" + 
				"        <DOB>19811112</DOB>\n" + 
				"        <PAN>BMAPP5916R</PAN>\n" + 
				"        <UID/>\n" + 
				"        <Address Name=\"Permanent\">\n" + 
				"          <AddLine1>NIRAVATHUPARAMPIL</AddLine1>\n" + 
				"          <AddLine2>KOLANI P O</AddLine2>\n" + 
				"          <AddLine3>VENGALLOOR</AddLine3>\n" + 
				"          <Land_Mark/>\n" + 
				"          <City>THODUPUZHA</City>\n" + 
				"          <State>32</State>\n" + 
				"          <Country>4</Country>\n" + 
				"          <PIN_Code>425401</PIN_Code>\n" + 
				"        </Address>\n" + 
				"        <Address Name=\"Correspondence\">\n" + 
				"          <AddLine1>NIRAVATHUPARAMPIL</AddLine1>\n" + 
				"          <AddLine2>KOLANI P O</AddLine2>\n" + 
				"          <AddLine3>VENGALLOOR</AddLine3>\n" + 
				"          <Land_Mark/>\n" + 
				"          <City>THODUPUZHA</City>\n" + 
				"          <State>32</State>\n" + 
				"          <Country>4</Country>\n" + 
				"          <PIN_Code>425402</PIN_Code>\n" + 
				"        </Address>\n" + 
				"        <Communication_Detail>\n" + 
				"          <Telephone_Number/>\n" + 
				"          <Alt_Telephone_Number/>\n" + 
				"          <Mob_Number>8975891291</Mob_Number>\n" + 
				"          <FAX/>\n" + 
				"          <Primary_email>bhupatil0001@gmail.com</Primary_email>\n" + 
				"          <Alternate_email/>\n" + 
				"        </Communication_Detail>\n" + 
				"      </Applicant>\n" + 
				"      <Bank_Details>\n" + 
				"        <Bank_Name>36</Bank_Name>\n" + 
				"        <Other_Bank_Name/>\n" + 
				"        <Branch>G G ROAD</Branch>\n" + 
				"        <City>KOCHI</City>\n" + 
				"        <Bank_Account_Number>543534553</Bank_Account_Number>\n" + 
				"        <Bank_Account_Type>1</Bank_Account_Type>\n" + 
				"        <Bank_MICR_Code/>\n" + 
				"        <Bank_IFSC_Code>IBKL0000014</Bank_IFSC_Code>\n" + 
				"        <Cancelled_Cheque>y</Cancelled_Cheque>\n" + 
				"      </Bank_Details>\n" + 
				"      <Authorized_Representative>\n" + 
				"        <First_Name>SURYA</First_Name>\n" + 
				"        <Middle_Name/>\n" + 
				"        <Last_Name/>\n" + 
				"        <Gender/>\n" + 
				"        <DOB/>\n" + 
				"        <PAN/>\n" + 
				"        <UID/>\n" + 
				"        <Address Name=\"Permanent\">\n" + 
				"          <AddLine1>SFYRTYT</AddLine1>\n" + 
				"          <AddLine2>KOLANI P O</AddLine2>\n" + 
				"          <AddLine3>VENGALLOOR</AddLine3>\n" + 
				"          <Land_Mark/>\n" + 
				"          <City>THODUPUZHA</City>\n" + 
				"          <State>32</State>\n" + 
				"          <Country>4</Country>\n" + 
				"          <PIN_Code>425403</PIN_Code>\n" + 
				"        </Address>\n" + 
				"        <Communication_Detail>\n" + 
				"          <Telephone_Number/>\n" + 
				"          <Mob_Number>8975891291</Mob_Number>\n" + 
				"          <Relationship>7</Relationship>\n" + 
				"          <Relationship_Other/>\n" + 
				"          <Primary_email>bhupatil0001@gmail.com</Primary_email>\n" + 
				"        </Communication_Detail>\n" + 
				"        <Communication_Flag>Y</Communication_Flag>\n" + 
				"      </Authorized_Representative>\n" + 
				"      <Other_Detail>\n" + 
				"        <ID_Proof>1</ID_Proof>\n" + 
				"        <Address_Proof>5</Address_Proof>\n" + 
				"        <Correspondence_Address_Proof>5</Correspondence_Address_Proof>\n" + 
				"        <DOB_Proof>1</DOB_Proof>\n" + 
				"      </Other_Detail>\n" + 
				"    </Applicant_Detail>\n" + 
				"  </Person_eIA_Detail>\n" + 
				" </eIA_Acc_Details>";
		String requestxml= value;
		String uid = securedWebServiceHeader.getUserID();
		String pwd = securedWebServiceHeader.getPassword();
		String bussinessPartnerId = securedWebServiceHeader.getBussinessPartnerId();
		String requestReferenceNumber = securedWebServiceHeader.getRequestReferenceNumber();

		//String apiname = "http://localhost:8080/NIR/onlineEiaAccountOpeningByPartnerNJ.html";
		String apiname = "http://localhost:8080/NIR/onlineEiaAccountOpeningByPartnerITrex.html";
			
		String url = apiname + "?requestxml=" + requestxml + "&uid=" + uid + "&pwd=" + pwd + "&bussinessPartnerId="
				+ bussinessPartnerId + "&requestReferenceNumber=" + requestReferenceNumber;

		try {

			RestTemplate restTemplate = new RestTemplate();

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add(HttpHeaders.AUTHORIZATION, "urAccessToken");

			HttpEntity httpEntity = new HttpEntity(httpHeaders);

//			ResponseEntity<String> commonResponse = restTemplate.exchange(url, HttpMethod.POST, httpEntity,
//					String.class);
//
//			String body = commonResponse.getBody();
//			System.out.println("commonResponse.getBody();"+commonResponse.getBody());
			
			   JAXBContext jc = JAXBContext.newInstance(EIAAccDetails.class);

		        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" + 
		        		"<EIA_Acc_Details>\n" + 
		        		"    <Response_TimeStamp>29/09/2022 06:46:30</Response_TimeStamp>\n" + 
		        		"    <STATUS>E</STATUS>\n" + 
		        		"    <EIA_NO></EIA_NO>\n" + 
		        		"    <ERROR_DESC>eIA Account 1000000057451 is Already Present With PAN BMAPP5916R</ERROR_DESC>\n" + 
		        		"</EIA_Acc_Details>";
		        System.out.println(xml);
		        StringReader reader = new StringReader(xml);

		        Unmarshaller unmarshaller = jc.createUnmarshaller();
		        Object result = unmarshaller.unmarshal(reader);

		        if(result instanceof EIAAccDetails) {
		        	 eIAAccDetails = (EIAAccDetails) result;
		            System.out.println("data"+eIAAccDetails);
		            return eIAAccDetails;
		        }
			
			
			
			// logger.info("updateStage << commonResponse : " + commonResponse);
			// response = CommonUtil.parseDto(commonResponse.getBody(), UserDTO.class);
			// logger.info("response : " + response);
		} catch (Exception e) {
			throw e;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
		String dateString = sdf.format(new Date());

		if (value != null) {
			eIAAccDetails.setEIANO("1111111111 ");
			eIAAccDetails.setERRORDESC("");
			eIAAccDetails.setSTATUS("S");
			eIAAccDetails.setResponseTimeStamp(dateString);
		} else {
			eIAAccDetails.setEIANO("");
			eIAAccDetails.setERRORDESC("code:400 , unsuccesfull");
			eIAAccDetails.setSTATUS("E");
			eIAAccDetails.setResponseTimeStamp(dateString);
		}
		return eIAAccDetails;
	}

	public String extractZipEntries(byte[] bytes) throws IOException {

		// String absolutePath = "";
		ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(bytes));
		ZipEntry entry = null;
		StringBuilder builder = new StringBuilder();
		while ((entry = zipStream.getNextEntry()) != null) {
			// Date date = new Date();
			// SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy");
			// String strDate = formatter.format(date);
			// String entryName = entry.getName();
			byte[] byteBuff = new byte[9096];
			int bytesRead = 0;
			String s3 = "";
			while ((bytesRead = zipStream.read(byteBuff)) != -1) {
				s3 = new String(byteBuff, 0, bytesRead);
				builder.append(s3);
			}
			zipStream.closeEntry();
		}
		zipStream.close();
		return builder.toString();
	}
	// public String extractZipEntries(byte[] bytes) throws IOException {
	//
	// String absolutePath = "";
	// ZipInputStream zipStream = new ZipInputStream(new
	// ByteArrayInputStream(bytes));
	// ZipEntry entry = null;
	// while ((entry = zipStream.getNextEntry()) != null) {
	// Date date = new Date();
	// SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy");
	// String strDate = formatter.format(date);
	// String entryName = entry.getName();
	//
	// File file = new File(filePath + strDate + "/" + System.currentTimeMillis() +
	// entryName); // //server path
	// // File file = new File("/eIAxmlsFiles/"+strDate+"/" +
	// // System.currentTimeMillis()+entryName); // local host path
	// // Will create parent directories if not exists
	// absolutePath = file.getAbsolutePath();
	// boolean bool = file.getParentFile().mkdirs();
	// if (bool) {
	// file.createNewFile();
	//
	// } else {
	// file.createNewFile();
	// }
	// FileOutputStream out = new FileOutputStream(file, false);
	//
	// byte[] byteBuff = new byte[9096];
	//
	// int bytesRead = 0;
	//
	// while ((bytesRead = zipStream.read(byteBuff)) != -1) {
	// out.write(byteBuff, 0, bytesRead);
	// }
	// out.close();
	// zipStream.closeEntry();
	// }
	// zipStream.close();
	// return "Successfull, \n your xml file absolutePath is ======> " +
	// absolutePath;
	// }
}
// public static void main(String[] args) throws IOException {
// /// old String soapEncodingString =
// "UEsDBBQAAAAIAHVxM1UwkYB3sQMAAIANAAAHAAAAeG1sLnhtbO1XXW+jOBR9X2n/A8r7xiEkaSu5nnFI06AkgEgymu4LosFtUMFmDRlN9tevTRLAgbSjVR+HJ99zjj/u5fpegF9+JrH2g/AsYvS+o3d7HY3QLQsj+nrf2aynf912vqA//4DEwj7ebv0JyYMoziQ0jWLiz0gQEl6aUYgGEJyHEuUsAXIwCXLiOy/+I6GEB3nEKOr39KGuGz0IWkgxxd4nErzcWofgCgPBxZlc4Rijhe6oEaAmHmiF4DwUZOWUVjxQLGqKI70yfpDb1c1Ssz6kxHkRlFRURrVGmtoMDXq9wWDUN/Q7CI5IKbBotucB3RLfTFJ68M0Q6SIWLXA55Rwnj2xJlOYtETwzJ+dAwzt5rjjaBjRXQyIYm8kVSl76dQmV2hLS7CAh950Vi4mIPs9yzeUsZRnhnVKtabCgfKlFYzx+gKAG1GTLKAxjUsCgji+Cs3gVJAEElV3fI8h3hPuzffYc0LC5iMgumRdLCE6jGjdxxki/u9XF04dAWjXSxTbCK+zO9Zu7/hwCadfojTVR9sFhyEmWyciIyIgcTAJKaF6Px1G1iCjRkW15+BtezzYu9vDStRYQlFzbjD6aOwtsW5qrOaW03yo10LcH+xEvFo7jlVJDlS5krJYBfwMqbkb5Aa1nzmTjbv6eYQgKQJGscpF1yBABO47U+WxPc36Q9eA8VHjXsn2ThQSNboej3i0EJVALJTjF8np4TcaFlTLxQsWd+R3jz4mxyZJkT6NtUYsvC0WhWJOYpDtGxWXdJ8+EX3iG49z/QLJkzycCDW9GI73XvxkNIajBinyKv18s4PIoCfjBJ4k8HSW74M34SrMw7m5ZN6IQqILL8xFOZdEsSOX+gne9h6ClHI4D+uarhbbCizpljCCorJrEKYpWSSknGctGsEOP2qPmOXgCwQmoSYqMmTvmzGpkz3F30ZRkapShHhhDYzAcGhC00ddmywYnG0ITvJyxtEyvyDHQoKzpyjymnzWeL3ry0QcQXHB152QfjGMS+uaO/LMn6ABBA6teTOtbgHif7xiP/hUzPJKKTBe1WLzZH8pOtXa02nhP+H83qJaOo0CitSi26CXgE5vJavrkrZ/Wn1Xefpe3D2vX3S/ULo/ExVbZLkrRDQSKfVXpF6Xh3aJnP8zw/Ku9miy6ptO17Os174Oq1gjKNA5e0RMELWh14T6+Wqfy1tzNmvjiQ5G9yKJSjpt5fyKG5WtsKtUvAL8x8V1evZnVkSqj8rbFlVozqBMQtP55FJ/jyh/Lf1BLAQIfABQAAAAIAHVxM1UwkYB3sQMAAIANAAAHACQAAAAAAAAAIAAAAAAAAAB4bWwueG1sCgAgAAAAAAABABgAACc/pAPM2AEAJz+kA8zYAQAnP6QDzNgBUEsFBgAAAAABAAEAWQAAANYDAAAAAA==";
// String soapEncodingString
// ="UEsDBBQAAAAIAMuah00wkYB3qgMAAIANAAAHAAAAeG1sLnhtbO1XXZOaMBR970z/g+N7jYi6uzNp2oh1ZVRgUDvdvjCsZFdmIaEBO7W/vgki4UPbTqd9K0+555ybj8vNvQDffYujzlfC05DRt12t1+92CN2xIKTPb7vbzezNbfcdev0KEhN7eLfzpiTzwyiV0CyMiDcnfkB4aYYBGkJQDHOUsxjIwdTPiGc/efeEEu5nYjk06GsjTdP7ELRJ6WIdYgk2l9YguMIUK6s9OeJgjEpdoRFgRzzQDMB5KMjCP0dyTExqiC09M36Uy1VMpdkcE2I/CUoqlKHmSBKLoWG/PxyOB7p2J6aRiBKYND1wn+6IZ8QJPXpGgDQRizZcupRBdMmOhEnWjKBizocDtdOd9xWFO59m1ZDkjMXkDCUvz9WAlLaEOpYfk7fdNYuIiD5Ps47DWcJSwru5utDnlCe1aIInHyBQQFW2CoMgIjkMqvjSP4vXfuxDUNq1NfxsT7g3P6SPPg3ak4jsknmxguA0qnJTe4K0u1tNPAMIhFUlHWwhvMbOQru5GywgEHaV3prT2jo4CDhJ0yIyIgdjnxKaneOhVMuQEg1Zpos/4s1862AXrxxzCcGZu+gxQAt7iS2z43TsUjq4KNXRxw/WPV4ubdstpXpdupSxWvn8BdRxI8yOaDO3p1tn+3mOIZBAXbLORNYhXQQsHzX82YFm/CjrQTGs845peQYLCBrfjsb9WwgKoPZKQRHL6+E1GBdWwsQLFXfmf4z/TowNFscHGu7yWlwvFOfyRyKS7BkVl/UQPxLeOBmOMu8XkhV7LAg0uhmPtf7gZjyCQMF1+Qx/akzg8DD2+dEjsdwdJXv/RX9P0yDq7VgvpBDUBK39EU5FQE8kqAXkyunP9IVyOPHpi1crtAo/1Sl9DEFpVSV2XrRKCtTcZSPYo/vOfce18VTMkAOFRKXQwjbm5il7mqvLBilTowz1UB/pw9FIF5O16avessHJhtACWx4r03DzHAMtypytjVP6mZPFsi8fTaRunasdTvbBKCKBZ+zJlwNBRwgamNIXE7Wb+SHbMx5+Fx4uSUSmi1os3uxXcqU/rbfuA/7jBnWh44BGowGN3gL+YjNZzx7czcPmf3n7t+WtUqTufqN2uSTKl0r3YYJuIKja15VeXhp+WvSsD3O8eG+tp8ueYfdMq1Hzfr+qtYIyi/xn9KC8FFq5cL++WkV5a69mTj3xocieZFEpx+28L4hR+RrbyvoXgNdy/BnfuJlqS8pQp20cpdEMFCHhS38eAm7+sfwAUEsBAj8AFAAAAAgAy5qHTTCRgHeqAwAAgA0AAAcAJAAAAAAAAAAgAAAAAAAAAHhtbC54bWwKACAAAAAAAAEAGACy48YSNI7UAcLxZVYzjtQBwvFlVjOO1AFQSwUGAAAAAAEAAQBZAAAAzwMAAAAA";
// byte[] zipData = Base64.decodeBase64(soapEncodingString);
// String value = extractZipEntries(zipData);
// System.out.println(value);
// }

// public static ZipEntry extractZipEntries(byte[] bytes) throws IOException {
//
// ZipInputStream zipStream = new ZipInputStream(new
// ByteArrayInputStream(bytes));
// ZipEntry entry = null;
// while ((entry = zipStream.getNextEntry()) != null) {
//
// String entryName = entry.getName();
//
// FileOutputStream out = new FileOutputStream(entryName);
//
// byte[] byteBuff = new byte[4096];
// int bytesRead = 0;
// while ((bytesRead = zipStream.read(byteBuff)) != -1) {
// out.write(byteBuff, 0, bytesRead);
//
// }
//
// out.close();
// zipStream.closeEntry();
// }
// zipStream.close();
// return entry;
// }

// public static void main(String[] args) {
// StaXParser read = new StaXParser();
// List<Item> readConfig = read.readConfig("D:\\config2.xml");
// for (Item item : readConfig) {
// System.out.println(item);
// }
// }
//
// public String generateEiaForPartnerNJ(String requestxml, String uid, String
// pwd, MessageContext messageContext) {
// SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
// sdf = new SimpleDateFormat("ddMMyyhhmmsss");
// String businessPartnerId = "fake"; // need to passed
// String requestReferencrNumber = "fake";
// // LOGGER.info("X-Forwarded-For :: " +request.getHeader("X-Forwarded-For"));
// // LOGGER.info("Proxy-Client-IP :: " +request.getHeader("Proxy-Client-IP"));
// // LOGGER.info("WL-Proxy-Client-IP :: "
// // +request.getHeader("WL-Proxy-Client-IP"));
// // LOGGER.info("HTTP_CLIENT_IP :: " +request.getHeader("HTTP_CLIENT_IP"));
// // LOGGER.info("HTTP_X_FORWARDED_FOR :: "
// // +request.getHeader("HTTP_X_FORWARDED_FOR"));
// // LOGGER.info("Unknown :: " +request.getRemoteAddr());
// //
// String partnerIP = "fake";// request.getRemoteAddr(); pending work
// // String partnerIP =
// // request.getHeader("X-Forwarded-For");//request.getRemoteAddr();
// // if(partnerIP==null) {
// // LOGGER.info("X-Forwarded-For is getting null, now fetching RemoteAddress"
// // +partnerIP);
// // partnerIP = request.getRemoteAddr();
// // LOGGER.info("Ip from getRemoteAddress " +partnerIP);
// // }
// //
// String IPArray[] = partnerIP.split(",");
//
// /*
// * if(partnerIP.equalsIgnoreCase("0:0:0:0:0:0:0:1")){ partnerIP = "127.0.0.1";
// }
// */
//
// // LOGGER.info("List Of Ip Address :: "+Arrays.toString(IPArray));
// // NirPartnerRequestGenerator nirPartnerRequestGenerator=new
// // NirPartnerRequestGenerator();
// List<FileBean> allProofFileBean = new ArrayList<FileBean>();
// String responseStatus = "";
// String responseReferenceNumber = "";
// String responseMessage = "";
// try {
//
// boolean validatePartner = false;
//
// LOGGER.info("Validating Partner with below data");
// LOGGER.info("User Id : " + uid);
// LOGGER.info("Password : " + pwd);
// LOGGER.info("Businsess Partner Id : " + businessPartnerId);
// LOGGER.info("Request Reference Number : " + requestReferencrNumber);
// for (String ipAddress : IPArray) {
//
// if (ipAddress.equalsIgnoreCase("0:0:0:0:0:0:0:1")) {
// ipAddress = "127.0.0.1";
// }
// LOGGER.info("IP Address" + ipAddress);
// //
// validatePartner=nirPartnerDelegate.validatePartnerIpAddressForNJ(businessPartnerId,uid,pwd,ipAddress);
// validatePartner = validatePartnerIpAddressForNJ(businessPartnerId, uid, pwd,
// ipAddress);
// if (validatePartner) {
// partnerIP = ipAddress;
// break;
// } else {
// LOGGER.info("IP Not found " + ipAddress);
// }
// }
// if (validatePartner) {
//
// NirPartnerTxnEiaCreation nirPartnerTxnEiaCreation = new
// NirPartnerTxnEiaCreation();
// // nirPartnerTxnEiaCreation.setNptectransactionreference(1234);
// nirPartnerTxnEiaCreation.setNptecpartnerid(businessPartnerId);
// nirPartnerTxnEiaCreation.setNptecrequestreferencenumber(Long.parseLong(requestReferencrNumber));
// nirPartnerTxnEiaCreation.setNptecrequestxml(requestxml);
// nirPartnerTxnEiaCreation.setNptecvisitorip(partnerIP);
// nirPartnerTxnEiaCreation.setNpteccreateddate(new Date());
// nirPartnerTxnEiaCreation.setNpteccreatedby("WebService");//
// NJGroupEiaCreation
// // long transactionreferenceId =
// // nirPartnerDelegate.savePartnerTransaction(nirPartnerTxnEiaCreation);
// NirPartnerTxnEiaCreation nirPartnerTxnEiaCreationNew =
// nirPartnerTxnEiaCreationRepo
// .save(nirPartnerTxnEiaCreation);
// boolean isDataSave = false;
// if (nirPartnerTxnEiaCreationNew != null) {
//
// long transactionreferenceId =
// nirPartnerTxnEiaCreationNew.getNptectransactionreference();
// LOGGER.info("Id - " + transactionreferenceId);
// if (transactionreferenceId != 0) {
// isDataSave = true;
// responseReferenceNumber = Long.toString(transactionreferenceId);
// }
// }
// if (isDataSave) {
// // String ackNumberGenerated = popMkrChkrDelegate.generateEiaApplnAckNo();
// String ackNumberGenerated = generateEiaApplnAckNo();
// LOGGER.info("New ack no generated as--->" + ackNumberGenerated);
// String tempFileName = businessPartnerId + requestReferencrNumber + ".xml";
// File inputXmlFile = new File(
// NIRConstants.BASE_FILE_SYSTEM_PATH + "EIA/PARTNER_REQUEST/" + tempFileName);
// LOGGER.info("Input XMl File Name :" + inputXmlFile.getName());
// LOGGER.info("Input XMl File absolute path :" +
// inputXmlFile.getAbsolutePath());
// LOGGER.info("Storing request xml temporary in file and sending it to
// process");
// java.io.FileWriter fw = new java.io.FileWriter(inputXmlFile);
// fw.write(requestxml);
// fw.close();
//
// // validate the input xml file using FVU .
//
// NJEiaService njEiaService = new NJEiaService();
// List<AccountOpeningFormBean> accountOpeningFormBeansList = njEiaService
// .startBusinessValidation(inputXmlFile);
// SimpleDateFormat originalFormat = new SimpleDateFormat("yyyyMMdd");
// SimpleDateFormat targetFormat = new SimpleDateFormat("dd-MM-yyyy");
// Date Date_Of_Receipt =
// originalFormat.parse(accountOpeningFormBeansList.get(0).getFormSubDate());
// String formatted_Date_Of_Receipt = targetFormat.format(Date_Of_Receipt);
//
// accountOpeningFormBeansList.get(0).setFormSubDate(formatted_Date_Of_Receipt);
//
// Date DOB1 = originalFormat.parse(
// accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(0).getDateOfBirth());
// String formatted_DOB1 = targetFormat.format(DOB1);
//
// accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(0)
// .setDateOfBirth(formatted_DOB1);
//
// if (accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(1)
// .getDateOfBirth() != null) {
//
// if (accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(1)
// .getDateOfBirth() != "") {
//
// Date DOB2 = originalFormat.parse(accountOpeningFormBeansList.get(0)
// .getProposalDetailBeanList().get(1).getDateOfBirth());
// String formatted_DOB2 = targetFormat.format(DOB2);
//
// accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(1)
// .setDateOfBirth(formatted_DOB2);
// }
// }
// if (accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(2)
// .getDateOfBirth() != null) {
// if (accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(2)
// .getDateOfBirth() != "") {
// LOGGER.info("DOB3 " +
// accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(2)
// .getDateOfBirth());
// Date DOB3 = originalFormat.parse(accountOpeningFormBeansList.get(0)
// .getProposalDetailBeanList().get(2).getDateOfBirth());
// String formatted_DOB3 = targetFormat.format(DOB3);
// LOGGER.info("formatted_DOB3 " + formatted_DOB3);
// accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(2)
// .setDateOfBirth(formatted_DOB3);
// }
// }
// accountOpeningFormBeansList.get(0).setTrnxId("99999");
// accountOpeningFormBeansList.get(0).setAckNo(ackNumberGenerated);
// accountOpeningFormBeansList.get(0).setAccountCategory("01");
// accountOpeningFormBeansList.get(0).setAccountType("01");
// accountOpeningFormBeansList.get(0).setEntityCode("03");
//
// accountOpeningFormBeansList.get(0).setIsAadharBased("Y");
// accountOpeningFormBeansList.get(0).setPartnerType("WebService");
//
// String mobileNumber =
// accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(0)
// .getMobileNo();
// String newPan =
// accountOpeningFormBeansList.get(0).getProposalDetailBeanList().get(0).getPan();
// // List<String> eIANoListForPAN =
// // popMkrChkrDelegate.getPANStatusForSoleProp("01", "01",
// // newPan.toUpperCase().trim());
// List<String> eIANoListForPAN = findPANStatusForSoleProp("01", "01",
// newPan.toUpperCase().trim());
//
// if (eIANoListForPAN.size() == 0) {
//// boolean isvalidPAN = validatePAN(newPan);
//// if (newPan != null && isvalidPAN && mobileNumber != null
//// && validateMobileNumber(mobileNumber)) {
// boolean isvalidPAN =true;
//
// if(isvalidPAN) {
//
// // String eIA =
// // popMkrChkrDelegate.createEIANew(accountOpeningFormBeansList.get(0),
// // accountOpeningFormBeansList.get(0).getAckNo(), "WebService",
// // allProofFileBean);
// String eIA = createEIANew(accountOpeningFormBeansList.get(0),
// accountOpeningFormBeansList.get(0).getAckNo(), "WebService",
// allProofFileBean);
// System.out.println("EIA ----- " + eIA);
//
// //
// ###################################################################################
// // This will required after real time dedupe .....
// // eIA = eIA+"|Test:Success";
// /*
// * String[] splitoutput = eIA.split(":"); if(splitoutput.length>1){
// *
// * if(splitoutput[1].equalsIgnoreCase("success")){ responseStatus="SUCCESS";
// * responseMessage= splitoutput[0].trim(); }else{ responseStatus="FAIL";
// * responseMessage= splitoutput[1].trim(); } }else{ responseStatus="FAIL";
// * responseMessage="Eia account is not active";
// *
// * }
// */
// //
// ###################################################################################
//
// if (eIA != null) {
// if (!eIA.equalsIgnoreCase("")) {
// if (businessPartnerId.equalsIgnoreCase("ALANKIT")) {
// responseStatus = "S";
// responseMessage = ackNumberGenerated;
// } else {
// responseStatus = "S";
// responseMessage = eIA;
// }
// } else {
// responseStatus = "FAIL";
// responseMessage = "Error while creating eia account";
// }
// } else {
// responseStatus = "FAIL";
// responseMessage = "Error while creating eia account";
// }
// // response =
// //
// nirPartnerRequestGenerator.createResponseXmlforNJEIACreation(businessPartnerId,
// // requestReferencrNumber, responseStatus, responseReferenceNumber,
// // responseMessage);
// // LOGGER.info("Response XML " + response);
// //
// // boolean updateNjTransaction = nirPartnerDelegate
// // .updatePartnerTransaction(transactionreferenceId, response);
// // if (updateNjTransaction) {
// // LOGGER.info("Response updated in Nj Transaction table");
// // } else {
// // LOGGER.info("Response updation failed in Nj Transaction table");
// // }
// } else {
//
// LOGGER.info("Please provide PAN number");
//
// responseStatus = "FAIL";
//// if (!isvalidPAN) {
//// responseMessage = "Please provide valid PAN number";
//// } else {
//// responseMessage = "Please provide valid mobile number";
//// }
// LOGGER.info("Generating Response...");
// // response =
// //
// nirPartnerRequestGenerator.createResponseXmlforNJEIACreation(businessPartnerId,
// // requestReferencrNumber, responseStatus, responseReferenceNumber,
// // responseMessage);
// // LOGGER.info("Response XML " + response);
//
// }
//
// } else {
//// LOGGER.info("eIA Account " + eIANoListForPAN.get(0) + " is Already Present
// With PAN "
//// + newPan.toUpperCase().trim());
//// responseStatus = "FAIL";
//// responseMessage = "eIA Account " + eIANoListForPAN.get(0) + " is Already
// Present With PAN "
//// + newPan.toUpperCase().trim();
//// LOGGER.info("Generating Response...");
// // response =
// //
// nirPartnerRequestGenerator.createResponseXmlforNJEIACreation(businessPartnerId,
// // requestReferencrNumber, responseStatus, responseReferenceNumber,
// // responseMessage);
// // LOGGER.info("Response XML " + response);
//
// // boolean updateNjTransaction = nirPartnerDelegate
// // .updatePartnerTransaction(transactionreferenceId, response);
// // if (updateNjTransaction) {
// // LOGGER.info("Response updated in Nj Transaction table");
// // } else {
// // LOGGER.info("Response updation failed in Nj Transaction table");
// // }
// }
//
// } else {
// responseStatus = "FAIL";
// responseMessage = "Data save failure in Partner transcation eia creation
// table";
// LOGGER.info("Generating Response...");
// // response =
// //
// nirPartnerRequestGenerator.createResponseXmlforNJEIACreation(businessPartnerId,
// // requestReferencrNumber, responseStatus, responseReferenceNumber,
// // responseMessage);
// // LOGGER.info("Response XML " + response);
// LOGGER.info("Data save failure in Partner transcation eia creation table");
// }
//
// } else {
// responseStatus = "FAIL";
// responseMessage = "Invalid Partner";
// LOGGER.info("Generating Response...");
// // response =
// //
// nirPartnerRequestGenerator.createResponseXmlforNJEIACreation(businessPartnerId,
// // requestReferencrNumber, responseStatus, responseReferenceNumber,
// // responseMessage);
// // LOGGER.info("Response XML " + response);
// LOGGER.info("Data save failure in Partner transcation eia creation table");
// LOGGER.info("Invalid Partner");
// }
//
// } catch (Exception e) {
//
// e.printStackTrace();
// }
// return responseStatus;
// }
//
// // @Override
// public boolean validatePartnerIpAddressForNJ(String partnerId, String userId,
// String password,
// String partnerIpAddress) {
//
// // Session session = null;
// boolean partnerIpFlag = false;
// try {
// LOGGER.info("Inside EJBNirPartnerDaoImpl validatePartnerIpAddress Starts ");
//
// int partnerIpCount = 0;
// // List<NirPartnerMstr> nirPartnerIpList = new ArrayList<NirPartnerMstr>();
//
// List<NirPartnerMstr> nirPartnerIpList =
// nirPartnerMstrRepo.findByPartnerId(partnerId); // jpa added
// // session = sessionFactory.openSession();
// // Criteria criteria = session.createCriteria(NirPartnerMstr.class);
// // criteria.add(Restrictions.eq("partnerId", partnerId));
// // nirPartnerIpList = criteria.list();
//
// if (nirPartnerIpList != null && nirPartnerIpList.size() > 0) {
// for (int i = 0; i < nirPartnerIpList.size(); i++) {
// // NirPartnerMstr mstr = new NirPartnerMstr();
//
// LOGGER.info("Inside EJBNirPartnerDaoImpl validatePartnerIpAddress getIp "
// + nirPartnerIpList.get(0).getNirPartnerIpMapping().get(i).getIpAddress() +
// "---"
// + partnerIpAddress);
//
// String partnerIP = partnerIpAddress.substring(0,
// partnerIpAddress.lastIndexOf("."));
// String dbIp =
// nirPartnerIpList.get(0).getNirPartnerIpMapping().get(i).getIpAddress();
// String new_dbIp = dbIp.substring(0, dbIp.lastIndexOf("."));
// LOGGER.info("New Partner IP - " + partnerIP);
// LOGGER.info("New DB IP - " + new_dbIp);
//
// if (partnerIP.equals(new_dbIp) &&
// userId.equals(nirPartnerIpList.get(0).getUserId())
// && password.equals(nirPartnerIpList.get(0).getPassword())) {
//
// partnerIpCount++;
// }
// }
//
// if (partnerIpCount == 1) {
// partnerIpFlag = true;
// } else {
// LOGGER.info("Inside EJBNirPartnerDaoImpl username and passowrd does not match
// ");
// }
//
// } else {
// LOGGER.info("Inside EJBNirPartnerDaoImpl username and passowrd does not match
// ");
// }
//
// LOGGER.info("Inside EJBNirPartnerDaoImpl validatePartnerIpAddress Ends " +
// partnerIpFlag);
//
// } catch (Exception e) {
// LOGGER.error("Exception in validatepartnerIpAddress:: " + e.getMessage());
// e.printStackTrace();
// }
// // } finally {
// // if (session != null && session.isOpen()) {
// //
// // session.close();
// // }
// //
// // }
// return partnerIpFlag;
// }
//
// public String generateEiaApplnAckNo() {
// LOGGER.info("Logger added for testing-->1");
// LOGGER.info("In generateEiaApplnAckNo method-->");
// LOGGER.info("Logger added for testing-->2");
// long nirSeqeunceNumber = 0;
// String idRenegerated = "";
// // Long idRenegeratedLong;
// int increment = 1;
// String newSequence = "";
// CripSeqGnrtr cripSeqGnrtr = null;
// // Session session = null; //
// HibernateUtilBV.getSessionFactory().openSession();
// // Transaction tx = null; // session.beginTransaction();
// String formatStr = "";
// String dbNewSeq = "";
// String returnSequence = "";
// try {
// // session = sessionFactory.openSession();
// // tx = session.beginTransaction();
// // Criteria codeMater = session.createCriteria(CripSeqGnrtr.class);
// // codeMater.add(Restrictions.eq("csgGenKey", "ACK_ID_SEQ"));
// // codeMater.setLockMode(LockMode.PESSIMISTIC_WRITE);
// // cripSeqGnrtr = (CripSeqGnrtr) codeMater.uniqueResult();
// cripSeqGnrtr = cripSeqGnrtrRepo.findByCsgGenKey("ACK_ID_SEQ"); // jpa added
// nirSeqeunceNumber = Long.valueOf(cripSeqGnrtr.getCsgGenValue());
// returnSequence = cripSeqGnrtr.getCsgGenValue();
// newSequence = String.valueOf((nirSeqeunceNumber + increment));
//
// formatStr = "%0" + cripSeqGnrtr.getCsgValueLen() + "d";
// if (newSequence.length() <
// Integer.parseInt(String.valueOf(cripSeqGnrtr.getCsgValueLen()))) {
// dbNewSeq = String.format(formatStr, Long.parseLong(newSequence));
// } else {
// dbNewSeq = String.format(formatStr, Long.parseLong("1"));
// }
//
// cripSeqGnrtr.setCsgGenValue(dbNewSeq);
// // session.update(cripSeqGnrtr);
// // tx.commit();
// } catch (Exception e) {
// LOGGER.fatal("Exception in generateEiaApplnAckNo-->" + e.getMessage());
// e.printStackTrace();
// }
// // tx.rollback();
// // } finally {
// //// if (session != null && session.isOpen()) {
// //// session.close();
// //// }
// // }
// LOGGER.info("generateEiaApplnAckNo Seq no-->" + nirSeqeunceNumber);
// LOGGER.info("generateEiaApplnAckNo Seq no Formarted -->" + returnSequence);
//
// String applnAckSeq = "";
// String applnAckNumber = null;
// Calendar currentDate = Calendar.getInstance();
// SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
// String dateNow = formatter.format(currentDate.getTime());
// try {
// applnAckSeq = returnSequence;// eiaCommonDao.getapplnAckNumberWithLock();
// applnAckNumber = calcApplnAck(dateNow + applnAckSeq);
// } catch (Exception e) {
// LOGGER.error("EXCEPTION IN generateEiaApplnAckNo : " + e.getMessage());
// }
// LOGGER.info("Final Ack Number :: " + applnAckNumber);
// return applnAckNumber;
// }
//
// /**
// * @description : This method is used to calculate Ack number
// * @author : ANIKET
// **/
// public static String calcApplnAck(String digStr) {
// final int[][] sumTable = { { 1, 8, 9, 7, 6, 3, 2, 0, 4, 5 }, { 0, 2, 4, 6, 8,
// 1, 3, 5, 7, 9 } };
// int sum = 0, flip = 0, rem = 0;
// for (int i = digStr.length() - 1; i >= 0; i--) {
// sum += sumTable[flip++ & 0x1][Character.digit(digStr.charAt(i), 10)];
// }
// rem = sum % 10;
// String remDer = String.valueOf(rem);
// StringBuilder SB = new StringBuilder(digStr);
// SB.insert(6, remDer);
// return SB.toString();
// }
//
// /**
// * @description : This method is to get ack number
// * @author : ANIKET
// **/
// public String[] getapplnAckNumber() {
// String[] applnSequenceNumber = new String[2];
// // Transaction tx = null;
// try {
// // tx = session.beginTransaction();
//
// // Query query = session.createQuery("from CripSeqGnrtr where
// // csgGenKey=?").setParameter(0, "ACK_ID_SEQ");
// CripSeqGnrtr cripSeqGnrtr = cripSeqGnrtrRepo.findByCsgGenKey("ACK_ID_SEQ");
// // jpa added
// // CripSeqGnrtr cripSeqGnrtr = (CripSeqGnrtr) query.uniqueResult();
// if (cripSeqGnrtr != null) {
// applnSequenceNumber[0] = cripSeqGnrtr.getCsgGenValue();
// applnSequenceNumber[1] = String.valueOf(cripSeqGnrtr.getCsgValueLen());
// LOGGER.info("Current seq value for ACK_ID_SEQ is-->" +
// cripSeqGnrtr.getCsgGenValue());
// }
// // tx.commit();
// } catch (Exception e) {
// // if (tx != null && tx.isActive()) {
// // tx.rollback();
// // }
// LOGGER.fatal("Exception in getapplnAckNumber metod-->" + e.getMessage());
// e.printStackTrace();
// }
// return applnSequenceNumber;
// }
//
// /**
// * @description : This method is used to get status of PAN for sole proposer
// * @author : SHANKAR
// **/
// public List<String> findPANStatusForSoleProp(String accCat, String accType,
// String PANNo) {
// List<String> eIANoListForPAN = new ArrayList<String>();
// if (PANNo == null || PANNo.trim().equals(NIRConstants.BLANK_STRING)) {
// LOGGER.warn("PAN not provided so returning null-->");
// return eIANoListForPAN;
// }
// try {
// LOGGER.info("In findPANStatusForSoleProp with details Account Catogery :-" +
// accCat + " Account type :-"
// + accType + " PAN :-" + PANNo.trim());
// eIANoListForPAN =
// super.findListByQueryName("CripEiaPrpsrAthrp.findPANStatusForSoleProp",
// PANNo.toUpperCase().trim());
// } catch (EntityNotFoundException e) {
// LOGGER.fatal("EntityNotFoundException in findPANStatusForSoleProp function :"
// + e.getMessage());
// e.printStackTrace();
// } catch (Exception e) {
// LOGGER.fatal("Exception in findPANStatusForSoleProp function :" +
// e.getMessage());
// e.printStackTrace();
// }
// return eIANoListForPAN;
// }
//
// // public boolean validatePAN(String PAN) {
// // boolean returnvalue = false;
// // boolean saveITD = false;
// // try {
// // String regx = "[a-zA-z]{3}[P][a-zA-z]{1}\\d{4}[a-zA-Z]{1}";
// // if (PAN.matches(regx)) {
// //
// // MainClass panObj = new MainClass();
// // String responseData = panObj.getPanData(PAN);
// //
// // if (!responseData.equals(null)) {
// // String splitResponseData[] = responseData.split("\\^", -1);
// // LOGGER.info("ITD PAN Response - " + Arrays.toString(splitResponseData));
// // LOGGER.info("Pan Status " + splitResponseData[2]);
// //
// // saveITD = eiaApplicantController.saveITD(responseData,
// // splitResponseData[1].toUpperCase(),
// // splitResponseData[2], splitResponseData[4], splitResponseData[5],
// // splitResponseData[3]);
// //
// // if (saveITD && splitResponseData[2].equalsIgnoreCase("E")) {
// // returnvalue = true;
// // } else {
// // returnvalue = false;
// // }
// //
// // } else {
// // saveITD = eiaApplicantController.saveITD("", PAN, "F", "", "", "");
// // if (saveITD) {
// // returnvalue = false;
// // } else {
// // returnvalue = false;
// // }
// // }
// // } else {
// //
// // returnvalue = false;
// // }
// //
// // } catch (Exception e) {
// // LOGGER.error("Exception while validating PAN");
// // }
// // return returnvalue;
// // }
//
// public String createEIANew(AccountOpeningFormBean checkerBean, String ackNo,
// String createdBy,
// List<FileBean> allProofFileBean) {
// LOGGER.info("In createEIA method of CheckerServiceImpl with ekyc flag----->"
// + checkerBean.getEkycFlag());
// LOGGER.info("$$$$$$$$$$$$$$$$$$$$$ VID In createEIANew
// $$$$$$$$$$$$$$$$$$$$$$$$ " + checkerBean.getVidToken());
//
// if (checkerBean.getEkycFlag() != null &&
// checkerBean.getEkycFlag().equalsIgnoreCase("Y")) {
// // LOGGER.info("Going to send email to user for further otp/biometric
// // process-->");
// // String ekycOtpUrl = null;
// // try {
// // Properties props = new Properties();
// // FileInputStream in;
// // in = new FileInputStream(NIRConstants.EMAIL_PROPERTY_FILE);
// // props.load(in);
// // in.close();
// // ekycOtpUrl = props.getProperty("nir.ekyc-url-otp");
// // } catch (Exception e) {
// // LOG.fatal("Exception occured while reading email property file-->");
// // return null;
// // }
// // if (ekycOtpUrl == null || ekycOtpUrl.equals(NIRConstants.BLANK_STRING)) {
// // LOG.fatal("nir.ekyc-url-otp not defined in crip-email property file.
// Please
// // make entry for it--->");
// // return null;
// // }
// // CripEmailInt cripEmailInt = null;
// // CripSmsInt cripSmsInt = null;
// // if (checkerBean.getProposalDetailBeanList().get(0).getOtpOrBiometricFlag()
// !=
// // null &&
// //
// checkerBean.getProposalDetailBeanList().get(0).getOtpOrBiometricFlag().equalsIgnoreCase("O"))
// // {
// // ekycOtpUrl = ekycOtpUrl + "?ackNo=" + ackNo;
// // LOG.info("User has opted for otp-->" +
// // checkerBean.getProposalDetailBeanList().get(0).getOtpOrBiometricFlag());
// // LOG.info("Setting email table for otp with url-->" + ekycOtpUrl);
// // String eia = NIRConstants.BLANK_STRING;
// // String fullName =
// //
// CommonMethodsAP.setFullName(checkerBean.getProposalDetailBeanList().get(0).getFirstNameOfCustomer(),
// // checkerBean.getProposalDetailBeanList().get(0).getMiddleNameOfCustomer(),
// // checkerBean.getProposalDetailBeanList().get(0).getLastNameOfCustomer());
// // String emailContent = fullName + "," + ackNo + "," + ekycOtpUrl;
// // LOG.info("Email content-->" + emailContent);
// // cripEmailInt = populateCripEmailInt(checkerBean, eia, ackNo, "T17",
// // emailContent);
// // LOG.info("Setting sms table for otp-->");
// // String smsContent = ackNo;
// // LOG.info("Sms content-->" + smsContent);
// // cripSmsInt = populateCripSmsInt(checkerBean, eia, ackNo, "T17",
// smsContent);
// // LOG.info("Calling dao---->");
// // boolean status = makerCheckerDao.processOPTRequest(checkerBean,
// cripEmailInt,
// // cripSmsInt);
// // LOG.info("Status of process-->" + status);
// // if (!status) {
// // return null;
// // } else {
// // return String.valueOf(status);
// // }
// // }
// } else {
//// Session sessionObj = sessionFactory.openSession();
//// Transaction trans = sessionObj.beginTransaction();
//// LOGGER.info("Hibernate Session created in createEIA--->" + sessionObj);
// LOGGER.info("Hibernate Trans created in createEIA----->" + trans);
//// String eIA = eiaService.generateEiaNumber();
// String eIA = generateEiaNumber();
// CripEiaAcct cripEiaAcct = new CripEiaAcct();
// // Set fields of EIA_ACCT table
//
// cripEiaAcct.setCeaAckId(ackNo);
// cripEiaAcct.setCeaApplId(checkerBean.getApplicationNo());
// cripEiaAcct.setCeaEiaAcctCatid(checkerBean.getAccountCategory());
// cripEiaAcct.setCeaEiaAcctType(checkerBean.getAccountType());
// cripEiaAcct.setCeaEiaAcctId(eIA);
// cripEiaAcct.setCeaEiaAcctStatus("01");
// cripEiaAcct.setCeaDedupFlg("01");
// cripEiaAcct.setCeaPrntrFlg("01");
// cripEiaAcct.setCeaTotApplcnt(1);
// cripEiaAcct.setCeaEntityCd(checkerBean.getEntityCode());
// cripEiaAcct.setCeaWebParam(checkerBean.getWebParameter()); /****
// * Added By Mayur J on 28-02-2019 to store
// * Insurance company web-site hit parameter
// *****/
//
// /***************
// * Added By Mayur J on 11-01-2019 to stored nameMatching score
// ******************/
//
// //
// cripEiaAcct.setNameMatchedScore(Double.valueOf(checkerBean.getNameScored()));
//
// /**********************************************************************************************/
// // cripEiaAcct.setCeaPwd(checkerBean.getIsExternal());
// cripEiaAcct.setCeaOnlineFlg(checkerBean.getIsExternal());
// LOGGER.info("IsExternal set as-->" + cripEiaAcct.getCeaOnlineFlg());
// try {
// cripEiaAcct.setCeaKycFlag(checkerBean.getProposalDetailBeanList().get(0).getOtpOrBiometricFlag());
// LOGGER.info("Kyc Flag set as-->" + cripEiaAcct.getCeaKycFlag());
// } catch (Exception e) {
// LOGGER.fatal("Exception while setting OtpOrBiometricFlag-->" +
// e.getMessage());
// }
// // FTR 5930 Start
// // if (checkerBean.getIcCd() != null &&
// // (!checkerBean.getIcCd().equalsIgnoreCase(NIRConstants.BLANK_STRING) &&
// // !checkerBean.getIcCd().equalsIgnoreCase("00"))) {
// if (checkerBean.getIcCd() != null &&
// (!checkerBean.getIcCd().equalsIgnoreCase(NIRConstants.BLANK_STRING))) {
// // FTR 5930 End
// cripEiaAcct.setCeaInsCmpnyCd(checkerBean.getIcCd());
// // 07082015 Start
// // cripEiaAcct.setCeaApOrIcBrnchCd(null);
// cripEiaAcct.setCeaOnBehalfOfIc("01");
// cripEiaAcct.setCeaEntityCreatedBy(checkerBean.getApOrICCode());
// cripEiaAcct.setCeaApOrIcBrnchCd(checkerBean.getApOrICBranchCode());
// // 07082015 End
// LOGGER.warn("This EIA is created on the behalf of IC whose code is-->" +
// checkerBean.getIcCd());
// } else {
// cripEiaAcct.setCeaInsCmpnyCd(checkerBean.getApOrICCode());
// cripEiaAcct.setCeaApOrIcBrnchCd(checkerBean.getApOrICBranchCode());
// // 07082015 Start
// cripEiaAcct.setCeaOnBehalfOfIc("02");
// cripEiaAcct.setCeaEntityCreatedBy(checkerBean.getApOrICCode());
// // 07082015 End
// LOGGER.warn("This EIA is self created for AP/IC Code--------->" +
// checkerBean.getApOrICCode());
// LOGGER.warn("This EIA is self created for AP/IC Branch Code-->" +
// checkerBean.getApOrICBranchCode());
// }
// if (checkerBean.getSentMailToAuth().equals("1")) {
// cripEiaAcct.setCeaAthrpSmsFlg("01");
// }
// cripEiaAcct.setCeaApplId(checkerBean.getApplNo());
// if (checkerBean.getFormSubDate() != null
// && !checkerBean.getFormSubDate().equals(NIRConstants.BLANK_STRING)) {
// try {
// Calendar tempDate = Calendar.getInstance();
// SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
// tempDate.setTime(formatter.parse(checkerBean.getFormSubDate()));
// // 03022015 Start
// // cripEiaAcct.setCeaApplDt(tempDate);
// // 03022015 End
// } catch (Exception e) {
// LOGGER.fatal("Exception while inserting data in column setCeaApplDt in
// CripEiaAcct table :"
// + e.getMessage());
// e.printStackTrace();
// }
// } else {
// LOGGER.warn("<---Form Submission Date Not Provided---->");
// }
// // setting bank details
// CripEiaBnkDtl bnkDtl = getBankDetails(eIA, checkerBean, createdBy);
// if (bnkDtl == null) {
// LOGGER.fatal("Bank domain is null...so returning null");
// return null;
// }
// cripEiaAcct.setCripEiaBnkDtl(bnkDtl);
// // setting PrpsrDetails
// LOGGER.info("LINE NO. 4046 vidTOKEN NUMBER :" + checkerBean.getVidToken());
// Set<CripEiaPrpsrAthrp> set = getPropAthRepSet(eIA, checkerBean, createdBy);
// if (set == null || set.size() == 0) {
// LOGGER.fatal("CripEiaPrpsrAthrp set is null---->");
// LOGGER.fatal("So stopping the further process---->");
// return null;
// }
// cripEiaAcct.setCripEiaPrpAthrp(set);
// Calendar now = Calendar.getInstance();
// cripEiaAcct.setCeaLstUpdTmstmp(now);
// cripEiaAcct.setCeaCrtDate(now);
// cripEiaAcct.setCeaCrtBy(createdBy);
// if (checkerBean.getTrnxId() != null &&
// !checkerBean.getTrnxId().equals(NIRConstants.BLANK_STRING)) {
// cripEiaAcct.setCeaTransactionId(Long.valueOf(checkerBean.getTrnxId().trim()));
// } else {
// LOGGER.fatal("<--Tranaction Id not present to be stored-->");
// }
// if (checkerBean.getIpAddress() != null &&
// !checkerBean.getIpAddress().equals(NIRConstants.BLANK_STRING)) {
// cripEiaAcct.setCeaIpAddress(checkerBean.getIpAddress().trim());
// } else {
// LOGGER.fatal("<--IP Address not present to be stored-->");
// }
// /*
// * USER DOMAIN
// */
//
// CripUsrMstr user = createUser(eIA, checkerBean, createdBy);
// cripEiaAcct.setCeaUsrId(user.getCumLoginId() != null ?
// user.getCumLoginId().trim().toLowerCase() : "");
//
// // BUG CR 4866 Start
// LOGGER.info("Before Aadhar Flag Print ::" + checkerBean.getIsAadharBased());
// String adharBased = checkerBean.getIsAadharBased() != null ?
// checkerBean.getIsAadharBased() : "N";
// LOGGER.info("Before Aadhar Flag Print ::");
// LOGGER.info("In createEIANew method for Aadhaar Check::");
// LOGGER.info("Is Application Aadhar Based -2 ::" + adharBased);
// LOGGER.info("New log for Aadhar Based eIA::");
// // need to check this is null or not ///////////
// if (adharBased.equalsIgnoreCase("N")) {
// checkerBean.setIsAadharBased("");
// LOGGER.info("Application Aadhar Based value set as empty string::");
// }
//
// if (adharBased != null && adharBased.equalsIgnoreCase("Y")) {
//
// cripEiaAcct.setCeaIsMandatoryDataPresent("N");
// LOGGER.info("all madatory Data not present------>");
// } else {
//
// if (isAuthAndBankMandatoryDataPresent(checkerBean)) {
// cripEiaAcct.setCeaIsMandatoryDataPresent("Y");
// LOGGER.info("all madatory Data present------>");
// } else {
// cripEiaAcct.setCeaIsMandatoryDataPresent("N");
// LOGGER.info("all madatory Data not present------>");
// }
// }
// // BUG CR 4866 Start
//
// /*
// * ROLE DOMAIN
// */
// CripRlUsrMap role = null;
// /*
// * Registration DOMAIN
// */
// CripRegstrn regStats = setApkStatus(checkerBean, ackNo, "04", createdBy);
// /*
// * EMAIL AND SMS DOMAIN LIST
// */
// List<CripEmailInt> emailList = new ArrayList<CripEmailInt>();
// List<CripSmsInt> smsList = new ArrayList<CripSmsInt>();
// LOG.info("Going to call makerCheckerDao--->");
// boolean status = makerCheckerDao.createEIA(sessionObj, cripEiaAcct, user,
// role, regStats, emailList,
// smsList);
// if (status == true) {
// // FTR 5500 Start
// LOG.info("GOING TO SAVE PROOF INTO DOC TABLE START");
// System.out.println("GOING TO SAVE PROOF INTO DOC TABLE START");
// boolean isDocSaved = makerCheckerDao.uploadProofImageFiles(sessionObj,
// checkerBean, allProofFileBean);
// System.out.println("GOING TO SAVE PROOF INTO DOC TABLE END : " + isDocSaved);
// LOG.info("GOING TO SAVE PROOF INTO DOC TABLE END : " + isDocSaved);
// // FTR 5500 End
//
// LOG.info("SAVING DocUpldDtlTemp to DocUpldDtl Start");
// System.out.println("SAVING DocUpldDtlTemp to DocUpldDtl Start");
// // boolean isDocTempToDocSaved =
// // makerService.saveProofImageFileFromDocUpldTempToMasterTblNew(sessionObj,
// // ackNo, eIA, createdBy);
// boolean isDocTempToDocSaved = makerCheckerDao
// .saveProofImageFileFromDocUpldTempToMasterTblNew(sessionObj, ackNo, eIA,
// createdBy);
// System.out.println("SAVING DocUpldDtlTemp to DocUpldDtl End : " +
// isDocTempToDocSaved);
// LOG.info("SAVING DocUpldDtlTemp to DocUpldDtl End : " + isDocTempToDocSaved);
//
// // CR 5113 Start
// LOG.info("Going to Update Policy Conversion Data Start--->");
// System.out.println("Going to Update Policy Conversion Data Start--->");
// boolean isPolicyConversionDataUpdated =
// makerCheckerDao.updateNirPolicyConversionData(sessionObj, ackNo,
// eIA);
// System.out.println(
// "Going to Update Policy Conversion Data End With --->" +
// isPolicyConversionDataUpdated);
// LOG.info("Going to Update Policy Conversion Data End With --->" +
// isPolicyConversionDataUpdated);
// // CR 5113 END
//
// try {
// trans.commit();
// LOG.info("Data successfully stored in all tables & EIA CREATED");
//
// /*****************
// * Added By Mayur J on 19-06-2019 for realtime Dedupe Response only for TATAM
// * Partner
// ***************************************/
//
// /*
// * if(checkerBean.getPartnerType()!=null &&
// * !checkerBean.getPartnerType().trim().equalsIgnoreCase("") &&
// * checkerBean.getPartnerType().equalsIgnoreCase("TATAM")){
// *
// * LOG.
// * info("<!============================== Dedupe Triggered for Partner
// ========================!>"
// * ); LOG.
// * info("<!============================== EIA_ACCT_ID Before DeDupe
// ========================!>"
// * +cripEiaAcct.getCeaEiaAcctId());
// *
// * NirWDedupeTimer nirWDedupeTimer=new NirWDedupeTimer();
// * nirWDedupeTimer.triggerDedupe(cripEiaAcct.getCeaEiaAcctId());
// *
// * DeDupeDao deDupeDao = new DeDupeDaoImpl(); Set<String> set1 = new
// * HashSet<>(); set1.add(cripEiaAcct.getCeaEiaAcctId()); CripEiaAcct
// * cripEiaAcct1 = deDupeDao.checkfinalStatus(set1); CisService cisServiceImpl
// =
// * new CisServiceImpl();
// *
// *
// * LOG.warn("Data get from CripEiaAcct Dedupe Flag --->" +
// * cripEiaAcct1.getCeaDedupFlg());
// * LOG.warn("Data get from CripEiaAcct Status--->" +
// * cripEiaAcct1.getCeaEiaAcctStatus());
// *
// * for (Entry<String, String> string :
// * NirWDedupeTimer.mapResponseDesc.entrySet() ) {
// *
// * LOG.
// * info("<!============================== NirWDedupeTimer.mapResponseDesc Key
// ========================!>"
// * +string.getKey()); LOG.
// * info("<!============================== NirWDedupeTimer.mapResponseDesc
// Value ========================!>"
// * +string.getValue());
// *
// * }
// *
// * if(cripEiaAcct1.getCeaDedupFlg().equalsIgnoreCase("02") &&
// * cripEiaAcct1.getCeaEiaAcctStatus().equalsIgnoreCase("01")){
// * LOG.info("NIR-POR-EJB Dedupe In side success eia 01,02");
// eIA=eIA+":success";
// *
// * }else if(cripEiaAcct1.getCeaDedupFlg().equalsIgnoreCase("02") &&
// * cripEiaAcct1.getCeaEiaAcctStatus().equalsIgnoreCase("02")){
// * LOG.info("NIR-POR-EJB Dedupe In side failed eia 02 , 02");
// *
// * for (Entry<String, String> string :
// * NirWDedupeTimer.mapResponseDesc.entrySet() ) {
// *
// * eIA=string.getKey()+":"+string.getValue(); LOG.
// * info("<!========= NIR-POR-EJB Dedupe In side failed eia 02 , 02 =======!> "
// * +eIA); } } else if(cripEiaAcct1.getCeaDedupFlg().equalsIgnoreCase("02") &&
// * cripEiaAcct1.getCeaEiaAcctStatus().equalsIgnoreCase("03")){
// * LOG.info("NIR-POR-EJB Dedupe In side On-Hold eia 03 , 02");
// * eIA=eIA+":On-Hold";
// *
// * } cisServiceImpl.updateLocalDedupeDate(cripEiaAcct.getCeaEiaAcctId(),
// * sessionObj);
// * LOG.info("Cripe_eia_acct table update column cea_dedup_date ::");
// *
// * }else{
// *
// * LOG.info("Partner Type is " +checkerBean.getPartnerType()); }
// */
// /**********************************************************************************************************************************/
//
// } catch (Exception e) {
// LOG.fatal("Exception occured while trans.commit() in createEIA method :" +
// e.getMessage());
// e.printStackTrace();
// if (trans.isActive()) {
// trans.rollback();
// }
// if (sessionObj.isOpen()) {
// sessionObj.close();
// }
// LOG.fatal("PLEASE NOTE..........EIA CREATION FAILED");
// return null;
// }
// } else {
// LOG.fatal("Merging failed in createEIA method... so NO EIA CREATED");
// if (sessionObj.isOpen()) {
// sessionObj.close();
// }
// return null;
// }
// // return eIA+" USERID: "+user.getCumLoginId()+" PASSWORD: "+password;
// LOG.info("EIA created and returning--------->");
// if (sessionObj.isOpen()) {
// sessionObj.close();
// }
//
// /*
// * Bug 4019 Audt Start
// */
// checkerBean.setEiaNo(eIA);
// makerService.saveUpdateRegistrationIntrimData(checkerBean, createdBy, "04",
// ackNo);
// /*
// * Bug 4019 Audit End
// */
// /*
// * CR 5276 Start
// */
// // FTR 5500 Start
// // LOG.info("SAVING DocUpldDtlTemp to DocUpldDtl Start");
// // makerService.saveProofImageFileFromDocUpldTempToMasterTbl(ackNo, eIA,
// // createdBy);
// // LOG.info("SAVING DocUpldDtlTemp to DocUpldDtl End");
// // FTR 5500 End
// /*
// * CR 5276 End
// */
//
// return eIA;
// }
// return null;
// }
//
// CripEiaBnkDtl getBankDetails(String eIA, AccountOpeningFormBean checkerBean,
// String loginUser) {
// LOGGER.info("In getBankDetails method-->");
// try {
// CripEiaBnkDtl bnkDtl = new CripEiaBnkDtl();
// bnkDtl.setCebdBnkAcctNo(PopCommonUtility.fillerMethodNullBlank2(checkerBean.getBankAccountNo()));
// bnkDtl.setCebdBnkAcctType(PopCommonUtility.fillerMethodNullBlank2(checkerBean.getBankAccountType()));
// LOGGER.info("Setting bank code as-->" + checkerBean.getBankName());
// bnkDtl.setCebdBnkName(PopCommonUtility.fillerMethodNullBlank2(checkerBean.getBankName()));
// //
// bnkDtl.setCebdBnkPinCd(checkerBean.getBankPinCode().equalsIgnoreCase(NIRConstants.BLANK_STRING)?null:checkerBean.getBankPinCode());
// bnkDtl.setCebdIfscCd(PopCommonUtility.fillerMethodNullBlank1(checkerBean.getBankIFSCCode()));
// bnkDtl.setCebdMicrCd(PopCommonUtility.fillerMethodNullBlank1(checkerBean.getBankMICRCode()));
// bnkDtl.setCebdCancelledCheque(PopCommonUtility.fillerMethodNullBlank1(checkerBean.getBankCancelChk()));
// bnkDtl.setCebdEiaAcctId(PopCommonUtility.fillerMethodNullBlank2(eIA));
// bnkDtl.setCebdBranchNm(PopCommonUtility.fillerMethodNullBlank2(checkerBean.getBankAddress1()));
// bnkDtl.setCebdCity(PopCommonUtility.fillerMethodNullBlank2(checkerBean.getBankAddress2()));
// bnkDtl.setCebdCrtBy(PopCommonUtility.fillerMethodNullBlank1(loginUser));
// bnkDtl.setCebdCrtDate(Calendar.getInstance());
// bnkDtl.setCebdTxId((checkerBean.getTrnxId() == null
// || checkerBean.getTrnxId().trim().equals(NIRConstants.BLANK_STRING)) ? null
// : (Long.valueOf(checkerBean.getTrnxId())));
// bnkDtl.setCebdIpaddress(PopCommonUtility.fillerMethodNullBlank1(checkerBean.getIpAddress()));
// LOGGER.info("Returning from getBankDetails method-->");
// return bnkDtl;
// } catch (Exception e) {
// LOGGER.fatal("Exception occured while setting Bank domain--->" +
// e.getMessage());
// LOGGER.fatal("<--------- Exception Start ---------->");
// for (StackTraceElement ste : e.getStackTrace()) {
// LOGGER.fatal(ste);
// }
// LOGGER.fatal("<--------- Exception End ------------>");
// e.printStackTrace();
// }
// return null;
// }
//
// Set<CripEiaPrpsrAthrp> getPropAthRepSet(String eIA, AccountOpeningFormBean
// checkerBean, String loginUser) {
// LOGGER.info("In getPropAthRepSet method-->");
// LOGGER.info("In getPropAthRepSet method viD FROM getProposalDetailBeanList
// -->" + checkerBean.getVidToken());
// List<ProposalDetailBean> prpsrList = checkerBean.getProposalDetailBeanList();
// Set<CripEiaPrpsrAthrp> athrpList = new LinkedHashSet<CripEiaPrpsrAthrp>();
// int i = 1;
// try {
// for (ProposalDetailBean prpsr : checkerBean.getProposalDetailBeanList()) {
// LOGGER.info("Loop count-->" + i + " For Proposar : P" + i);
// // LOG.info("Account TYpe Is : P" + i + " : " +
// checkerBean.getAccountType());
//
// // if there is no Second Proposer then skip the bean.
// // if (!(checkerBean.getAccountType().equalsIgnoreCase("03") &&
// // checkerBean.getAccountCategory().equalsIgnoreCase("01")) && i == 2)
// // if (checkerBean.getAccountType().equalsIgnoreCase("03") && i == 2)
// if (i == 2) {
// i++;
// LOGGER.info("Account Type Is " + checkerBean.getAccountType() + " AND
// Propposar : P" + i
// + " Conversion Not Needed");
// } else {
// CripEiaPrpsrAthrp athrp = new CripEiaPrpsrAthrp();
// athrp.setCepaFathrFrstNm(prpsr.getFatherOrHusbandFirstName());
// athrp.setCepaFathrLstNm(prpsr.getFatherOrHusbandLastName());
// athrp.setCepaFathrMidNm(prpsr.getFatherOrHusbandMiddleName());
// // tempDate.setTime(formatter.parse(prpsr.getDateOfBirth()));
// // athrp.setCepaPrpAthrpDob(tempDate);
// athrp.setCepaPrpAthrpFrstNm(prpsr.getFirstNameOfCustomer());
// // FTR 5394
// athrp.setCepaPrpAthrpGndr(
// (prpsr.getGender() != null ? prpsr.getGender().trim().toUpperCase() : ""));
// // FTR 5394
// athrp.setCepaPrpAthrpLstNm(prpsr.getLastNameOfCustomer());
// athrp.setCepaPrpAthrpMidNm(prpsr.getMiddleNameOfCustomer());
// athrp.setCepaRltnshpId(prpsr.getRelationshipProof());
// if (prpsr.getRelationshipProof() != null) {
// if (prpsr.getRelationshipProof().equalsIgnoreCase("99")) {
// athrp.setCepaOthrRltnDesc(prpsr.getRelationshipProofOthers());
// }
// }
// Calendar tempDate = Calendar.getInstance();
// if (prpsr.getDateOfBirth() != null &&
// !prpsr.getDateOfBirth().trim().equalsIgnoreCase("")) {
// // FTR 5421 Start
// // tempDate.setTime(formatter.parse(prpsr.getDateOfBirth()));
// SimpleDateFormat formatterDOB = new SimpleDateFormat("dd-MM-yyyy
// HH:mm:ss:SSS");
// tempDate.setTime(formatterDOB.parse(prpsr.getDateOfBirth() + "
// 00:00:00:000"));
// // FTR 5421 End
// athrp.setCepaPrpAthrpDob(tempDate);
// }
// athrp.setCepaCrtDate(Calendar.getInstance());
// athrp.setCepaCrtBy(loginUser);
// athrp.setCepaDobProof(prpsr.getDateOfBirthProof());
// athrp.setCepaEmail1(prpsr.getEmailId() != null ?
// prpsr.getEmailId().trim().toLowerCase() : "");
// athrp.setCepaEmail2(prpsr.getEmailIdAlt());
// athrp.setCepaFax(prpsr.getFaxNo());
// athrp.setCepaMobNo(prpsr.getMobileNo() == null ? "" : prpsr.getMobileNo());
// athrp.setCepaPhn1(prpsr.getTelephoneNo());
// athrp.setCepaPhn2(prpsr.getTelephoneNoAlt());
// athrp.setCepaPrpAthrpPan(prpsr.getPan() != null ?
// prpsr.getPan().trim().toUpperCase() : "");
// athrp.setCepaPrpAthrpUid(prpsr.getUid());
// athrp.setCepaPrpAthrpPan(prpsr.getPan());
// LOGGER.info("$$$$$$$$$$$$$$$$$$$ VID in getPropAthRepSet
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"
// + prpsr.getVid());
// athrp.setCepaPrpAthrpVid(prpsr.getVid());
// athrp.setCepaPrpsrTitleId(prpsr.getTitleOfCustomer());
// // setting correspondence and permanent address for the proposer
// String txId = checkerBean.getTrnxId();
// try {
// LOGGER.info("Tx id is-->" + txId);
// if (txId != null && !txId.trim().equalsIgnoreCase(NIRConstants.BLANK_STRING))
// {
// athrp.setCepaTxId(Long.valueOf(txId));
// } else {
// LOGGER.warn("Tx id not set in CripEiaPrpsrAthrp-->");
// }
// } catch (Exception e) {
// LOGGER.fatal("Exception while setting tx id in CripEiaPrpsrAthrp-->" +
// e.getMessage());
// }
// athrp.setCepaIpaddress(checkerBean.getIpAddress());
// athrp.setCepaIdProof(prpsr.getIdProof());
// LOGGER.info("Calling getApplAndAuthRepAddressSet to set child domain-->");
// Set<CripEiaPrpAthrpAddr> set = getApplAndAuthRepAddressSet(eIA, prpsr, "P" +
// i, loginUser, txId,
// checkerBean.getIpAddress(), checkerBean.getFileId());
// if (set == null || set.size() == 0) {
// LOGGER.fatal("CripEiaPrpAthrpAddr set is null---->");
// LOGGER.fatal("So stopping the further process---->");
// return null;
// }
// athrp.setCripPrpAthrpAddr(set);
// athrp.getPk().setCepaEiaAcctId(eIA);
// athrp.getPk().setCepaPrpAthrpFlag("P" + i);
// i++;
// athrpList.add(athrp);
// LOGGER.info("Loop completed and CripEiaPrpsrAthrp added to list-->");
// }
// }
// } catch (Exception e) {
// LOGGER.fatal("Exception occured in getPrpsr_AthrpSet. Exception is : " +
// e.getMessage());
// e.printStackTrace();
// return null;
// }
// LOGGER.info("Returning from getPropAthRepSet method-->");
// return athrpList;
// }
//
// Set<CripEiaPrpAthrpAddr> getApplAndAuthRepAddressSet(String eIA,
// ProposalDetailBean proposer, String propType,
// String loginUser, String txId, String ipAddress, String fileId) {
// LOGGER.info("Setting CripEiaPrpAthrpAddr domain-->");
// try {
// Set<CripEiaPrpAthrpAddr> addrSet = new LinkedHashSet<CripEiaPrpAthrpAddr>();
// CripEiaPrpAthrpAddr addrP = new CripEiaPrpAthrpAddr();
// CripEiaPrpAthrpAddr addrC = new CripEiaPrpAthrpAddr();
// // Setting Permanent address
// addrP.getPk().setCpaaEiaAcctId(eIA);
// addrP.getPk().setCpaaPrpAthrpAddrType("p");
// addrP.getPk().setCpaaPrpAthrpFlag(propType);
// addrP.setCpaaPrmsBldg(proposer.getPermanentAddress1() != null ?
// proposer.getPermanentAddress1() : "");
// addrP.setCpaaFltFlrDoorBlk(proposer.getPermanentAddress2());
// addrP.setCpaaRdStreetLn(proposer.getPermanentAddress3());
// addrP.setCpaaVillArLoclty(proposer.getPermanentAddress4());
// addrP.setCpaaBlkTlukSubDivTwn(
// proposer.getPermanentAddress5() != null ? proposer.getPermanentAddress5() :
// "");
// addrP.setCpaaCountryCd(proposer.getPermanentCountry() == null ? "" :
// proposer.getPermanentCountry());
// addrP.setCpaaAddrProof(proposer.getPermanentAddressProof());
// if (propType.equalsIgnoreCase("P1")) {
// if (proposer.getPermanentCountry().equalsIgnoreCase(NIRConstants.CNTY_IND)
// || proposer.getPermanentCountry().equalsIgnoreCase("101")) {
// addrP.setCpaaPinCd(proposer.getPermanentPinCode());
// addrP.setCpaaStateCd(proposer.getPermanentStateDD());
// LOGGER.info("Permanent Indian State Cd-->" + proposer.getPermanentStateDD() +
// " & Pincode---->"
// + proposer.getPermanentPinCode());
// } else {
// // addrP.setCpaaPinCd(proposer.getPermanentPinCode());
// addrP.setCpaaPinCd(proposer.getPermanentPinCodeExt());
// // addrP.setCpaaOthrState(proposer.getPermanentStateDD());
// addrP.setCpaaOthrState(proposer.getPermanentStateText());
// addrP.setCpaaStateCd("00");
// LOGGER.info("Permanent Non Indian State Name-->" +
// proposer.getPermanentStateDD()
// + " & Pincode---->" + proposer.getPermanentPinCode());
// }
// } else if (propType.equalsIgnoreCase("P3")) {
// if (proposer.getPermanentCountry() != null
// && !proposer.getPermanentCountry().trim().equals(NIRConstants.BLANK_STRING))
// {
// if (proposer.getPermanentCountry().equalsIgnoreCase(NIRConstants.CNTY_IND)
// || proposer.getPermanentCountry().equalsIgnoreCase("101")) {
// addrP.setCpaaPinCd(proposer.getPermanentPinCode());
// addrP.setCpaaStateCd(proposer.getPermanentStateDD());
// LOGGER.info("Permanent Indian State Cd-->" + proposer.getPermanentStateDD() +
// " & Pincode---->"
// + proposer.getPermanentPinCode());
// } else {
// // addrP.setCpaaPinCd(proposer.getPermanentPinCode());
// addrP.setCpaaPinCd(proposer.getPermanentPinCodeExt());
// // addrP.setCpaaOthrState(proposer.getPermanentStateDD());
// addrP.setCpaaOthrState(proposer.getPermanentStateText());
// addrP.setCpaaStateCd("00");
// LOGGER.info("Permanent Non Indian State Name-->" +
// proposer.getPermanentStateDD()
// + " & Pincode---->" + proposer.getPermanentPinCode());
// }
// } else {
// addrP.setCpaaPinCd(proposer.getPermanentPinCode());
// addrP.setCpaaStateCd(proposer.getPermanentStateDD());
// }
// }
// addrP.setCpaaCrtBy(loginUser);
// addrP.setCpaaCrtDate(Calendar.getInstance());
// addrP.setCpaaIpAddress(ipAddress);
// try {
// LOGGER.info("Tx id is-->" + txId);
// if (txId != null && !txId.trim().equalsIgnoreCase(NIRConstants.BLANK_STRING))
// {
// addrP.setCpaaTxId(Long.valueOf(txId));
// } else {
// LOGGER.warn("Tx id not set in CripEiaPrpAthrpAddr-->");
// }
// } catch (Exception e) {
// LOGGER.fatal("Exception while setting tx id in CripEiaPrpsrAthrp-->" +
// e.getMessage());
// }
// addrSet.add(addrP);
// // Setting correspondence address
// if (!propType.equalsIgnoreCase("P3")) {
// LOGGER.info("Going to set correspondence Address-->");
// addrC.getPk().setCpaaEiaAcctId(eIA);
// addrC.getPk().setCpaaPrpAthrpAddrType("c");
// addrC.getPk().setCpaaPrpAthrpFlag(propType);
// addrC.setCpaaPrmsBldg(proposer.getCorrespondenceAddress1());
// addrC.setCpaaFltFlrDoorBlk(proposer.getCorrespondenceAddress2());
// addrC.setCpaaRdStreetLn(proposer.getCorrespondenceAddress3());
// addrC.setCpaaVillArLoclty(proposer.getCorrespondenceAddress4());
// addrC.setCpaaBlkTlukSubDivTwn(proposer.getCorrespondenceAddress5());
// addrC.setCpaaCountryCd(proposer.getCorrespondenceCountry());
// addrC.setCpaaAddrProof(proposer.getCorrespondenceAddressProof());
// if
// (proposer.getCorrespondenceCountry().equalsIgnoreCase(NIRConstants.CNTY_IND)
// || proposer.getCorrespondenceCountry().equalsIgnoreCase("101")) {
// addrC.setCpaaPinCd(proposer.getCorrespondencePinCode());
// addrC.setCpaaStateCd(proposer.getCorrespondenceStateDD());
// LOGGER.info("Correspondence Indian State Cd-->" +
// proposer.getCorrespondenceStateDD()
// + " & Pincode---->" + proposer.getCorrespondencePinCode());
// } else {
// // addrC.setCpaaPinCd(proposer.getCorrespondencePinCode());
// addrC.setCpaaPinCd(proposer.getCorrespondencePinCodeExt());
// // addrC.setCpaaOthrState(proposer.getCorrespondenceStateDD());
// addrC.setCpaaOthrState(proposer.getCorrespondenceStateText());
// addrC.setCpaaStateCd("00");
// LOGGER.info("Correspondence Indian State Name-->" +
// proposer.getCorrespondenceStateDD()
// + " & Pincode---->" + proposer.getCorrespondencePinCode());
// }
// addrC.setCpaaCrtBy(loginUser);
// addrC.setCpaaCrtDate(Calendar.getInstance());
// try {
// LOGGER.info("Tx id is-->" + txId);
// if (txId != null && !txId.trim().equalsIgnoreCase(NIRConstants.BLANK_STRING))
// {
// addrC.setCpaaTxId(Long.valueOf(txId));
// } else {
// LOGGER.warn("Tx id not set in CripEiaPrpAthrpAddr for P3-->");
// }
// } catch (Exception e) {
// LOGGER.fatal("Exception while setting tx id in CripEiaPrpsrAthrp-->" +
// e.getMessage());
// }
// addrC.setCpaaIpAddress(ipAddress);
// addrSet.add(addrC);
// LOGGER.info("Correspondence Address set and added to set--->");
// }
// LOGGER.info("Returning from getApplAndAuthRepAddressSet method-->");
// return addrSet;
// } catch (Exception e) {
// LOGGER.fatal("Exception occured while setting EiaPrpAthrpAddr domain--->" +
// e.getMessage());
// LOGGER.fatal("<--------- Exception Start ---------->");
// for (StackTraceElement ste : e.getStackTrace()) {
// LOGGER.fatal(ste);
// }
// LOGGER.fatal("<--------- Exception End ------------>");
// e.printStackTrace();
// }
// return null;
// }
//
// public CripUsrMstr createUser(String eIA, AccountOpeningFormBean checkerBean,
// String loginUser) {
// LOGGER.info("In createUser method of CheckerServiceImpl with following
// data----->");
// LOGGER.info("IsExternal--->" + checkerBean.getIsExternal());
// LOGGER.info("User Id------>" +
// checkerBean.getProposalDetailBeanList().get(0).getUserId());
// LOGGER.info("Password----->" +
// checkerBean.getProposalDetailBeanList().get(0).getPassword());
// CripUsrMstr usr = null;
// try {
// usr = new CripUsrMstr();
// if (checkerBean.getProposalDetailBeanList().get(0).getUserId() == null ||
// checkerBean
// .getProposalDetailBeanList().get(0).getUserId().trim().equals(NIRConstants.BLANK_STRING))
// {
// LOGGER.warn("Going for new user id and pwd generation-->");
// String userId;
// userId = checkerBean.getAckNo();//
// generateUserId(checkerBean.getProposalDetailBeanList().get(0).getFirstNameOfCustomer(),
// // checkerBean.getProposalDetailBeanList().get(0).getLastNameOfCustomer());
// String sysGenPassword = randomStringGenerator();
// String DBPassword = sysGenPassword;
// // String pubMod =
// // popCommonService.getParamValForParamCd(NIRConstants.PUB_KEY_MOD);
// // String pubExp =
// // popCommonService.getParamValForParamCd(NIRConstants.PUB_KEY_EXP);
// String pubMod =
// cripSysParamRepo.getParamValForParamCd(NIRConstants.PUB_KEY_MOD);
// String pubExp =
// cripSysParamRepo.getParamValForParamCd(NIRConstants.PUB_KEY_EXP);
// Encryption encryption = new Encryption(pubMod, pubExp);
// try {
// DBPassword = encryption.encrypt(DBPassword, Encryption.getPublicKey());
// } catch (Exception e) {
// LOGGER.fatal("Exception occured while getting encrypted password in
// createUser. Exception is :"
// + e.getMessage());
// e.printStackTrace();
// }
// // LOG.info("User Id-->"+userId + " & Random password-->"+sysGenPassword+ " &
// // Encoded password-->"+DBPassword);
// LOGGER.info("Going to set data for userId-->" + userId);
// usr.setCumLoginId(userId.toLowerCase());
// usr.setCumPwd(DBPassword);
// } else {
// LOGGER.warn("Using existing user id and pwd-->");
//
// //
// usr.setCumLoginId(checkerBean.getProposalDetailBeanList().get(0).getUserId().trim().toLowerCase());
// usr.setCumLoginId(
// checkAndgenerateUserId(checkerBean.getProposalDetailBeanList().get(0).getFirstNameOfCustomer(),
// checkerBean.getProposalDetailBeanList().get(0).getLastNameOfCustomer(),
// checkerBean.getProposalDetailBeanList().get(0).getUserId().trim().toLowerCase()));
// usr.setCumPwd(null);
// //
// usr.setCumPwd(checkerBean.getProposalDetailBeanList().get(0).getPassword().trim());
// }
// usr.setCumBadLoginCnt(0);
// Calendar expDate = Calendar.getInstance();
// expDate.add(Calendar.DAY_OF_MONTH, 60);
// // FTR 5369 Start
// // usr.setCumPwdExprDate(expDate.getTime()); // pwd exp date= 60 days after
// // current date
// // FTR 5369 End
// usr.setCumPwdExprFlg(4); // pwd exp flag = 4 , new user creation
// usr.setCumStatId("01");
// usr.setCumEnttCd("01"); // Policy Holder entity code
// usr.setCumRlCd(9); // Policy Holder Role code
// usr.setCumApOrIcCd(null);
// usr.setCumApOrIcBrnchCd(null);
// usr.setCumCertSno(null);
// usr.setCumCaId(null);
// usr.setCumCertExpDt(null);
// usr.setCumFrstNm(checkerBean.getProposalDetailBeanList().get(0).getFirstNameOfCustomer());
// usr.setCumUsrLoggedIn(0);
// usr.setCumAuthType(NIRConstants.PWD_TYPE); // AUTH TYPE ADDED
// usr.setCumCrtBy(loginUser);
// usr.setCumCrtDate(Calendar.getInstance());
// usr.setCumAuthorizedBy(null);
// // usr.setCumAuthorizedBy(sysGenPassword);
// usr.setCumLstNm(checkerBean.getProposalDetailBeanList().get(0).getLastNameOfCustomer());
// usr.setCumMoblNum(checkerBean.getProposalDetailBeanList().get(0).getMobileNo());
// usr.setCumEmailId(checkerBean.getProposalDetailBeanList().get(0).getEmailId());
// return usr;
// } catch (Exception e) {
// LOGGER.fatal("Exception in createUser method of CheckerServiceImpl :" +
// e.getMessage());
// e.printStackTrace();
// LOGGER.fatal("<--------- Exception Start ---------->");
// for (StackTraceElement ste : e.getStackTrace()) {
// LOGGER.fatal(ste);
// }
// LOGGER.fatal("<--------- Exception End ------------>");
// usr = null;
// }
// return usr;
// }
//
// public String randomStringGenerator() {
// int i = 1;
// final Random random = new Random(System.currentTimeMillis() + i);
// byte len = 10;
// byte[] buf = new byte[len * 4];
// char[] text = new char[len];
// int c = 0;
// while (c < text.length) {
// random.nextBytes(buf);
// for (byte b : buf) {
// if ((b >= 'a' && b <= 'z' || (b >= 'A' && b <= 'Z')) && b != 'O' && b != 'o'
// && b != 'l' && b != 'L'
// && b != 'i' && b != 'I') {
// text[c++] = (char) b;
// if (c >= text.length) {
// break;
// }
// }
// }
// }
// String genString = (new String(text)).toUpperCase();
// LOGGER.info("Random string generated-->" + genString);
// return genString;
// }
//
// public String checkAndgenerateUserId(String fstName, String lstName, String
// userId) {
// try {
// LOGGER.info("In checkAndgenerateUserId method with UserID ---> " + userId + "
// & FstName ---> " + fstName
// + " & LstName--->" + lstName);
// if (chkUserId(userId.toString().toLowerCase())) {
// LOGGER.info("In checkAndgenerateUserId method with UserID ---> " + userId + "
// NOT Present in DB");
// return userId;
// } else {
// LOGGER.info("In checkAndgenerateUserId method with UserID ---> " + userId
// + " Present in DB GENERTING NEW USER ID");
// return generateUserId(fstName, lstName);
// }
// } catch (Exception e) {
// LOGGER.fatal("Exception occured in generateUserId method--->" +
// e.getMessage());
// LOGGER.fatal("<--------- Exception Start ---------->");
// for (StackTraceElement ste : e.getStackTrace()) {
// LOGGER.fatal(ste);
// }
// LOGGER.fatal("<--------- Exception End ------------>");
// e.printStackTrace();
// }
// return null;
//
// }
// // NEW Code 19012015 End
//
// public String generateUserId(String fstName, String lstName) {
// /*
// * try { LOG.info("In generateUserId method with FstName --->" + fstName +
// * " & LstName--->" + lstName); StringBuffer str = new StringBuffer();
// * StringBuffer userId = new StringBuffer(); if ((fstName != null) && (lstName
// * != null)) { //Changes done by susmit on 26-04-2016 for Bug 6250 fstName =
// * fstName.replace("'", "").replace(".", "").replace(" ", "").trim(); lstName
// =
// * lstName.replace("'", "").replace(".", "").replace(" ", "").trim();
// //Changes
// * done by susmit on 26-04-2016 for Bug 6250
// * LOG.info("In generateUserId method with FstName --->" + fstName +
// * " & LstName--->" + lstName); if (fstName.length() >= 3) {
// * str.append(fstName.substring(0, 3)); if (lstName.length() >= 3) {
// * str.append(lstName.substring(0, 3)); } else { str.append("000"); } } else {
// * str.append(fstName.substring(0, fstName.length())); if (lstName.length() >=
// * 3) { str.append(lstName.substring(0, 3) + "00"); } else {
// str.append("0000");
// * } } } else if (fstName != null && lstName == null) { fstName =
// * fstName.replace("'", "").replace(".", "").trim();
// * LOG.info("In generateUserId method with FstName --->" + fstName); if
// * (fstName.length() >= 3) { str.append(fstName.substring(0, 3) + "000"); }
// else
// * { if (fstName.length() == 1) { str.append(fstName.substring(0,
// * fstName.length()) + "00000"); } else { str.append(fstName.substring(0,
// * fstName.length()) + "0000"); } } } else { return null; } do { userId = str;
// * userId.append(getRandomVal()); } while
// * (!chkUserId(userId.toString().toLowerCase()));
// * LOG.info("Returning from generateUserId method with User Id-->" +
// * userId.toString().toLowerCase()); return userId.toString().toLowerCase(); }
// * catch (Exception e) {
// * LOG.fatal("Exception occured in generateUserId method--->" +
// e.getMessage());
// * LOG.fatal("<--------- Exception Start ---------->"); for (StackTraceElement
// * ste : e.getStackTrace()) { LOG.fatal(ste); }
// * LOG.fatal("<--------- Exception End ------------>"); e.printStackTrace(); }
// * return null;
// *
// */
// LOGGER.info("In generateUserId method with FstName --->" + fstName + " &
// LstName--->" + lstName);
// StringBuffer str = new StringBuffer();
// StringBuffer userId = new StringBuffer();
// try {
//
// if (fstName != null && !fstName.isEmpty()) {
// LOGGER.info("First Name - " + fstName);
// LOGGER.info("Last Name - " + lstName);
//
// fstName = fstName.trim();
// lstName = lstName.trim();
//
// if (lstName == null || lstName.length() < 3) {
//
// String[] firstNameArray = fstName.split(" ");
// LOGGER.info("First Name split for multiple word" +
// Arrays.toString(firstNameArray));
//
// if (firstNameArray.length > 1) {
// if (firstNameArray[0].length() >= 3) {
// LOGGER.info("First word greater than 3");
// str.append(firstNameArray[0].substring(0, 3));
// if (firstNameArray[1].length() >= 3) {
// str.append(firstNameArray[1].substring(0, 3));
// } else {
// str.append(getSaltString());
// }
// } else {
// LOGGER.info("First word less than 3");
// str.append(getSaltString());
// if (firstNameArray[1].length() >= 3) {
// str.append(firstNameArray[1].substring(0, 3));
// } else {
// str.append(getSaltString());
// }
// }
//
// } else {
// if (fstName.length() >= 3) {
// str.append(fstName.substring(0, 3));
// str.append(getSaltString());
// } else {
// str.append(getSaltString());
// str.append(getSaltString());
//
// }
// }
//
// } else {
// LOGGER.info("Last name is greater than or equal 3 ");
// if (fstName.length() >= 3) {
// str.append(fstName.substring(0, 3));
// } else {
// str.append(getSaltString());
// }
// str.append(lstName.substring(0, 3));
// }
//
// } else {
// LOGGER.info("First Name is mandatory");
// return null;
// }
//
// do {
// StringBuffer newSTR = new StringBuffer(str);
// userId = newSTR;
// userId.append(getRandomVal());
// } while (!chkUserId(userId.toString().toLowerCase()));
// } catch (Exception e) {
// LOGGER.fatal("Exception in generateUserId " + e.getMessage());
// e.printStackTrace();
// try {
// throw new Exception("Exception in generateUserId");
// } catch (Exception e1) {
// LOGGER.error("Exception in generate UserID 1251 " + e1.getMessage());
// e1.printStackTrace();
// }
// }
//
// LOGGER.info("Returning from generateUserId method with User Id-->" +
// userId.toString().toLowerCase());
// return userId.toString().toLowerCase();
//
// }
//
// public int getRandomVal() {
// return (new Random().nextInt(9999 - 1000) + 1000);
// }
//
// public boolean chkUserId(String userId) {
// LOGGER.info("In chkUserId method with userId-->" + userId);
// boolean returnVal = false;
// try {
// long count = isUserIdPresent(userId);
// // long count = makerCheckerDao.isUserIdPresent(userId);
// if (count == 0) {
// LOGGER.info("User Id-->" + userId + " not found in DB");
// returnVal = true;
// } else {
// LOGGER.fatal("User Id-->" + userId + " found in DB");
// returnVal = false;
// }
// } catch (Exception e) {
// LOGGER.error("Exception occured in chkUserId function :" + e.getMessage());
// LOGGER.fatal("<--------- Exception Start ---------->");
// for (StackTraceElement ste : e.getStackTrace()) {
// LOGGER.fatal(ste);
// }
// LOGGER.fatal("<--------- Exception End ------------>");
// e.printStackTrace();
// }
// return returnVal;
// }
//
// public long isUserIdPresent(String userId) {
// // Session session = null;
// // Transaction tx = null;
// long userIdCount = 100;
// try {
// // session = sessionFactory.getCurrentSession();
// // tx = session.beginTransaction();
// // Query query = session.getNamedQuery("CripUsrMstr.isUserIdPresent")
// // .setParameter(0, userId.toLowerCase());
//
// userIdCount = isUserIdPresent(userId.toLowerCase());
// // userIdCount = (Long) query.uniqueResult();
// } catch (NoResultException nre) {
// LOGGER.warn("No Entries Found for User Id-->" + userId);
// } catch (Exception e) {
// LOGGER.fatal("Exception in isUserIdPresent method of EIACommonDaoImpl :" +
// e.getMessage());
// e.printStackTrace();
// }
// LOGGER.info("Returning from isUserIdPresent method with count :" +
// userIdCount);
// return userIdCount;
// }
//
// private String getSaltString() {
// String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
// StringBuilder salt = new StringBuilder();
// Random rnd = new Random();
// while (salt.length() < 3) { // length of the random string.
// int index = (int) (rnd.nextFloat() * SALTCHARS.length());
// salt.append(SALTCHARS.charAt(index));
// }
// String saltStr = salt.toString();
// return saltStr;
//
// }
//
// public String generateEiaNumber() {
// LOGGER.info("In getEiaSequenceNumberWithLock method-->");
// long nirSeqeunceNumber = 0;
// String idRenegerated = "";
// // Long idRenegeratedLong;
// int increment = 1;
// String newSequence = "";
// CripSeqGnrtr cripSeqGnrtr = null;
// Session session = null; // HibernateUtilBV.getSessionFactory().openSession();
// Transaction trxn = null; // session.beginTransaction();
// SQLQuery query = null;
// String formatStr = "";
// String dbNewSeq = "";
// String lengthOfSeq = "0";
// String returnSequence = "";
// String seqLength = "";
//
// try {
//
// session = SESSIONFACTORY.openSession();
// trxn = session.beginTransaction();
// /*
// * Criteria codeMater = session.createCriteria(CripSeqGnrtr.class);
// * codeMater.add(Restrictions.eq("csgGenKey", "EIA_SEQ"));
// * codeMater.setLockMode(LockMode.PESSIMISTIC_WRITE); cripSeqGnrtr =
// * (CripSeqGnrtr) codeMater.uniqueResult(); nirSeqeunceNumber =
// * Long.valueOf(cripSeqGnrtr.getCsgGenValue()); returnSequence =
// * cripSeqGnrtr.getCsgGenValue(); newSequence =
// * String.valueOf((nirSeqeunceNumber + increment)); lengthOfSeq =
// * String.valueOf(cripSeqGnrtr.getCsgValueLen()); formatStr = "%0" +
// lengthOfSeq
// * + "d"; if (newSequence.length() <
// * Integer.parseInt(String.valueOf(cripSeqGnrtr.getCsgValueLen()))) { dbNewSeq
// =
// * String.format(formatStr, Long.parseLong(newSequence)); } else { dbNewSeq =
// * String.format(formatStr, Long.parseLong("1")); }
// */
//
// // Above code commented and added native query to get EIA number due to
// // synchronization issue on production
// // AMol B. 16 Jan 2019
// String key = "EIA_SEQ";
// SQLQuery codeMater = session
// .createSQLQuery("select * from crip_seq_gnrtr where csg_gen_key = '" + key +
// "' for update");
//
// List<Object[]> objList = codeMater.list();
//
// System.out.println("Object List for get EIA number :: " +
// objList.toString());
//
// Object[] obj = objList.get(0);
//
// if (null != obj) {
// nirSeqeunceNumber = Long.valueOf(obj[1].toString());
// returnSequence = obj[1].toString();
// seqLength = obj[2].toString();
// cripSeqGnrtr = new CripSeqGnrtr();
// newSequence = String.valueOf((nirSeqeunceNumber + increment));
// LOGGER.info("Current_Sequence:: " + returnSequence);
// LOGGER.info("New_Sequence:: " + newSequence);
// LOGGER.info("Length of Sequence:: " + seqLength);
// formatStr = "%0" + seqLength + "d";
//
// LOGGER.info("String Format :: " + formatStr);
// if (newSequence.length() < Integer.parseInt(seqLength)) {
// dbNewSeq = String.format(formatStr, Long.parseLong(newSequence));
// } else {
// dbNewSeq = String.format(formatStr, Long.parseLong("1"));
// }
// cripSeqGnrtr.setCsgGenKey(key);
// cripSeqGnrtr.setCsgGenValue(dbNewSeq);
// // session.update(cripSeqGnrtr);
//
// LOGGER.info("Updating table crip_seq_gnrt with below data");
// LOGGER.info("Key :: " + key);
// LOGGER.info("New Sequence :: " + dbNewSeq);
// SQLQuery updateTablewithNewSequence = session
// .createSQLQuery("update crip_seq_gnrtr set CSG_GEN_VALUE = ? where
// csg_gen_key = ? ");
// updateTablewithNewSequence.setParameter(0, dbNewSeq);
// updateTablewithNewSequence.setParameter(1, key);
// LOGGER.info("Query to be execute :: " +
// updateTablewithNewSequence.getQueryString());
// int count = updateTablewithNewSequence.executeUpdate();
// LOGGER.info("Number of rows updated in table crip_seq_gnrtr :: " + count);
// } else {
// return null;
// }
// // End of new code 16 Jan 2019
//
// trxn.commit();
// } catch (Exception e) {
// LOGGER.fatal("Exception in getEiaSequenceNumberWithLock-->" +
// e.getMessage());
// e.printStackTrace();
// trxn.rollback();
// } finally {
// if (session != null && session.isOpen()) {
// session.close();
// }
// }
// LOGGER.info("getEiaSequenceNumberWithLock Seq no-->" + nirSeqeunceNumber);
// LOGGER.info("getEiaSequenceNumberWithLock Seq no Formarted -->" +
// returnSequence);
//
// String eIANumberSeq = "";
// String eiaNumber = null;
// try {
// eIANumberSeq = returnSequence;
// eiaNumber = calcEia(eIANumberSeq);
// } catch (Exception e) {
// LOGGER.error("EXCEPTION IN getEiaSequenceNumberWithLock : " +
// e.getMessage());
// }
//
// return eiaNumber;
// }
//
// public static String calcEia(String digStr) {
// final int[][] sumTable = { { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 }, { 0, 2, 4, 6, 8,
// 1, 3, 5, 7, 9 } };
// int sum = 0, flip = 0, rem = 0;
// for (int i = digStr.length() - 1; i >= 0; i--) {
// sum += sumTable[flip++ & 0x1][Character.digit(digStr.charAt(i), 10)];
// }
// rem = sum % 10;
// StringBuilder SB = new StringBuilder(digStr);
// SB.insert(0, "1");
// SB.append(rem);
// return SB.toString();
// }
//
// }