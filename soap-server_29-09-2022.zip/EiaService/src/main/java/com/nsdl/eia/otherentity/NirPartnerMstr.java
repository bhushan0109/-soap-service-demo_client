package com.nsdl.eia.otherentity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
//@Data
@Entity
@Table(name = "nir_partner_config")
public class NirPartnerMstr implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "npc_id")
	private Integer npccId;

	@Column(name = "npc_partner_id")
	private String partnerId;

	@Column(name = "npc_branch_id")
	private String branchId;

	@Column(name = "npc_partner_name")
	private String partnerNameUrl;

	@Column(name = "npc_access_type")
	private String accessType;

	@Column(name = "npc_user_id")
	private String userId;

	@Column(name = "npc_password")
	private String password;

	@Column(name = "npc_secure_key")
	private String secureKey;

	@Column(name = "npc_link_email_sent")
	private String linkEmailSent;

	@Column(name = "npc_link_sms_sent")
	private String linkSmsSent;

	@Column(name = "npc_webresponse_url")
	private String webResponseUrl;

	/*
	 * @Column(name="npc_ip_address") private String ipAddress;
	 * 
	 * @Column(name="npc_ip_region") private String ipRegion;
	 */

	public String getWebResponseUrl() {
		return webResponseUrl;
	}

	public void setWebResponseUrl(String webResponseUrl) {
		this.webResponseUrl = webResponseUrl;
	}

	@OneToMany(mappedBy = "nirPartnerMstr2", cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.EAGER)
	List<NirPartnerIpMapping> nirPartnerIpMapping;

	@Column(name = "npc_activation_date")
	private String actDate;

	@Column(name = "npc_effective_date")
	private String effDate;

	@Column(name = "npc_createddate")
	private Date createdDate;

	@Column(name = "npc_createdby")
	private String createdBy;

	@Column(name = "npc_updateddate")
	private Date updatedDate;

	@Column(name = "npc_updatedby")
	private String updatedBy;

	public Integer getNpccId() {
		return npccId;
	}

	public void setNpccId(Integer npccId) {
		this.npccId = npccId;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getPartnerNameUrl() {
		return partnerNameUrl;
	}

	public void setPartnerNameUrl(String partnerNameUrl) {
		this.partnerNameUrl = partnerNameUrl;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecureKey() {
		return secureKey;
	}

	public void setSecureKey(String secureKey) {
		this.secureKey = secureKey;
	}

	public String getLinkEmailSent() {
		return linkEmailSent;
	}

	public void setLinkEmailSent(String linkEmailSent) {
		this.linkEmailSent = linkEmailSent;
	}

	public String getLinkSmsSent() {
		return linkSmsSent;
	}

	public void setLinkSmsSent(String linkSmsSent) {
		this.linkSmsSent = linkSmsSent;
	}

	public List<NirPartnerIpMapping> getNirPartnerIpMapping() {
		return nirPartnerIpMapping;
	}

	public void setNirPartnerIpMapping(List<NirPartnerIpMapping> nirPartnerIpMapping) {
		this.nirPartnerIpMapping = nirPartnerIpMapping;
	}

	public String getActDate() {
		return actDate;
	}

	public void setActDate(String actDate) {
		this.actDate = actDate;
	}

	public String getEffDate() {
		return effDate;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "NirPartnerMstr [npccId=" + npccId + ", partnerId=" + partnerId + ", branchId=" + branchId
				+ ", partnerNameUrl=" + partnerNameUrl + ", accessType=" + accessType + ", userId=" + userId
				+ ", password=" + password + ", secureKey=" + secureKey + ", linkEmailSent=" + linkEmailSent
				+ ", linkSmsSent=" + linkSmsSent + ", webResponseUrl=" + webResponseUrl + ", nirPartnerIpMapping="
				+ nirPartnerIpMapping + ", actDate=" + actDate + ", effDate=" + effDate + ", createdDate=" + createdDate
				+ ", createdBy=" + createdBy + ", updatedDate=" + updatedDate + ", updatedBy=" + updatedBy + "]";
	}

	
	/*
	 * public String getIpAddress() { return ipAddress; }
	 * 
	 * public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }
	 * 
	 * public String getIpRegion() { return ipRegion; }
	 * 
	 * public void setIpRegion(String ipRegion) { this.ipRegion = ipRegion; }
	 */


}
