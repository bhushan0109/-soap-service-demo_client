package com.nsdl.eia.xmBean;

import java.io.Serializable;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.nsdl.eia.constants.NIRConstants;

//import com.ndml.nir.common.constants.NIRConstants;

public class AccountOpeningFormBean implements Serializable {
	private static final long serialVersionUID = 1L;

	
	//CR 5301 Start
	private String userName;
	
	private String id;

	private String isExternal;

	private String ekycFlag = "N";

	private String isOnline;

	private String otpForUid;

	private String isApSearch;

	private String captchaText;

	private String applNo;

	private String ackNo;

	private String eiaNo;

	private String onlineEiaPDFPath;

	private String entityCode;

	private String entityName;

	private String roleCode;

	private String roleName;

	private String pan;

	private String uid;

	private String nameOfCustomer;

	private String accountType;

	private String accountTypeOthers;

	private String accountCategory;
	
	private String kycCategory;
	
	private String accountStatus;
	
	private String authRepReuiredDataPresent = "N";
	
	private String authRepLoginCreation = "N";

	private String applicationNo;

	private String formSubDate;

	private String ackNoCreDate;

	private String pendDays;

	private String bankAccountType;

	private String bankAccountNo;

	private String bankName;

	private String bankNameOthers;

	private String bankId;

	private String bankMICRCode;

	private String bankIFSCCode;

	private String bankCancelChk;

	private String bankAddress1;

	private String bankAddress2;

	private String bankAddress3;

	private String bankAddress4;

	private String bankPinCode;

	private String bankState;

	private String bankCountry;

	private String toDate;

	private String fromDate;

	private String maker;

	private String acceptReasonText;

	private String rejectReasonID;

	private String rejectReasonOtherText;

	private String addressSameAsPermanentradio0;

	private String addressSameAsPermanentradio1;

	private String addressSameAsPermanentradio2;

	private String radio3SecAddSame;

	private String radio4AuthAddSame;
	
	private String sentMailToAuth;

	private String eiaToBeUpdated;

	private String icCd;
	
	private String insuranceCompanyType;
	
	private String insuranceCompanyTypeDescription;

	private String icName;

	private String icBranchCd;

	private String icBranchName;

	private String isIcBranchHO;

	private String apCd;

	private String apName;

	private String apBranchCd;

	private String apBranchName;

	private String isApBranchHO;

	private String apOrICCode;

	private String apOrICName;

	private String apOrICBranchCode;

	private String apOrICBranchName;

	private String isApOrIcBranchHO;

	private String selectedApOrIcBranchCode = NIRConstants.BLANK_STRING;

	private String selectedApOrIcBranchName = NIRConstants.BLANK_STRING;

	private String selectedApOrIcBranchUserCode = NIRConstants.BLANK_STRING;

	private String selectedApOrIcBranchUserName = NIRConstants.BLANK_STRING;

	private String checkerAction;

	private String signature;

	private String formData;

	private String changeApplAccCatAndType;

	private String changeApplName;

	private String changeApplFatherOrHusName;

	private String changeApplPanOrUid;

	private String changeApplPan;

	private String changeApplUid;
	
	private String changeApplUserid; // newly added to display user id on change request page Amol B. 6 March 2019

	private String changeApplPermanentAddress;

	private String changeApplCorrAddress;

	private String changeApplBankDtl;

	private String changeApplContactDtl;

	private String changeApplDOB;

	private String changeApplGender;

	private String changeApplDOBProof;

	private String changeApplTelNo;

	private String deleteApplTelNo;

	private String changeApplAltTelNo;

	private String deleteApplAltTelNo;

	private String changeApplMobileNo;

	private String deleteApplMobileNo;

	private String changeApplFAXNo;

	private String deleteApplFAXNo;

	private String changeApplEmailId;

	private String deleteApplEmailId;

	private String changeApplAltEmailId;

	private String deleteApplAltEmailId;

	private String changeToNewAuthRep;

	private String changeAuthRepName;

	private String changeAuthRepFatherOrHusName;

	private String changeAuthRepPanOrUid;

	private String changeAuthRepPan;

	private String changeAuthRepUid;

	private String changeAuthRepPermanentAddress;

	private String changeAuthRepContactDtl;

	private String changeAuthRepTelNo;

	private String deleteAuthRepTelNo;

	private String changeAuthRepAltTelNo;

	private String deleteAuthRepAltTelNo;

	private String changeAuthRepMobileNo;

	private String deleteAuthRepMobileNo;

	private String changeAuthRepFAXNo;

	private String deleteAuthRepFAXNo;

	private String changeAuthRepEmailId;

	private String deleteAuthRepEmailId;

	private String changeAuthRepAltEmailId;

	private String deleteAuthRepAltEmailId;

	private String hidden1;

	private String hidden2;

	private String flag1;

	private String flag2;
	
	private String partnerType;
	
	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}		

/*	public List<CorporateDesignPersonInfo> getCorporateDesignPersonInfo() {
		return corporateDesignPersonInfo;
	}

	public void setCorporateDesignPersonInfo(List<CorporateDesignPersonInfo> corporateDesignPersonInfo) {
		this.corporateDesignPersonInfo = corporateDesignPersonInfo;
	}*/

	private String numberOfApplicants;

	private List<ProposalDetailBean> proposalDetailBeanList;

	// private List<String> linkList = new ArrayList<String>();
	private String challengeResponse = NIRConstants.BLANK_STRING;

	private String ipAddress = NIRConstants.BLANK_STRING;

	private String cultId = NIRConstants.BLANK_STRING;

	private String trnxId = NIRConstants.BLANK_STRING;

	private String fileId = NIRConstants.BLANK_STRING;

	private String fileName = NIRConstants.BLANK_STRING;

	private String formStatus;

	private String formStatusDesc;

	private String ekycOtpResponseCode;

	private String ekycOtpResponseDesc;

	private String flgNewCr;
	
	private String dataStoringByAp = "N";
	
	private String deactiveIcName;
	
	private String pageNumber = "0";
	
	/*
	 * For Pgination Code
	 * 02012015 Start
	 */
	private int pageSize = 0;

	private int totalSize = 0;
	
	private String firstPageInd;
	
    private String lastPageInd;
    
    private int pageNum;
    
    private int pageNumPlus;
    
    private long numberOfPages;
    
    //FTR 5302
    private String otpForMobile;
    private String otpForEmail;
    private String otpGenerateDate;
    private String otpSelected;
    private String otpResetAllow = "N";
    
    //03082015 Start
    private String isPartialOrFinalFlag = "01";
    //03082015 End
    
    //CR 6345 Ajit code Start
    private String lotNumber;
    private String sourcedBy;
    private String isAadharBased;
    private String webParameter;   /**** Added By Mayur J on 28-02-2019 It is the part of Insurance company web-site hit *****/
    
    public String getWebParameter() {
		return webParameter;
	}

	public void setWebParameter(String webParameter) {
		this.webParameter = webParameter;
	}
	/************* Added By Mayur J on 11-01-2019 To stored name compare score ***************/
/*    private String nameScored;
    
    
	public String getNameScored() {
		return nameScored;
	}

	public void setNameScored(String nameScored) {
		this.nameScored = nameScored;
	}
    /*****************************************************************************************/
	/* Added By Mayur J on 20-07-2018 */
    private String vidToken;
	public String getVidToken() {
		return vidToken;
	}

	public void setVidToken(String vidToken) {
		this.vidToken = vidToken;
	}
	
	/*********************************************/

    //23052018 Start Swapnali  code for Corporate EIA
  //  private List<String> entityType;
    private String entityType;
  
	private String entityTypDtls; 
	private String dateOfRecpt; 
	private String aadharNo;
	private String rgstrnum;
	private String incropDate;
	private String corporateAddress1;
	private String corporateAddress2;
	private String corporateAddress3;
	private String corporateLandmark;
	private String corporateCity;
	private String corporateCountry;
	private String corporateState;
	private String corporatePincode;
	private String corporateEmail;
	private String corporateTelNo;
	
	private String corporateDocTyp;
	private String corporateDocOthrs;
	private String corporateDoc;
	private CommonsMultipartFile corporateDocPath;
	private String representativeDocTyp;
	private String representativeDocOthrs;
	private String representativeDoc;
	private String designatPersonPan;
	private String designatPersonAadhar;
	private String designatPersonName;
	private String designatPersonCntcNo;
	private String designatPersonEmail;
	private String designatPersonTelNo;
	private String designatLandline;
	
	private String docType;
	private String docName;
	
	//private List<CorporateDesignPersonInfo> corporateDesignPersonInfo;


	public CommonsMultipartFile getCorporateDocPath() {
		return corporateDocPath;
	}

	public void setCorporateDocPath(CommonsMultipartFile corporateDocPath) {
		this.corporateDocPath = corporateDocPath;
	}

	public String getDesignatPersonPan() {
		return designatPersonPan;
	}

	public void setDesignatPersonPan(String designatPersonPan) {
		this.designatPersonPan = designatPersonPan;
	}

	public String getDesignatPersonAadhar() {
		return designatPersonAadhar;
	}

	public void setDesignatPersonAadhar(String designatPersonAadhar) {
		this.designatPersonAadhar = designatPersonAadhar;
	}

	public String getDesignatPersonName() {
		return designatPersonName;
	}

	public void setDesignatPersonName(String designatPersonName) {
		this.designatPersonName = designatPersonName;
	}

	public String getDesignatPersonCntcNo() {
		return designatPersonCntcNo;
	}

	public void setDesignatPersonCntcNo(String designatPersonCntcNo) {
		this.designatPersonCntcNo = designatPersonCntcNo;
	}

	public String getDesignatPersonEmail() {
		return designatPersonEmail;
	}

	public void setDesignatPersonEmail(String designatPersonEmail) {
		this.designatPersonEmail = designatPersonEmail;
	}

	public String getDesignatPersonTelNo() {
		return designatPersonTelNo;
	}

	public void setDesignatPersonTelNo(String designatPersonTelNo) {
		this.designatPersonTelNo = designatPersonTelNo;
	}

	public String getDesignatLandline() {
		return designatLandline;
	}

	public void setDesignatLandline(String designatLandline) {
		this.designatLandline = designatLandline;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	//CR 6345 Ajit Code End
	public String getDeactiveIcName() {
		return deactiveIcName;
	}

	public void setDeactiveIcName(String deactiveIcName) {
		this.deactiveIcName = deactiveIcName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getApplNo() {
		return applNo;
	}

	public void setApplNo(String applNo) {
		this.applNo = applNo;
	}

	public String getAckNo() {
		return ackNo;
	}

	public void setAckNo(String ackNo) {
		this.ackNo = ackNo;
	}

	public String getEiaNo() {
		return eiaNo;
	}

	public void setEiaNo(String eiaNo) {
		this.eiaNo = eiaNo;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getNameOfCustomer() {
		return nameOfCustomer;
	}

	public void setNameOfCustomer(String nameOfCustomer) {
		this.nameOfCustomer = nameOfCustomer;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountTypeOthers() {
		return accountTypeOthers;
	}

	public void setAccountTypeOthers(String accountTypeOthers) {
		this.accountTypeOthers = accountTypeOthers;
	}

	public String getAccountCategory() {
		return accountCategory;
	}

	public void setAccountCategory(String accountCategory) {
		this.accountCategory = accountCategory;
	}

	public String getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getFormSubDate() {
		return formSubDate;
	}

	public void setFormSubDate(String formSubDate) {
		this.formSubDate = formSubDate;
	}

	public String getAckNoCreDate() {
		return ackNoCreDate;
	}

	public void setAckNoCreDate(String ackNoCreDate) {
		this.ackNoCreDate = ackNoCreDate;
	}

	public String getPendDays() {
		return pendDays;
	}

	public void setPendDays(String pendDays) {
		this.pendDays = pendDays;
	}

	public String getBankAccountType() {
		return bankAccountType;
	}

	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}

	public String getBankAccountNo() {
		return bankAccountNo;
	}

	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankNameOthers() {
		return bankNameOthers;
	}

	public void setBankNameOthers(String bankNameOthers) {
		this.bankNameOthers = bankNameOthers;
	}

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getBankMICRCode() {
		return bankMICRCode;
	}

	public void setBankMICRCode(String bankMICRCode) {
		this.bankMICRCode = bankMICRCode;
	}

	public String getBankIFSCCode() {
		return bankIFSCCode;
	}

	public void setBankIFSCCode(String bankIFSCCode) {
		this.bankIFSCCode = bankIFSCCode;
	}

	public String getBankCancelChk() {
		return bankCancelChk;
	}

	public void setBankCancelChk(String bankCancelChk) {
		this.bankCancelChk = bankCancelChk;
	}

	public String getBankAddress1() {
		return bankAddress1;
	}

	public void setBankAddress1(String bankAddress1) {
		this.bankAddress1 = bankAddress1;
	}

	public String getBankAddress2() {
		return bankAddress2;
	}

	public void setBankAddress2(String bankAddress2) {
		this.bankAddress2 = bankAddress2;
	}

	public String getBankAddress3() {
		return bankAddress3;
	}

	public void setBankAddress3(String bankAddress3) {
		this.bankAddress3 = bankAddress3;
	}

	public String getBankAddress4() {
		return bankAddress4;
	}

	public void setBankAddress4(String bankAddress4) {
		this.bankAddress4 = bankAddress4;
	}

	public String getBankPinCode() {
		return bankPinCode;
	}

	public void setBankPinCode(String bankPinCode) {
		this.bankPinCode = bankPinCode;
	}

	public String getBankState() {
		return bankState;
	}

	public void setBankState(String bankState) {
		this.bankState = bankState;
	}

	public String getBankCountry() {
		return bankCountry;
	}

	public void setBankCountry(String bankCountry) {
		this.bankCountry = bankCountry;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public String getAcceptReasonText() {
		return acceptReasonText;
	}

	public void setAcceptReasonText(String acceptReasonText) {
		this.acceptReasonText = acceptReasonText;
	}

	public String getRejectReasonID() {
		return rejectReasonID;
	}

	public void setRejectReasonID(String rejectReasonID) {
		this.rejectReasonID = rejectReasonID;
	}

	public String getRejectReasonOtherText() {
		return rejectReasonOtherText;
	}

	public void setRejectReasonOtherText(String rejectReasonOtherText) {
		this.rejectReasonOtherText = rejectReasonOtherText;
	}

	public String getSentMailToAuth() {
		return sentMailToAuth;
	}

	public void setSentMailToAuth(String sentMailToAuth) {
		this.sentMailToAuth = sentMailToAuth;
	}

	public String getEiaToBeUpdated() {
		return eiaToBeUpdated;
	}

	public void setEiaToBeUpdated(String eiaToBeUpdated) {
		this.eiaToBeUpdated = eiaToBeUpdated;
	}

	public String getIcCd() {
		return icCd;
	}

	public void setIcCd(String icCd) {
		this.icCd = icCd;
	}

	public String getIcBranchCd() {
		return icBranchCd;
	}

	public void setIcBranchCd(String icBranchCd) {
		this.icBranchCd = icBranchCd;
	}

	public String getIsIcBranchHO() {
		return isIcBranchHO;
	}

	public void setIsIcBranchHO(String isIcBranchHO) {
		this.isIcBranchHO = isIcBranchHO;
	}

	public String getIsApBranchHO() {
		return isApBranchHO;
	}

	public void setIsApBranchHO(String isApBranchHO) {
		this.isApBranchHO = isApBranchHO;
	}

	public String getIsApOrIcBranchHO() {
		return isApOrIcBranchHO;
	}

	public void setIsApOrIcBranchHO(String isApOrIcBranchHO) {
		this.isApOrIcBranchHO = isApOrIcBranchHO;
	}

	public String getApCd() {
		return apCd;
	}

	public void setApCd(String apCd) {
		this.apCd = apCd;
	}

	public String getApBranchCd() {
		return apBranchCd;
	}

	public void setApBranchCd(String apBranchCd) {
		this.apBranchCd = apBranchCd;
	}

	public String getApOrICCode() {
		return apOrICCode;
	}

	public void setApOrICCode(String apOrICCode) {
		this.apOrICCode = apOrICCode;
	}

	public String getApOrICBranchCode() {
		return apOrICBranchCode;
	}

	public void setApOrICBranchCode(String apOrICBranchCode) {
		this.apOrICBranchCode = apOrICBranchCode;
	}

	public String getCheckerAction() {
		return checkerAction;
	}

	public void setCheckerAction(String checkerAction) {
		this.checkerAction = checkerAction;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getFormData() {
		return formData;
	}

	public void setFormData(String formData) {
		this.formData = formData;
	}

	public String getChangeApplAccCatAndType() {
		return changeApplAccCatAndType;
	}

	public void setChangeApplAccCatAndType(String changeApplAccCatAndType) {
		this.changeApplAccCatAndType = changeApplAccCatAndType;
	}

	public String getChangeApplName() {
		return changeApplName;
	}

	public void setChangeApplName(String changeApplName) {
		this.changeApplName = changeApplName;
	}

	public String getChangeApplFatherOrHusName() {
		return changeApplFatherOrHusName;
	}

	public void setChangeApplFatherOrHusName(String changeApplFatherOrHusName) {
		this.changeApplFatherOrHusName = changeApplFatherOrHusName;
	}

	public String getChangeApplPanOrUid() {
		return changeApplPanOrUid;
	}

	public void setChangeApplPanOrUid(String changeApplPanOrUid) {
		this.changeApplPanOrUid = changeApplPanOrUid;
	}

	public String getChangeApplPan() {
		return changeApplPan;
	}

	public void setChangeApplPan(String changeApplPan) {
		this.changeApplPan = changeApplPan;
	}

	public String getChangeApplUid() {
		return changeApplUid;
	}

	public void setChangeApplUid(String changeApplUid) {
		this.changeApplUid = changeApplUid;
	}

	public String getChangeApplPermanentAddress() {
		return changeApplPermanentAddress;
	}

	public void setChangeApplPermanentAddress(String changeApplPermanentAddress) {
		this.changeApplPermanentAddress = changeApplPermanentAddress;
	}

	public String getChangeApplCorrAddress() {
		return changeApplCorrAddress;
	}

	public void setChangeApplCorrAddress(String changeApplCorrAddress) {
		this.changeApplCorrAddress = changeApplCorrAddress;
	}

	public String getChangeApplBankDtl() {
		return changeApplBankDtl;
	}

	public void setChangeApplBankDtl(String changeApplBankDtl) {
		this.changeApplBankDtl = changeApplBankDtl;
	}

	public String getChangeApplContactDtl() {
		return changeApplContactDtl;
	}

	public void setChangeApplContactDtl(String changeApplContactDtl) {
		this.changeApplContactDtl = changeApplContactDtl;
	}

	public String getChangeApplTelNo() {
		return changeApplTelNo;
	}

	public void setChangeApplTelNo(String changeApplTelNo) {
		this.changeApplTelNo = changeApplTelNo;
	}

	public String getDeleteApplTelNo() {
		return deleteApplTelNo;
	}

	public void setDeleteApplTelNo(String deleteApplTelNo) {
		this.deleteApplTelNo = deleteApplTelNo;
	}

	public String getChangeApplAltTelNo() {
		return changeApplAltTelNo;
	}

	public void setChangeApplAltTelNo(String changeApplAltTelNo) {
		this.changeApplAltTelNo = changeApplAltTelNo;
	}

	public String getDeleteApplAltTelNo() {
		return deleteApplAltTelNo;
	}

	public void setDeleteApplAltTelNo(String deleteApplAltTelNo) {
		this.deleteApplAltTelNo = deleteApplAltTelNo;
	}

	public String getChangeApplMobileNo() {
		return changeApplMobileNo;
	}

	public void setChangeApplMobileNo(String changeApplMobileNo) {
		this.changeApplMobileNo = changeApplMobileNo;
	}

	public String getDeleteApplMobileNo() {
		return deleteApplMobileNo;
	}

	public void setDeleteApplMobileNo(String deleteApplMobileNo) {
		this.deleteApplMobileNo = deleteApplMobileNo;
	}

	public String getChangeApplFAXNo() {
		return changeApplFAXNo;
	}

	public void setChangeApplFAXNo(String changeApplFAXNo) {
		this.changeApplFAXNo = changeApplFAXNo;
	}

	public String getDeleteApplFAXNo() {
		return deleteApplFAXNo;
	}

	public void setDeleteApplFAXNo(String deleteApplFAXNo) {
		this.deleteApplFAXNo = deleteApplFAXNo;
	}

	public String getChangeApplEmailId() {
		return changeApplEmailId;
	}

	public void setChangeApplEmailId(String changeApplEmailId) {
		this.changeApplEmailId = changeApplEmailId;
	}

	public String getDeleteApplEmailId() {
		return deleteApplEmailId;
	}

	public void setDeleteApplEmailId(String deleteApplEmailId) {
		this.deleteApplEmailId = deleteApplEmailId;
	}

	public String getChangeApplAltEmailId() {
		return changeApplAltEmailId;
	}

	public void setChangeApplAltEmailId(String changeApplAltEmailId) {
		this.changeApplAltEmailId = changeApplAltEmailId;
	}

	public String getDeleteApplAltEmailId() {
		return deleteApplAltEmailId;
	}

	public void setDeleteApplAltEmailId(String deleteApplAltEmailId) {
		this.deleteApplAltEmailId = deleteApplAltEmailId;
	}

	public String getChangeToNewAuthRep() {
		return changeToNewAuthRep;
	}

	public void setChangeToNewAuthRep(String changeToNewAuthRep) {
		this.changeToNewAuthRep = changeToNewAuthRep;
	}

	public String getChangeAuthRepName() {
		return changeAuthRepName;
	}

	public void setChangeAuthRepName(String changeAuthRepName) {
		this.changeAuthRepName = changeAuthRepName;
	}

	public String getChangeAuthRepFatherOrHusName() {
		return changeAuthRepFatherOrHusName;
	}

	public void setChangeAuthRepFatherOrHusName(String changeAuthRepFatherOrHusName) {
		this.changeAuthRepFatherOrHusName = changeAuthRepFatherOrHusName;
	}

	public String getChangeAuthRepPanOrUid() {
		return changeAuthRepPanOrUid;
	}

	public void setChangeAuthRepPanOrUid(String changeAuthRepPanOrUid) {
		this.changeAuthRepPanOrUid = changeAuthRepPanOrUid;
	}

	public String getChangeAuthRepPan() {
		return changeAuthRepPan;
	}

	public void setChangeAuthRepPan(String changeAuthRepPan) {
		this.changeAuthRepPan = changeAuthRepPan;
	}

	public String getChangeAuthRepUid() {
		return changeAuthRepUid;
	}

	public void setChangeAuthRepUid(String changeAuthRepUid) {
		this.changeAuthRepUid = changeAuthRepUid;
	}

	public String getChangeAuthRepPermanentAddress() {
		return changeAuthRepPermanentAddress;
	}

	public void setChangeAuthRepPermanentAddress(
			String changeAuthRepPermanentAddress) {
		this.changeAuthRepPermanentAddress = changeAuthRepPermanentAddress;
	}

	public String getChangeAuthRepContactDtl() {
		return changeAuthRepContactDtl;
	}

	public void setChangeAuthRepContactDtl(String changeAuthRepContactDtl) {
		this.changeAuthRepContactDtl = changeAuthRepContactDtl;
	}

	public String getChangeAuthRepTelNo() {
		return changeAuthRepTelNo;
	}

	public void setChangeAuthRepTelNo(String changeAuthRepTelNo) {
		this.changeAuthRepTelNo = changeAuthRepTelNo;
	}

	public String getDeleteAuthRepTelNo() {
		return deleteAuthRepTelNo;
	}

	public void setDeleteAuthRepTelNo(String deleteAuthRepTelNo) {
		this.deleteAuthRepTelNo = deleteAuthRepTelNo;
	}

	public String getChangeAuthRepAltTelNo() {
		return changeAuthRepAltTelNo;
	}

	public void setChangeAuthRepAltTelNo(String changeAuthRepAltTelNo) {
		this.changeAuthRepAltTelNo = changeAuthRepAltTelNo;
	}

	public String getDeleteAuthRepAltTelNo() {
		return deleteAuthRepAltTelNo;
	}

	public void setDeleteAuthRepAltTelNo(String deleteAuthRepAltTelNo) {
		this.deleteAuthRepAltTelNo = deleteAuthRepAltTelNo;
	}

	public String getChangeAuthRepMobileNo() {
		return changeAuthRepMobileNo;
	}

	public void setChangeAuthRepMobileNo(String changeAuthRepMobileNo) {
		this.changeAuthRepMobileNo = changeAuthRepMobileNo;
	}

	public String getDeleteAuthRepMobileNo() {
		return deleteAuthRepMobileNo;
	}

	public void setDeleteAuthRepMobileNo(String deleteAuthRepMobileNo) {
		this.deleteAuthRepMobileNo = deleteAuthRepMobileNo;
	}

	public String getChangeAuthRepFAXNo() {
		return changeAuthRepFAXNo;
	}

	public void setChangeAuthRepFAXNo(String changeAuthRepFAXNo) {
		this.changeAuthRepFAXNo = changeAuthRepFAXNo;
	}

	public String getDeleteAuthRepFAXNo() {
		return deleteAuthRepFAXNo;
	}

	public void setDeleteAuthRepFAXNo(String deleteAuthRepFAXNo) {
		this.deleteAuthRepFAXNo = deleteAuthRepFAXNo;
	}

	public String getChangeAuthRepEmailId() {
		return changeAuthRepEmailId;
	}

	public void setChangeAuthRepEmailId(String changeAuthRepEmailId) {
		this.changeAuthRepEmailId = changeAuthRepEmailId;
	}

	public String getDeleteAuthRepEmailId() {
		return deleteAuthRepEmailId;
	}

	public void setDeleteAuthRepEmailId(String deleteAuthRepEmailId) {
		this.deleteAuthRepEmailId = deleteAuthRepEmailId;
	}

	public String getChangeAuthRepAltEmailId() {
		return changeAuthRepAltEmailId;
	}

	public void setChangeAuthRepAltEmailId(String changeAuthRepAltEmailId) {
		this.changeAuthRepAltEmailId = changeAuthRepAltEmailId;
	}

	public String getDeleteAuthRepAltEmailId() {
		return deleteAuthRepAltEmailId;
	}

	public void setDeleteAuthRepAltEmailId(String deleteAuthRepAltEmailId) {
		this.deleteAuthRepAltEmailId = deleteAuthRepAltEmailId;
	}

	public String getHidden1() {
		return hidden1;
	}

	public void setHidden1(String hidden1) {
		this.hidden1 = hidden1;
	}

	public String getHidden2() {
		return hidden2;
	}

	public void setHidden2(String hidden2) {
		this.hidden2 = hidden2;
	}

	public String getFlag1() {
		return flag1;
	}

	public void setFlag1(String flag1) {
		this.flag1 = flag1;
	}

	public String getFlag2() {
		return flag2;
	}

	public void setFlag2(String flag2) {
		this.flag2 = flag2;
	}

	public List<ProposalDetailBean> getProposalDetailBeanList() {
		return proposalDetailBeanList;
	}

	public void setProposalDetailBeanList(
			List<ProposalDetailBean> proposalDetailBeanList) {
		this.proposalDetailBeanList = proposalDetailBeanList;
	}

	/*public List<String> getLinkList() {
		return linkList;
	}

	public void setLinkList(List<String> linkList) {
		this.linkList = linkList;
	}*/
	public String getChallengeResponse() {
		return challengeResponse;
	}

	public void setChallengeResponse(String challengeResponse) {
		this.challengeResponse = challengeResponse;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getCultId() {
		return cultId;
	}

	public void setCultId(String cultId) {
		this.cultId = cultId;
	}

	public String getTrnxId() {
		return trnxId;
	}

	public void setTrnxId(String trnxId) {
		this.trnxId = trnxId;
	}

	public String getEntityCode() {
		return entityCode;
	}

	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getIcName() {
		return icName;
	}

	public void setIcName(String icName) {
		this.icName = icName;
	}

	public String getIcBranchName() {
		return icBranchName;
	}

	public void setIcBranchName(String icBranchName) {
		this.icBranchName = icBranchName;
	}

	public String getApName() {
		return apName;
	}

	public void setApName(String apName) {
		this.apName = apName;
	}

	public String getApBranchName() {
		return apBranchName;
	}

	public void setApBranchName(String apBranchName) {
		this.apBranchName = apBranchName;
	}

	public String getApOrICName() {
		return apOrICName;
	}

	public void setApOrICName(String apOrICName) {
		this.apOrICName = apOrICName;
	}

	public String getApOrICBranchName() {
		return apOrICBranchName;
	}

	public void setApOrICBranchName(String apOrICBranchName) {
		this.apOrICBranchName = apOrICBranchName;
	}

	public String getSelectedApOrIcBranchCode() {
		return selectedApOrIcBranchCode;
	}

	public void setSelectedApOrIcBranchCode(String selectedApOrIcBranchCode) {
		this.selectedApOrIcBranchCode = selectedApOrIcBranchCode;
	}

	public String getSelectedApOrIcBranchName() {
		return selectedApOrIcBranchName;
	}

	public void setSelectedApOrIcBranchName(String selectedApOrIcBranchName) {
		this.selectedApOrIcBranchName = selectedApOrIcBranchName;
	}

	public String getSelectedApOrIcBranchUserCode() {
		return selectedApOrIcBranchUserCode;
	}

	public void setSelectedApOrIcBranchUserCode(String selectedApOrIcBranchUserCode) {
		this.selectedApOrIcBranchUserCode = selectedApOrIcBranchUserCode;
	}

	public String getSelectedApOrIcBranchUserName() {
		return selectedApOrIcBranchUserName;
	}

	public void setSelectedApOrIcBranchUserName(String selectedApOrIcBranchUserName) {
		this.selectedApOrIcBranchUserName = selectedApOrIcBranchUserName;
	}

	public void setChangeApplDOBProof(String changeApplDOBProof) {
		this.changeApplDOBProof = changeApplDOBProof;
	}

	public String getChangeApplDOBProof() {
		return changeApplDOBProof;
	}

	public String getNumberOfApplicants() {
		return numberOfApplicants;
	}

	public void setNumberOfApplicants(String numberOfApplicants) {
		this.numberOfApplicants = numberOfApplicants;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/*
	 * public AccountOpeningFormBean()
	 * {
	 * proposalDetailBeanList=new ArrayList<ProposalDetailBean>();
	 * proposalDetailBeanList.add(new ProposalDetailBean());
	 * proposalDetailBeanList.add(new ProposalDetailBean());
	 * proposalDetailBeanList.add(new ProposalDetailBean());
	 * }
	 */
	public String getIsOnline() {
		return isOnline;
	}

	public void setIsOnline(String isOnline) {
		this.isOnline = isOnline;
	}

	public String getIsExternal() {
		return isExternal;
	}

	public void setIsExternal(String isExternal) {
		this.isExternal = isExternal;
	}

	public String getIsApSearch() {
		return isApSearch;
	}

	public void setIsApSearch(String isApSearch) {
		this.isApSearch = isApSearch;
	}

	public String getCaptchaText() {
		return captchaText;
	}

	public void setCaptchaText(String captchaText) {
		this.captchaText = captchaText;
	}

	public String getEkycFlag() {
		return ekycFlag;
	}

	public void setEkycFlag(String ekycFlag) {
		this.ekycFlag = ekycFlag;
	}

	public String getFormStatus() {
		return formStatus;
	}

	public void setFormStatus(String formStatus) {
		this.formStatus = formStatus;
	}

	public String getFormStatusDesc() {
		return formStatusDesc;
	}

	public void setFormStatusDesc(String formStatusDesc) {
		this.formStatusDesc = formStatusDesc;
	}

	public String getOtpForUid() {
		return otpForUid;
	}

	public void setOtpForUid(String otpForUid) {
		this.otpForUid = otpForUid;
	}

	public String getEkycOtpResponseCode() {
		return ekycOtpResponseCode;
	}

	public void setEkycOtpResponseCode(String ekycOtpResponseCode) {
		this.ekycOtpResponseCode = ekycOtpResponseCode;
	}

	public String getEkycOtpResponseDesc() {
		return ekycOtpResponseDesc;
	}

	public void setEkycOtpResponseDesc(String ekycOtpResponseDesc) {
		this.ekycOtpResponseDesc = ekycOtpResponseDesc;
	}

	public String getFlgNewCr() {
		return flgNewCr;
	}

	public void setFlgNewCr(String flgNewCr) {
		this.flgNewCr = flgNewCr;
	}

	public String getChangeApplDOB() {
		return changeApplDOB;
	}

	public void setChangeApplDOB(String changeApplDOB) {
		this.changeApplDOB = changeApplDOB;
	}

	public String getChangeApplGender() {
		return changeApplGender;
	}

	public void setChangeApplGender(String changeApplGender) {
		this.changeApplGender = changeApplGender;
	}

	public String getOnlineEiaPDFPath() {
		return onlineEiaPDFPath;
	}

	public void setOnlineEiaPDFPath(String onlineEiaPDFPath) {
		this.onlineEiaPDFPath = onlineEiaPDFPath;
	}

	public String getDataStoringByAp() {
		return dataStoringByAp;
	}

	public void setDataStoringByAp(String dataStoringByAp) {
		this.dataStoringByAp = dataStoringByAp;
	}

	public String getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}

	public String getAddressSameAsPermanentradio0() {
		return addressSameAsPermanentradio0;
	}

	public void setAddressSameAsPermanentradio0(String addressSameAsPermanentradio0) {
		this.addressSameAsPermanentradio0 = addressSameAsPermanentradio0;
	}

	public String getAddressSameAsPermanentradio1() {
		return addressSameAsPermanentradio1;
	}

	public void setAddressSameAsPermanentradio1(String addressSameAsPermanentradio1) {
		this.addressSameAsPermanentradio1 = addressSameAsPermanentradio1;
	}

	public String getAddressSameAsPermanentradio2() {
		return addressSameAsPermanentradio2;
	}

	public void setAddressSameAsPermanentradio2(String addressSameAsPermanentradio2) {
		this.addressSameAsPermanentradio2 = addressSameAsPermanentradio2;
	}

	public String getRadio3SecAddSame() {
		return radio3SecAddSame;
	}

	public void setRadio3SecAddSame(String radio3SecAddSame) {
		this.radio3SecAddSame = radio3SecAddSame;
	}

	public String getRadio4AuthAddSame() {
		return radio4AuthAddSame;
	}

	public void setRadio4AuthAddSame(String radio4AuthAddSame) {
		this.radio4AuthAddSame = radio4AuthAddSame;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotalSize() {
		return totalSize;
	}

	public void setTotalSize(int totalSize) {
		this.totalSize = totalSize;
	}

	public String getFirstPageInd() {
		return firstPageInd;
	}

	public void setFirstPageInd(String firstPageInd) {
		this.firstPageInd = firstPageInd;
	}

	public String getLastPageInd() {
		return lastPageInd;
	}

	public void setLastPageInd(String lastPageInd) {
		this.lastPageInd = lastPageInd;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public int getPageNumPlus() {
		return pageNumPlus;
	}

	public void setPageNumPlus(int pageNumPlus) {
		this.pageNumPlus = pageNumPlus;
	}

	public long getNumberOfPages() {
		return numberOfPages;
	}

	public void setNumberOfPages(long numberOfPages) {
		this.numberOfPages = numberOfPages;
	}

	public String getOtpForMobile() {
		return otpForMobile;
	}

	public void setOtpForMobile(String otpForMobile) {
		this.otpForMobile = otpForMobile;
	}

	public String getOtpForEmail() {
		return otpForEmail;
	}

	public void setOtpForEmail(String otpForEmail) {
		this.otpForEmail = otpForEmail;
	}

	public String getOtpGenerateDate() {
		return otpGenerateDate;
	}

	public void setOtpGenerateDate(String otpGenerateDate) {
		this.otpGenerateDate = otpGenerateDate;
	}

	public String getOtpSelected() {
		return otpSelected;
	}

	public void setOtpSelected(String otpSelected) {
		this.otpSelected = otpSelected;
	}

	public String getOtpResetAllow() {
		return otpResetAllow;
	}

	public void setOtpResetAllow(String otpResetAllow) {
		this.otpResetAllow = otpResetAllow;
	}

	public String getIsPartialOrFinalFlag() {
		return isPartialOrFinalFlag;
	}

	public void setIsPartialOrFinalFlag(String isPartialOrFinalFlag) {
		this.isPartialOrFinalFlag = isPartialOrFinalFlag;
	}

	public String getInsuranceCompanyType() {
		return insuranceCompanyType;
	}

	public void setInsuranceCompanyType(String insuranceCompanyType) {
		this.insuranceCompanyType = insuranceCompanyType;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getAuthRepReuiredDataPresent() {
		return authRepReuiredDataPresent;
	}

	public void setAuthRepReuiredDataPresent(String authRepReuiredDataPresent) {
		this.authRepReuiredDataPresent = authRepReuiredDataPresent;
	}

	public String getAuthRepLoginCreation() {
		return authRepLoginCreation;
	}

	public void setAuthRepLoginCreation(String authRepLoginCreation) {
		this.authRepLoginCreation = authRepLoginCreation;
	}

	public String getInsuranceCompanyTypeDescription() {
		return insuranceCompanyTypeDescription;
	}

	public void setInsuranceCompanyTypeDescription(String insuranceCompanyTypeDescription) {
		this.insuranceCompanyTypeDescription = insuranceCompanyTypeDescription;
	}

	public String getKycCategory() {
		return kycCategory;
	}

	public void setKycCategory(String kycCategory) {
		this.kycCategory = kycCategory;
	}

	public String getLotNumber() {
		return lotNumber;
	}

	public void setLotNumber(String lotNumber) {
		this.lotNumber = lotNumber;
	}

	public String getSourcedBy() {
		return sourcedBy;
	}
	public void setSourcedBy(String sourcedBy) {
		this.sourcedBy = sourcedBy;
	}

    public String getIsAadharBased() {
			return isAadharBased;
	}

	public void setIsAadharBased(String isAadharBased) {
		this.isAadharBased = isAadharBased;
	}

	

	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityTypDtls() {
		return entityTypDtls;
	}

	public void setEntityTypDtls(String entityTypDtls) {
		this.entityTypDtls = entityTypDtls;
	}

	public String getDateOfRecpt() {
		return dateOfRecpt;
	}

	public void setDateOfRecpt(String dateOfRecpt) {
		this.dateOfRecpt = dateOfRecpt;
	}

	public String getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getRgstrnum() {
		return rgstrnum;
	}

	public void setRgstrnum(String rgstrnum) {
		this.rgstrnum = rgstrnum;
	}

	public String getIncropDate() {
		return incropDate;
	}

	public void setIncropDate(String incropDate) {
		this.incropDate = incropDate;
	}

	public String getCorporateAddress1() {
		return corporateAddress1;
	}

	public void setCorporateAddress1(String corporateAddress1) {
		this.corporateAddress1 = corporateAddress1;
	}

	public String getCorporateAddress2() {
		return corporateAddress2;
	}

	public void setCorporateAddress2(String corporateAddress2) {
		this.corporateAddress2 = corporateAddress2;
	}

	public String getCorporateAddress3() {
		return corporateAddress3;
	}

	public void setCorporateAddress3(String corporateAddress3) {
		this.corporateAddress3 = corporateAddress3;
	}

	public String getCorporateLandmark() {
		return corporateLandmark;
	}

	public void setCorporateLandmark(String corporateLandmark) {
		this.corporateLandmark = corporateLandmark;
	}

	public String getCorporateCity() {
		return corporateCity;
	}

	public void setCorporateCity(String corporateCity) {
		this.corporateCity = corporateCity;
	}

	public String getCorporateCountry() {
		return corporateCountry;
	}

	public void setCorporateCountry(String corporateCountry) {
		this.corporateCountry = corporateCountry;
	}

	public String getCorporateState() {
		return corporateState;
	}

	public void setCorporateState(String corporateState) {
		this.corporateState = corporateState;
	}

	public String getCorporatePincode() {
		return corporatePincode;
	}

	public void setCorporatePincode(String corporatePincode) {
		this.corporatePincode = corporatePincode;
	}

	public String getCorporateEmail() {
		return corporateEmail;
	}

	public void setCorporateEmail(String corporateEmail) {
		this.corporateEmail = corporateEmail;
	}

	public String getCorporateTelNo() {
		return corporateTelNo;
	}

	public void setCorporateTelNo(String corporateTelNo) {
		this.corporateTelNo = corporateTelNo;
	}

	

	public String getCorporateDocTyp() {
		return corporateDocTyp;
	}

	public void setCorporateDocTyp(String corporateDocTyp) {
		this.corporateDocTyp = corporateDocTyp;
	}

	public String getCorporateDocOthrs() {
		return corporateDocOthrs;
	}

	public void setCorporateDocOthrs(String corporateDocOthrs) {
		this.corporateDocOthrs = corporateDocOthrs;
	}

	public String getCorporateDoc() {
		return corporateDoc;
	}

	public void setCorporateDoc(String corporateDoc) {
		this.corporateDoc = corporateDoc;
	}

	public String getRepresentativeDocTyp() {
		return representativeDocTyp;
	}

	public void setRepresentativeDocTyp(String representativeDocTyp) {
		this.representativeDocTyp = representativeDocTyp;
	}

	public String getRepresentativeDocOthrs() {
		return representativeDocOthrs;
	}

	public void setRepresentativeDocOthrs(String representativeDocOthrs) {
		this.representativeDocOthrs = representativeDocOthrs;
	}

	public String getRepresentativeDoc() {
		return representativeDoc;
	}

	public void setRepresentativeDoc(String representativeDoc) {
		this.representativeDoc = representativeDoc;
	}

	public String getChangeApplUserid() {
		return changeApplUserid;
	}

	public void setChangeApplUserid(String changeApplUserid) {
		this.changeApplUserid = changeApplUserid;
	}

}