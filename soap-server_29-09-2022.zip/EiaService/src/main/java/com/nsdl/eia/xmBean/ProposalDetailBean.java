package com.nsdl.eia.xmBean;

import java.io.Serializable;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.nsdl.eia.constants.NIRConstants;


public class ProposalDetailBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private String userId;

	private String password;

	private String confirmPassword;

	private String passwordChangeFlag;

	private String otpOrBiometricFlag;

	private String otpFlag;

	private String biometricFlag;

	private String entityCode;

	private String entityName;

	private String roleCode;

	private String roleName;

	private String icCd;

	private String icName;

	private String icBranchCd;

	private String icBranchName;

	private String isIcBranchHO;

	private String apCd;

	private String apName;

	private String apBranchCd;

	private String apBranchName;

	private String isApBranchHO;

	private String apOrICCode;

	private String apOrICName;

	private String apOrICBranchCode;

	private String apOrICBranchName;

	private String isApOrIcBranchHO;

	private String selectedApOrIcBranchCode = NIRConstants.BLANK_STRING;

	private String selectedApOrIcBranchName = NIRConstants.BLANK_STRING;

	private String selectedApOrIcBranchUserCode = NIRConstants.BLANK_STRING;

	private String selectedApOrIcBranchUserName = NIRConstants.BLANK_STRING;

	private String fullNameOfCustomer;

	private String prpsrAthFlag;

	private String titleOfCustomer;

	private String firstNameOfCustomer;

	private String middleNameOfCustomer;

	private String lastNameOfCustomer;

	private String fatherOrHusbandFirstName;

	private String fatherOrHusbandMiddleName;

	private String fatherOrHusbandLastName;

	// private String gender="M";
	private String gender;

	private String dateOfBirth;

	private String pan;
	private String panOld;

	private String isPanPresent;

	private String isPanChanged;

	private String uid;
	/************* Added By Mayur J on 23-07-2018 ***************/
	private String vid;

	public String getVid() {
		return vid;
	}

	public void setVid(String vid) {
		this.vid = vid;
	}

	/***********************************************************/

	private String uidOld;

	private String poi;

	private String isUidPresent;

	private String isUidChanged;

	private String permanentAddress1;

	private String permanentAddress2;

	private String permanentAddress3;

	private String permanentAddress4;

	private String permanentAddress5;

	private String permanentPinCode;

	private String permanentPinCodeExt;

	private String permanentStateDD;

	private String permanentStateText;

	private String permanentCountry;

	private String correspondenceAddress1;

	private String correspondenceAddress2;

	private String correspondenceAddress3;

	private String correspondenceAddress4;

	private String correspondenceAddress5;

	private String correspondencePinCode;

	private String correspondencePinCodeExt;

	private String correspondenceStateDD;

	private String correspondenceStateText;

	private String correspondenceCountry;

	private String correspondenceAddressSameAsPermanent;

	private String addressSameAsP1Address;

	private String telephoneNo;

	private String telephoneNoAlt;

	private String mobileNo;
	private String mobileNoOld;

	private String emailId;
	private String emailIdOld;

	private String emailIdAlt;

	private String faxNo;

	private String relationshipProof;

	private String relationshipProofOthers;

	private String nameChangeProof;

	private String nameChangeProofOfFaterOrHus;

	/*--- FOR NEW ADDTION OF AUTH REPRESENTATIVE -----*/
	private String newFullNameOfCustomer;

	private String newPrpsrAthFlag;

	private String newFirstNameOfCustomer;

	private String newMiddleNameOfCustomer;

	private String newLastNameOfCustomer;

	private String newGender = "M";

	private String newDateOfBirth;

	private String newDateOfBirthProof;

	private String newPan;

	private String newUid;

	private String newPermanentAddress1;

	private String newPermanentAddress2;

	private String newPermanentAddress3;

	private String newPermanentAddress4;

	private String newPermanentAddress5;

	private String newPermanentPinCode;

	private String newPermanentPinCodeExt;

	private String newPermanentStateDD;

	private String newPermanentStateText;

	private String newPermanentCountry;

	private String newPermanentAddressProof;

	private String newTelephoneNo;

	private String newTelephoneNoAlt;

	private String newMobileNo;

	private String newEmailId;

	private String newEmailIdAlt;

	private String newFaxNo;

	private String newRelationshipProof;

	private String newRelationshipProofOthers;

	private String hidden1;

	private String hidden2;

	private String flag1;

	private String flag2;

	private String authRepSameAsApplSoleAddressRadio;

	/*--- END OF NEW ADDTION OF AUTH REPRESENTATIVE -----*/
	// Address Proof
	private String perAddProofP1;

	private String CorrAddProofP1;

	// added by vamsi
	private String ackNo;

	private String refNo;

	private String name;

	private String eIANo;

	private String toDate;

	private String fromDate;

	private int pageSize;

	private int listSize;

	private String idProof;
	private String dateOfBirthProof;
	private String permanentAddressProof;
	private String correspondenceAddressProof;
	private String eiaApplicationFormProof;
	private String eiaAllInOneProof;

	private String idProofFilePathDownload = "N";
	private String dateOfBirthProofFilePathDownload = "N";
	private String permanentAddressProofFilePathDownload = "N";
	private String correspondenceAddressProofFilePathDownload = "N";
	private String eiaApplicationFormPathDownload = "N";
	private String eiaAllInOneProofPathDownload = "N";

	private CommonsMultipartFile idProofFilePath;
	private CommonsMultipartFile dateOfBirthProofFilePath;
	private CommonsMultipartFile permanentAddressProofFilePath;
	private CommonsMultipartFile correspondenceAddressProofFilePath;
	private CommonsMultipartFile eiaApplicationFormFilePath;
	private CommonsMultipartFile eiaAllInOneProofFilePath;

	private String idProofFilePathTemp = NIRConstants.BLANK_STRING;
	private String dateOfBirthProofFilePathTemp = NIRConstants.BLANK_STRING;
	private String permanentAddressProofFilePathTemp = NIRConstants.BLANK_STRING;
	private String correspondenceAddressProofFilePathTemp = NIRConstants.BLANK_STRING;
	private String eiaApplicationFormFilePathTemp = NIRConstants.BLANK_STRING;
	private String eiaAllInOneProofFilePathTemp = NIRConstants.BLANK_STRING;

	// CR 5500 Start
	private String idProofFileDelete = NIRConstants.BLANK_STRING;
	private String dateOfBirthProofFileDelete = NIRConstants.BLANK_STRING;
	private String permanentAddressProofDelete = NIRConstants.BLANK_STRING;
	private String correspondenceAddressProofFileDelete = NIRConstants.BLANK_STRING;
	private String eiaApplicationFormFileDelete = NIRConstants.BLANK_STRING;
	private String eiaAllInOneProofFileDelete = NIRConstants.BLANK_STRING;
	// CR 5500 End

	public String getPrpsrAthFlag() {
		return prpsrAthFlag;
	}

	public void setPrpsrAthFlag(String prpsrAthFlag) {
		this.prpsrAthFlag = prpsrAthFlag;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getListSize() {
		return listSize;
	}

	public void setListSize(int listSize) {
		this.listSize = listSize;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getAckNo() {
		return ackNo;
	}

	public void setAckNo(String ackNo) {
		this.ackNo = ackNo;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String geteIANo() {
		return eIANo;
	}

	public void seteIANo(String eIANo) {
		this.eIANo = eIANo;
	}

	public String getTitleOfCustomer() {
		return titleOfCustomer;
	}

	public void setTitleOfCustomer(String titleOfCustomer) {
		this.titleOfCustomer = titleOfCustomer;
	}

	public String getFirstNameOfCustomer() {
		return firstNameOfCustomer;
	}

	public void setFirstNameOfCustomer(String firstNameOfCustomer) {
		this.firstNameOfCustomer = firstNameOfCustomer;
	}

	public String getMiddleNameOfCustomer() {
		return middleNameOfCustomer;
	}

	public void setMiddleNameOfCustomer(String middleNameOfCustomer) {
		this.middleNameOfCustomer = middleNameOfCustomer;
	}

	public String getLastNameOfCustomer() {
		return lastNameOfCustomer;
	}

	public void setLastNameOfCustomer(String lastNameOfCustomer) {
		this.lastNameOfCustomer = lastNameOfCustomer;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getPermanentAddress1() {
		return permanentAddress1;
	}

	public void setPermanentAddress1(String permanentAddress1) {
		this.permanentAddress1 = permanentAddress1;
	}

	public String getPermanentAddress2() {
		return permanentAddress2;
	}

	public void setPermanentAddress2(String permanentAddress2) {
		this.permanentAddress2 = permanentAddress2;
	}

	public String getPermanentAddress3() {
		return permanentAddress3;
	}

	public void setPermanentAddress3(String permanentAddress3) {
		this.permanentAddress3 = permanentAddress3;
	}

	public String getPermanentPinCode() {
		return permanentPinCode;
	}

	public void setPermanentPinCode(String permanentPinCode) {
		this.permanentPinCode = permanentPinCode;
	}

	public String getPermanentCountry() {
		return permanentCountry;
	}

	public void setPermanentCountry(String permanentCountry) {
		this.permanentCountry = permanentCountry;
	}

	public String getCorrespondenceAddress1() {
		return correspondenceAddress1;
	}

	public void setCorrespondenceAddress1(String correspondenceAddress1) {
		this.correspondenceAddress1 = correspondenceAddress1;
	}

	public String getCorrespondenceAddress2() {
		return correspondenceAddress2;
	}

	public void setCorrespondenceAddress2(String correspondenceAddress2) {
		this.correspondenceAddress2 = correspondenceAddress2;
	}

	public String getCorrespondenceAddress3() {
		return correspondenceAddress3;
	}

	public void setCorrespondenceAddress3(String correspondenceAddress3) {
		this.correspondenceAddress3 = correspondenceAddress3;
	}

	public String getCorrespondencePinCode() {
		return correspondencePinCode;
	}

	public void setCorrespondencePinCode(String correspondencePinCode) {
		this.correspondencePinCode = correspondencePinCode;
	}

	public String getCorrespondenceCountry() {
		return correspondenceCountry;
	}

	public void setCorrespondenceCountry(String correspondenceCountry) {
		this.correspondenceCountry = correspondenceCountry;
	}

	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}

	public String getTelephoneNoAlt() {
		return telephoneNoAlt;
	}

	public void setTelephoneNoAlt(String telephoneNoAlt) {
		this.telephoneNoAlt = telephoneNoAlt;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getEmailIdAlt() {
		return emailIdAlt;
	}

	public void setEmailIdAlt(String emailIdAlt) {
		this.emailIdAlt = emailIdAlt;
	}

	public String getFaxNo() {
		return faxNo;
	}

	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}

	public String getFatherOrHusbandFirstName() {
		return fatherOrHusbandFirstName;
	}

	public void setFatherOrHusbandFirstName(String fatherOrHusbandFirstName) {
		this.fatherOrHusbandFirstName = fatherOrHusbandFirstName;
	}

	public String getFatherOrHusbandMiddleName() {
		return fatherOrHusbandMiddleName;
	}

	public void setFatherOrHusbandMiddleName(String fatherOrHusbandMiddleName) {
		this.fatherOrHusbandMiddleName = fatherOrHusbandMiddleName;
	}

	public String getFatherOrHusbandLastName() {
		return fatherOrHusbandLastName;
	}

	public void setFatherOrHusbandLastName(String fatherOrHusbandLastName) {
		this.fatherOrHusbandLastName = fatherOrHusbandLastName;
	}

	public String getPermanentAddress4() {
		return permanentAddress4;
	}

	public void setPermanentAddress4(String permanentAddress4) {
		this.permanentAddress4 = permanentAddress4;
	}

	public String getPermanentAddress5() {
		return permanentAddress5;
	}

	public void setPermanentAddress5(String permanentAddress5) {
		this.permanentAddress5 = permanentAddress5;
	}

	public String getCorrespondenceAddress4() {
		return correspondenceAddress4;
	}

	public void setCorrespondenceAddress4(String correspondenceAddress4) {
		this.correspondenceAddress4 = correspondenceAddress4;
	}

	public String getCorrespondenceAddress5() {
		return correspondenceAddress5;
	}

	public void setCorrespondenceAddress5(String correspondenceAddress5) {
		this.correspondenceAddress5 = correspondenceAddress5;
	}

	public String getPermanentStateDD() {
		return permanentStateDD;
	}

	public void setPermanentStateDD(String permanentStateDD) {
		this.permanentStateDD = permanentStateDD;
	}

	public String getPermanentStateText() {
		return permanentStateText;
	}

	public void setPermanentStateText(String permanentStateText) {
		this.permanentStateText = permanentStateText;
	}

	public String getCorrespondenceStateDD() {
		return correspondenceStateDD;
	}

	public void setCorrespondenceStateDD(String correspondenceStateDD) {
		this.correspondenceStateDD = correspondenceStateDD;
	}

	public String getCorrespondenceStateText() {
		return correspondenceStateText;
	}

	public void setCorrespondenceStateText(String correspondenceStateText) {
		this.correspondenceStateText = correspondenceStateText;
	}

	public String getDateOfBirthProof() {
		return dateOfBirthProof;
	}

	public void setDateOfBirthProof(String dateOfBirthProof) {
		this.dateOfBirthProof = dateOfBirthProof;
	}

	public String getPermanentAddressProof() {
		return permanentAddressProof;
	}

	public void setPermanentAddressProof(String permanentAddressProof) {
		this.permanentAddressProof = permanentAddressProof;
	}

	public String getCorrespondenceAddressProof() {
		return correspondenceAddressProof;
	}

	public void setCorrespondenceAddressProof(String correspondenceAddressProof) {
		this.correspondenceAddressProof = correspondenceAddressProof;
	}

	public String getRelationshipProof() {
		return relationshipProof;
	}

	public void setRelationshipProof(String relationshipProof) {
		this.relationshipProof = relationshipProof;
	}

	public void setPermanentPinCodeExt(String permanentPinCodeExt) {
		this.permanentPinCodeExt = permanentPinCodeExt;
	}

	public String getPermanentPinCodeExt() {
		return permanentPinCodeExt;
	}

	public void setCorrespondencePinCodeExt(String correspondencePinCodeExt) {
		this.correspondencePinCodeExt = correspondencePinCodeExt;
	}

	public String getCorrespondencePinCodeExt() {
		return correspondencePinCodeExt;
	}

	public void setRelationshipProofOthers(String relationshipProofOthers) {
		this.relationshipProofOthers = relationshipProofOthers;
	}

	public String getRelationshipProofOthers() {
		return relationshipProofOthers;
	}

	public void setFullNameOfCustomer(String fullNameOfCustomer) {
		this.fullNameOfCustomer = fullNameOfCustomer;
	}

	public String getFullNameOfCustomer() {
		return fullNameOfCustomer;
	}

	public String getPerAddProofP1() {
		return perAddProofP1;
	}

	public void setPerAddProofP1(String perAddProofP1) {
		this.perAddProofP1 = perAddProofP1;
	}

	public String getCorrAddProofP1() {
		return CorrAddProofP1;
	}

	public void setCorrAddProofP1(String corrAddProofP1) {
		CorrAddProofP1 = corrAddProofP1;
	}

	public String getNewFullNameOfCustomer() {
		return newFullNameOfCustomer;
	}

	public void setNewFullNameOfCustomer(String newFullNameOfCustomer) {
		this.newFullNameOfCustomer = newFullNameOfCustomer;
	}

	public String getNewPrpsrAthFlag() {
		return newPrpsrAthFlag;
	}

	public void setNewPrpsrAthFlag(String newPrpsrAthFlag) {
		this.newPrpsrAthFlag = newPrpsrAthFlag;
	}

	public String getNewFirstNameOfCustomer() {
		return newFirstNameOfCustomer;
	}

	public void setNewFirstNameOfCustomer(String newFirstNameOfCustomer) {
		this.newFirstNameOfCustomer = newFirstNameOfCustomer;
	}

	public String getNewMiddleNameOfCustomer() {
		return newMiddleNameOfCustomer;
	}

	public void setNewMiddleNameOfCustomer(String newMiddleNameOfCustomer) {
		this.newMiddleNameOfCustomer = newMiddleNameOfCustomer;
	}

	public String getNewLastNameOfCustomer() {
		return newLastNameOfCustomer;
	}

	public void setNewLastNameOfCustomer(String newLastNameOfCustomer) {
		this.newLastNameOfCustomer = newLastNameOfCustomer;
	}

	public String getNewDateOfBirth() {
		return newDateOfBirth;
	}

	public void setNewDateOfBirth(String newDateOfBirth) {
		this.newDateOfBirth = newDateOfBirth;
	}

	public String getNewDateOfBirthProof() {
		return newDateOfBirthProof;
	}

	public void setNewDateOfBirthProof(String newDateOfBirthProof) {
		this.newDateOfBirthProof = newDateOfBirthProof;
	}

	public String getNewPermanentAddress1() {
		return newPermanentAddress1;
	}

	public void setNewPermanentAddress1(String newPermanentAddress1) {
		this.newPermanentAddress1 = newPermanentAddress1;
	}

	public String getNewPermanentAddress2() {
		return newPermanentAddress2;
	}

	public void setNewPermanentAddress2(String newPermanentAddress2) {
		this.newPermanentAddress2 = newPermanentAddress2;
	}

	public String getNewPermanentAddress3() {
		return newPermanentAddress3;
	}

	public void setNewPermanentAddress3(String newPermanentAddress3) {
		this.newPermanentAddress3 = newPermanentAddress3;
	}

	public String getNewPermanentAddress4() {
		return newPermanentAddress4;
	}

	public void setNewPermanentAddress4(String newPermanentAddress4) {
		this.newPermanentAddress4 = newPermanentAddress4;
	}

	public String getNewPermanentAddress5() {
		return newPermanentAddress5;
	}

	public void setNewPermanentAddress5(String newPermanentAddress5) {
		this.newPermanentAddress5 = newPermanentAddress5;
	}

	public String getNewPermanentPinCode() {
		return newPermanentPinCode;
	}

	public void setNewPermanentPinCode(String newPermanentPinCode) {
		this.newPermanentPinCode = newPermanentPinCode;
	}

	public String getNewPermanentPinCodeExt() {
		return newPermanentPinCodeExt;
	}

	public void setNewPermanentPinCodeExt(String newPermanentPinCodeExt) {
		this.newPermanentPinCodeExt = newPermanentPinCodeExt;
	}

	public String getNewPermanentStateDD() {
		return newPermanentStateDD;
	}

	public void setNewPermanentStateDD(String newPermanentStateDD) {
		this.newPermanentStateDD = newPermanentStateDD;
	}

	public String getNewPermanentStateText() {
		return newPermanentStateText;
	}

	public void setNewPermanentStateText(String newPermanentStateText) {
		this.newPermanentStateText = newPermanentStateText;
	}

	public String getNewPermanentCountry() {
		return newPermanentCountry;
	}

	public void setNewPermanentCountry(String newPermanentCountry) {
		this.newPermanentCountry = newPermanentCountry;
	}

	public String getNewPermanentAddressProof() {
		return newPermanentAddressProof;
	}

	public void setNewPermanentAddressProof(String newPermanentAddressProof) {
		this.newPermanentAddressProof = newPermanentAddressProof;
	}

	public String getNewTelephoneNo() {
		return newTelephoneNo;
	}

	public void setNewTelephoneNo(String newTelephoneNo) {
		this.newTelephoneNo = newTelephoneNo;
	}

	public String getNewTelephoneNoAlt() {
		return newTelephoneNoAlt;
	}

	public void setNewTelephoneNoAlt(String newTelephoneNoAlt) {
		this.newTelephoneNoAlt = newTelephoneNoAlt;
	}

	public String getNewMobileNo() {
		return newMobileNo;
	}

	public void setNewMobileNo(String newMobileNo) {
		this.newMobileNo = newMobileNo;
	}

	public String getNewEmailId() {
		return newEmailId;
	}

	public void setNewEmailId(String newEmailId) {
		this.newEmailId = newEmailId;
	}

	public String getNewEmailIdAlt() {
		return newEmailIdAlt;
	}

	public void setNewEmailIdAlt(String newEmailIdAlt) {
		this.newEmailIdAlt = newEmailIdAlt;
	}

	public String getNewFaxNo() {
		return newFaxNo;
	}

	public void setNewFaxNo(String newFaxNo) {
		this.newFaxNo = newFaxNo;
	}

	public String getNewRelationshipProof() {
		return newRelationshipProof;
	}

	public void setNewRelationshipProof(String newRelationshipProof) {
		this.newRelationshipProof = newRelationshipProof;
	}

	public void setNewGender(String newGender) {
		this.newGender = newGender;
	}

	public String getNewGender() {
		return newGender;
	}

	public void setNewRelationshipProofOthers(String newRelationshipProofOthers) {
		this.newRelationshipProofOthers = newRelationshipProofOthers;
	}

	public String getNewRelationshipProofOthers() {
		return newRelationshipProofOthers;
	}

	public String getNameChangeProof() {
		return nameChangeProof;
	}

	public void setNameChangeProof(String nameChangeProof) {
		this.nameChangeProof = nameChangeProof;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		if (pan != null) {
			this.pan = pan.trim().toUpperCase();
		} else {
			this.pan = pan;
		}
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getNewPan() {
		return newPan;
	}

	public void setNewPan(String newPan) {
		this.newPan = newPan;
	}

	public String getNewUid() {
		return newUid;
	}

	public void setNewUid(String newUid) {
		this.newUid = newUid;
	}

	public String getHidden1() {
		return hidden1;
	}

	public void setHidden1(String hidden1) {
		this.hidden1 = hidden1;
	}

	public String getHidden2() {
		return hidden2;
	}

	public void setHidden2(String hidden2) {
		this.hidden2 = hidden2;
	}

	public String getFlag1() {
		return flag1;
	}

	public void setFlag1(String flag1) {
		this.flag1 = flag1;
	}

	public String getFlag2() {
		return flag2;
	}

	public void setFlag2(String flag2) {
		this.flag2 = flag2;
	}

	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}

	public String getIdProof() {
		return idProof;
	}

	public void setNameChangeProofOfFaterOrHus(String nameChangeProofOfFaterOrHus) {
		this.nameChangeProofOfFaterOrHus = nameChangeProofOfFaterOrHus;
	}

	public String getNameChangeProofOfFaterOrHus() {
		return nameChangeProofOfFaterOrHus;
	}

	public String getIcCd() {
		return icCd;
	}

	public void setIcCd(String icCd) {
		this.icCd = icCd;
	}

	public String getIcName() {
		return icName;
	}

	public void setIcName(String icName) {
		this.icName = icName;
	}

	public String getIcBranchCd() {
		return icBranchCd;
	}

	public void setIcBranchCd(String icBranchCd) {
		this.icBranchCd = icBranchCd;
	}

	public String getIcBranchName() {
		return icBranchName;
	}

	public void setIcBranchName(String icBranchName) {
		this.icBranchName = icBranchName;
	}

	public String getIsIcBranchHO() {
		return isIcBranchHO;
	}

	public void setIsIcBranchHO(String isIcBranchHO) {
		this.isIcBranchHO = isIcBranchHO;
	}

	public String getApCd() {
		return apCd;
	}

	public void setApCd(String apCd) {
		this.apCd = apCd;
	}

	public String getApName() {
		return apName;
	}

	public void setApName(String apName) {
		this.apName = apName;
	}

	public String getApBranchCd() {
		return apBranchCd;
	}

	public void setApBranchCd(String apBranchCd) {
		this.apBranchCd = apBranchCd;
	}

	public String getApBranchName() {
		return apBranchName;
	}

	public void setApBranchName(String apBranchName) {
		this.apBranchName = apBranchName;
	}

	public String getIsApBranchHO() {
		return isApBranchHO;
	}

	public void setIsApBranchHO(String isApBranchHO) {
		this.isApBranchHO = isApBranchHO;
	}

	public String getApOrICCode() {
		return apOrICCode;
	}

	public void setApOrICCode(String apOrICCode) {
		this.apOrICCode = apOrICCode;
	}

	public String getApOrICName() {
		return apOrICName;
	}

	public void setApOrICName(String apOrICName) {
		this.apOrICName = apOrICName;
	}

	public String getApOrICBranchCode() {
		return apOrICBranchCode;
	}

	public void setApOrICBranchCode(String apOrICBranchCode) {
		this.apOrICBranchCode = apOrICBranchCode;
	}

	public String getApOrICBranchName() {
		return apOrICBranchName;
	}

	public void setApOrICBranchName(String apOrICBranchName) {
		this.apOrICBranchName = apOrICBranchName;
	}

	public String getIsApOrIcBranchHO() {
		return isApOrIcBranchHO;
	}

	public void setIsApOrIcBranchHO(String isApOrIcBranchHO) {
		this.isApOrIcBranchHO = isApOrIcBranchHO;
	}

	public String getEntityCode() {
		return entityCode;
	}

	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getSelectedApOrIcBranchCode() {
		return selectedApOrIcBranchCode;
	}

	public void setSelectedApOrIcBranchCode(String selectedApOrIcBranchCode) {
		this.selectedApOrIcBranchCode = selectedApOrIcBranchCode;
	}

	public String getSelectedApOrIcBranchName() {
		return selectedApOrIcBranchName;
	}

	public void setSelectedApOrIcBranchName(String selectedApOrIcBranchName) {
		this.selectedApOrIcBranchName = selectedApOrIcBranchName;
	}

	public String getSelectedApOrIcBranchUserCode() {
		return selectedApOrIcBranchUserCode;
	}

	public void setSelectedApOrIcBranchUserCode(String selectedApOrIcBranchUserCode) {
		this.selectedApOrIcBranchUserCode = selectedApOrIcBranchUserCode;
	}

	public String getSelectedApOrIcBranchUserName() {
		return selectedApOrIcBranchUserName;
	}

	public void setSelectedApOrIcBranchUserName(String selectedApOrIcBranchUserName) {
		this.selectedApOrIcBranchUserName = selectedApOrIcBranchUserName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getAuthRepSameAsApplSoleAddressRadio() {
		return authRepSameAsApplSoleAddressRadio;
	}

	public void setAuthRepSameAsApplSoleAddressRadio(String authRepSameAsApplSoleAddressRadio) {
		this.authRepSameAsApplSoleAddressRadio = authRepSameAsApplSoleAddressRadio;
	}

	public String getOtpOrBiometricFlag() {
		return otpOrBiometricFlag;
	}

	public void setOtpOrBiometricFlag(String otpOrBiometricFlag) {
		this.otpOrBiometricFlag = otpOrBiometricFlag;
	}

	public String getOtpFlag() {
		return otpFlag;
	}

	public void setOtpFlag(String otpFlag) {
		this.otpFlag = otpFlag;
	}

	public String getBiometricFlag() {
		return biometricFlag;
	}

	public void setBiometricFlag(String biometricFlag) {
		this.biometricFlag = biometricFlag;
	}

	public String getPasswordChangeFlag() {
		return passwordChangeFlag;
	}

	public void setPasswordChangeFlag(String passwordChangeFlag) {
		this.passwordChangeFlag = passwordChangeFlag;
	}

	public String getIsPanPresent() {
		return isPanPresent;
	}

	public void setIsPanPresent(String isPanPresent) {
		this.isPanPresent = isPanPresent;
	}

	public String getIsUidPresent() {
		return isUidPresent;
	}

	public void setIsUidPresent(String isUidPresent) {
		this.isUidPresent = isUidPresent;
	}

	public String getIsPanChanged() {
		return isPanChanged;
	}

	public void setIsPanChanged(String isPanChanged) {
		this.isPanChanged = isPanChanged;
	}

	public String getIsUidChanged() {
		return isUidChanged;
	}

	public void setIsUidChanged(String isUidChanged) {
		this.isUidChanged = isUidChanged;
	}

	public String getCorrespondenceAddressSameAsPermanent() {
		return correspondenceAddressSameAsPermanent;
	}

	public void setCorrespondenceAddressSameAsPermanent(String correspondenceAddressSameAsPermanent) {
		this.correspondenceAddressSameAsPermanent = correspondenceAddressSameAsPermanent;
	}

	public String getAddressSameAsP1Address() {
		return addressSameAsP1Address;
	}

	public void setAddressSameAsP1Address(String addressSameAsP1Address) {
		this.addressSameAsP1Address = addressSameAsP1Address;
	}

	// public MultipartFile getIdProofFilePath() {
	// return idProofFilePath;
	// }
	//
	// public void setIdProofFilePath(MultipartFile idProofFilePath) {
	// this.idProofFilePath = idProofFilePath;
	// }
	//
	// public MultipartFile getDateOfBirthProofFilePath() {
	// return dateOfBirthProofFilePath;
	// }
	//
	// public void setDateOfBirthProofFilePath(MultipartFile
	// dateOfBirthProofFilePath) {
	// this.dateOfBirthProofFilePath = dateOfBirthProofFilePath;
	// }
	//
	// public MultipartFile getPermanentAddressProofFilePath() {
	// return permanentAddressProofFilePath;
	// }
	//
	// public void setPermanentAddressProofFilePath(MultipartFile
	// permanentAddressProofFilePath) {
	// this.permanentAddressProofFilePath = permanentAddressProofFilePath;
	// }
	//
	// public MultipartFile getCorrespondenceAddressProofFilePath() {
	// return correspondenceAddressProofFilePath;
	// }
	//
	// public void setCorrespondenceAddressProofFilePath(MultipartFile
	// correspondenceAddressProofFilePath) {
	// this.correspondenceAddressProofFilePath = correspondenceAddressProofFilePath;
	// }
	// public MultipartFile getEiaApplicationFormFilePath() {
	// return eiaApplicationFormFilePath;
	// }
	//
	// public void setEiaApplicationFormFilePath(MultipartFile
	// eiaApplicationFormFilePath) {
	// this.eiaApplicationFormFilePath = eiaApplicationFormFilePath;
	// }
	//
	// public MultipartFile getEiaAllInOneProofFilePath() {
	// return eiaAllInOneProofFilePath;
	// }
	//
	// public void setEiaAllInOneProofFilePath(MultipartFile
	// eiaAllInOneProofFilePath) {
	// this.eiaAllInOneProofFilePath = eiaAllInOneProofFilePath;
	// }

	public String getIdProofFilePathDownload() {
		return idProofFilePathDownload;
	}

	public void setIdProofFilePathDownload(String idProofFilePathDownload) {
		this.idProofFilePathDownload = idProofFilePathDownload;
	}

	public String getDateOfBirthProofFilePathDownload() {
		return dateOfBirthProofFilePathDownload;
	}

	public void setDateOfBirthProofFilePathDownload(String dateOfBirthProofFilePathDownload) {
		this.dateOfBirthProofFilePathDownload = dateOfBirthProofFilePathDownload;
	}

	public String getPermanentAddressProofFilePathDownload() {
		return permanentAddressProofFilePathDownload;
	}

	public void setPermanentAddressProofFilePathDownload(String permanentAddressProofFilePathDownload) {
		this.permanentAddressProofFilePathDownload = permanentAddressProofFilePathDownload;
	}

	public String getCorrespondenceAddressProofFilePathDownload() {
		return correspondenceAddressProofFilePathDownload;
	}

	public void setCorrespondenceAddressProofFilePathDownload(String correspondenceAddressProofFilePathDownload) {
		this.correspondenceAddressProofFilePathDownload = correspondenceAddressProofFilePathDownload;
	}

	public String getEiaApplicationFormProof() {
		return eiaApplicationFormProof;
	}

	public void setEiaApplicationFormProof(String eiaApplicationFormProof) {
		this.eiaApplicationFormProof = eiaApplicationFormProof;
	}

	public String getEiaAllInOneProof() {
		return eiaAllInOneProof;
	}

	public void setEiaAllInOneProof(String eiaAllInOneProof) {
		this.eiaAllInOneProof = eiaAllInOneProof;
	}

	public String getEiaApplicationFormPathDownload() {
		return eiaApplicationFormPathDownload;
	}

	public void setEiaApplicationFormPathDownload(String eiaApplicationFormPathDownload) {
		this.eiaApplicationFormPathDownload = eiaApplicationFormPathDownload;
	}

	public String getEiaAllInOneProofPathDownload() {
		return eiaAllInOneProofPathDownload;
	}

	public void setEiaAllInOneProofPathDownload(String eiaAllInOneProofPathDownload) {
		this.eiaAllInOneProofPathDownload = eiaAllInOneProofPathDownload;
	}

	public CommonsMultipartFile getIdProofFilePath() {
		return idProofFilePath;
	}

	public void setIdProofFilePath(CommonsMultipartFile idProofFilePath) {
		this.idProofFilePath = idProofFilePath;
	}

	public CommonsMultipartFile getDateOfBirthProofFilePath() {
		return dateOfBirthProofFilePath;
	}

	public void setDateOfBirthProofFilePath(CommonsMultipartFile dateOfBirthProofFilePath) {
		this.dateOfBirthProofFilePath = dateOfBirthProofFilePath;
	}

	public CommonsMultipartFile getPermanentAddressProofFilePath() {
		return permanentAddressProofFilePath;
	}

	public void setPermanentAddressProofFilePath(CommonsMultipartFile permanentAddressProofFilePath) {
		this.permanentAddressProofFilePath = permanentAddressProofFilePath;
	}

	public CommonsMultipartFile getCorrespondenceAddressProofFilePath() {
		return correspondenceAddressProofFilePath;
	}

	public void setCorrespondenceAddressProofFilePath(CommonsMultipartFile correspondenceAddressProofFilePath) {
		this.correspondenceAddressProofFilePath = correspondenceAddressProofFilePath;
	}

	public CommonsMultipartFile getEiaApplicationFormFilePath() {
		return eiaApplicationFormFilePath;
	}

	public void setEiaApplicationFormFilePath(CommonsMultipartFile eiaApplicationFormFilePath) {
		this.eiaApplicationFormFilePath = eiaApplicationFormFilePath;
	}

	public CommonsMultipartFile getEiaAllInOneProofFilePath() {
		return eiaAllInOneProofFilePath;
	}

	public void setEiaAllInOneProofFilePath(CommonsMultipartFile eiaAllInOneProofFilePath) {
		this.eiaAllInOneProofFilePath = eiaAllInOneProofFilePath;
	}

	public String getPanOld() {
		return panOld;
	}

	public void setPanOld(String panOld) {
		this.panOld = panOld;
	}

	public String getUidOld() {
		return uidOld;
	}

	public void setUidOld(String uidOld) {
		this.uidOld = uidOld;
	}

	public String getIdProofFilePathTemp() {
		return idProofFilePathTemp;
	}

	public void setIdProofFilePathTemp(String idProofFilePathTemp) {
		this.idProofFilePathTemp = idProofFilePathTemp;
	}

	public String getDateOfBirthProofFilePathTemp() {
		return dateOfBirthProofFilePathTemp;
	}

	public void setDateOfBirthProofFilePathTemp(String dateOfBirthProofFilePathTemp) {
		this.dateOfBirthProofFilePathTemp = dateOfBirthProofFilePathTemp;
	}

	public String getPermanentAddressProofFilePathTemp() {
		return permanentAddressProofFilePathTemp;
	}

	public void setPermanentAddressProofFilePathTemp(String permanentAddressProofFilePathTemp) {
		this.permanentAddressProofFilePathTemp = permanentAddressProofFilePathTemp;
	}

	public String getCorrespondenceAddressProofFilePathTemp() {
		return correspondenceAddressProofFilePathTemp;
	}

	public void setCorrespondenceAddressProofFilePathTemp(String correspondenceAddressProofFilePathTemp) {
		this.correspondenceAddressProofFilePathTemp = correspondenceAddressProofFilePathTemp;
	}

	public String getEiaApplicationFormFilePathTemp() {
		return eiaApplicationFormFilePathTemp;
	}

	public void setEiaApplicationFormFilePathTemp(String eiaApplicationFormFilePathTemp) {
		this.eiaApplicationFormFilePathTemp = eiaApplicationFormFilePathTemp;
	}

	public String getEiaAllInOneProofFilePathTemp() {
		return eiaAllInOneProofFilePathTemp;
	}

	public void setEiaAllInOneProofFilePathTemp(String eiaAllInOneProofFilePathTemp) {
		this.eiaAllInOneProofFilePathTemp = eiaAllInOneProofFilePathTemp;
	}

	public String getIdProofFileDelete() {
		return idProofFileDelete;
	}

	public void setIdProofFileDelete(String idProofFileDelete) {
		this.idProofFileDelete = idProofFileDelete;
	}

	public String getDateOfBirthProofFileDelete() {
		return dateOfBirthProofFileDelete;
	}

	public void setDateOfBirthProofFileDelete(String dateOfBirthProofFileDelete) {
		this.dateOfBirthProofFileDelete = dateOfBirthProofFileDelete;
	}

	public String getPermanentAddressProofDelete() {
		return permanentAddressProofDelete;
	}

	public void setPermanentAddressProofDelete(String permanentAddressProofDelete) {
		this.permanentAddressProofDelete = permanentAddressProofDelete;
	}

	public String getCorrespondenceAddressProofFileDelete() {
		return correspondenceAddressProofFileDelete;
	}

	public void setCorrespondenceAddressProofFileDelete(String correspondenceAddressProofFileDelete) {
		this.correspondenceAddressProofFileDelete = correspondenceAddressProofFileDelete;
	}

	public String getEiaApplicationFormFileDelete() {
		return eiaApplicationFormFileDelete;
	}

	public void setEiaApplicationFormFileDelete(String eiaApplicationFormFileDelete) {
		this.eiaApplicationFormFileDelete = eiaApplicationFormFileDelete;
	}

	public String getEiaAllInOneProofFileDelete() {
		return eiaAllInOneProofFileDelete;
	}

	public void setEiaAllInOneProofFileDelete(String eiaAllInOneProofFileDelete) {
		this.eiaAllInOneProofFileDelete = eiaAllInOneProofFileDelete;
	}

	public String getMobileNoOld() {
		return mobileNoOld;
	}

	public void setMobileNoOld(String mobileNoOld) {
		this.mobileNoOld = mobileNoOld;
	}

	public String getEmailIdOld() {
		return emailIdOld;
	}

	public void setEmailIdOld(String emailIdOld) {
		this.emailIdOld = emailIdOld;
	}

	public String getPoi() {
		return poi;
	}

	public void setPoi(String poi) {
		this.poi = poi;
	}

}