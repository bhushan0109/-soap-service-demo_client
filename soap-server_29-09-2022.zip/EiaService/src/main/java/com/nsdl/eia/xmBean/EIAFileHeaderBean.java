package com.nsdl.eia.xmBean;

import java.io.Serializable;

public class EIAFileHeaderBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private String fileId;

	private String from;

	private String dateOfGeneration;

	private String fileType;

	private String numOfEIAAccountDetails;

	private String fVUVersion = null;

	private String fVUHash = null;

	private String xmlEncoding;

	private String xmlVersion;

	private String xmlDocType;

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getDateOfGeneration() {
		return dateOfGeneration;
	}

	public void setDateOfGeneration(String dateOfGeneration) {
		this.dateOfGeneration = dateOfGeneration;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getNumOfEIAAccountDetails() {
		return numOfEIAAccountDetails;
	}

	public void setNumOfEIAAccountDetails(String numOfEIAAccountDetails) {
		this.numOfEIAAccountDetails = numOfEIAAccountDetails;
	}

	public String getfVUVersion() {
		return fVUVersion;
	}

	public void setfVUVersion(String fVUVersion) {
		this.fVUVersion = fVUVersion;
	}

	public String getfVUHash() {
		return fVUHash;
	}

	public void setfVUHash(String fVUHash) {
		this.fVUHash = fVUHash;
	}

	public String getXmlEncoding() {
		return xmlEncoding;
	}

	public void setXmlEncoding(String xmlEncoding) {
		this.xmlEncoding = xmlEncoding;
	}

	public String getXmlVersion() {
		return xmlVersion;
	}

	public void setXmlVersion(String xmlVersion) {
		this.xmlVersion = xmlVersion;
	}

	public String getXmlDocType() {
		return xmlDocType;
	}

	public void setXmlDocType(String xmlDocType) {
		this.xmlDocType = xmlDocType;
	}
}
