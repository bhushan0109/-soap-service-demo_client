package com.nsdl.eia.xmBean;

import java.io.Serializable;
import java.util.List;

public class EIAMasterBean implements Serializable {
	private static final long serialVersionUID = 1L;

	List<AccountOpeningFormBean> accountOpeningFormBeanList;

	private EIAFileHeaderBean eIAFileHeaderBean;

	public List<AccountOpeningFormBean> getAccountOpeningFormBeanList() {
		return accountOpeningFormBeanList;
	}

	public void setAccountOpeningFormBeanList(List<AccountOpeningFormBean> accountOpeningFormBeanList) {
		this.accountOpeningFormBeanList = accountOpeningFormBeanList;
	}

	public EIAFileHeaderBean geteIAFileHeaderBean() {
		return eIAFileHeaderBean;
	}

	public void seteIAFileHeaderBean(EIAFileHeaderBean eIAFileHeaderBean) {
		this.eIAFileHeaderBean = eIAFileHeaderBean;
	}
}