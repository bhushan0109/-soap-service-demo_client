package com.nsdl.eia.entity;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the CRIP_EIA_PRP_ATHRP_ADDR database table.
 */
@Entity
@Table(name = "NIR.CRIP_EIA_PRP_ATHRP_ADDR")
public class CripEiaPrpAthrpAddr implements Serializable, Auditable {
	/**
	 * The primary key class for the CRIP_PRP_ATHRP_ADDR database table.
	 */
	public String[] getId() {
		String[] id = new String[3];
		id[0] = "CPAA_EIA_ACCT_ID:" + pk.cpaaEiaAcctId;
		id[1] = "CPAA_PRP_ATHRP_FLAG:" + pk.cpaaPrpAthrpFlag;
		id[2] = "CPAA_PRP_ATHRP_ADDR_TYPE:" + pk.cpaaPrpAthrpAddrType;
		return id;
	}

	@Embeddable
	public static class CripPrpAthrpAddrPK implements Serializable {
		private static final long serialVersionUID = 1L;

		@Column(name = "CPAA_EIA_ACCT_ID")
		private String cpaaEiaAcctId;

		@Column(name = "CPAA_PRP_ATHRP_FLAG")
		private String cpaaPrpAthrpFlag;

		@Column(name = "CPAA_PRP_ATHRP_ADDR_TYPE")
		private String cpaaPrpAthrpAddrType;

		public CripPrpAthrpAddrPK() {
			super();
		}

		public CripPrpAthrpAddrPK(String cpaaEiaAcctId, String cpaaPrpAthrpFlag, String cpaaPrpAthrpAddrType) {
			this.cpaaEiaAcctId = cpaaEiaAcctId;
			this.cpaaPrpAthrpAddrType = cpaaPrpAthrpAddrType;
			this.cpaaPrpAthrpFlag = cpaaPrpAthrpFlag;
		}

		public String getCpaaEiaAcctId() {
			return this.cpaaEiaAcctId;
		}

		public void setCpaaEiaAcctId(String cpaaEiaAcctId) {
			this.cpaaEiaAcctId = cpaaEiaAcctId;
		}

		public String getCpaaPrpAthrpFlag() {
			return this.cpaaPrpAthrpFlag;
		}

		public void setCpaaPrpAthrpFlag(String cpaaPrpAthrpFlag) {
			this.cpaaPrpAthrpFlag = cpaaPrpAthrpFlag;
		}

		public String getCpaaPrpAthrpAddrType() {
			return this.cpaaPrpAthrpAddrType;
		}

		public void setCpaaPrpAthrpAddrType(String cpaaPrpAthrpAddrType) {
			this.cpaaPrpAthrpAddrType = cpaaPrpAthrpAddrType;
		}

		public boolean equals(Object other) {
			if (this == other) {
				return true;
			}
			if (!(other instanceof CripPrpAthrpAddrPK)) {
				return false;
			}
			CripPrpAthrpAddrPK castOther = (CripPrpAthrpAddrPK) other;
			return this.cpaaEiaAcctId.equals(castOther.cpaaEiaAcctId)
					&& this.cpaaPrpAthrpFlag.equals(castOther.cpaaPrpAthrpFlag)
					&& this.cpaaPrpAthrpAddrType.equals(castOther.cpaaPrpAthrpAddrType);
		}

		public int hashCode() {
			final int prime = 31;
			int hash = 17;
			hash = hash * prime + this.cpaaEiaAcctId.hashCode();
			hash = hash * prime + this.cpaaPrpAthrpFlag.hashCode();
			hash = hash * prime + this.cpaaPrpAthrpAddrType.hashCode();
			return hash;
		}
	}

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CripPrpAthrpAddrPK pk = new CripPrpAthrpAddrPK();

	@Column(name = "CPAA_BLK_TLUK_SUB_DIV_TWN")
	private String cpaaBlkTlukSubDivTwn;

	@Column(name = "CPAA_CNS_CD")
	private String cpaaCnsCd;

	@Column(name = "CPAA_COUNTRY_CD")
	private String cpaaCountryCd;

	@Column(name = "CPAA_CRT_BY")
	private String cpaaCrtBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CPAA_CRT_DATE")
	private Calendar cpaaCrtDate;

	@Column(name = "CPAA_FLT_FLR_DOOR_BLK")
	private String cpaaFltFlrDoorBlk;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CPAA_LST_UPD_TMSTMP")
	private Calendar cpaaLstUpdTmstmp;

	@Column(name = "CPAA_MODF_BY")
	private String cpaaModfBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CPAA_MODF_DATE")
	private Calendar cpaaModfDate;

	@Column(name = "CPAA_PIN_CD")
	private String cpaaPinCd;

	@Column(name = "CPAA_POST_OFFC")
	private String cpaaPostOffc;

	@Column(name = "CPAA_PRMS_BLDG")
	private String cpaaPrmsBldg;

	@Column(name = "CPAA_RD_STREET_LN")
	private String cpaaRdStreetLn;

	@Column(name = "CPAA_STATE_CD")
	private String cpaaStateCd;

	@Column(name = "CPAA_OTHR_STATE")
	private String cpaaOthrState;

	@Column(name = "CPAA_VILL_AR_LOCLTY")
	private String cpaaVillArLoclty;

	@Column(name = "CPAA_ADDR_PROOF")
	private String cpaaAddrProof;

	@Column(name = "CPAA_FILEID")
	private String cpaaFileid;

	@Column(name = "CPAA_IPADDRESS")
	private String cpaaIpAddress;

	@Column(name = "CPAA_TRANSACTION_ID")
	private Long cpaaTxId;

	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "CPAA_EIA_ACCT_ID", referencedColumnName = "CEPA_EIA_ACCT_ID", insertable = false, updatable = false),
			@JoinColumn(name = "CPAA_PRP_ATHRP_FLAG", referencedColumnName = "CEPA_PRP_ATHRP_FLAG", insertable = false, updatable = false) })
	private CripEiaPrpsrAthrp cripEiaPrpsrAthrp;

	public CripEiaPrpAthrpAddr() {
		super();
	}

	public CripEiaPrpsrAthrp getCripEiaPrpsrAthrp() {
		return cripEiaPrpsrAthrp;
	}

	public void setCripEiaPrpsrAthrp(CripEiaPrpsrAthrp cripEiaPrpsrAthrp) {
		this.cripEiaPrpsrAthrp = cripEiaPrpsrAthrp;
	}

	public String getCpaaOthrState() {
		return cpaaOthrState;
	}

	public void setCpaaOthrState(String cpaaOthrState) {
		this.cpaaOthrState = cpaaOthrState;
	}

	public String getCpaaBlkTlukSubDivTwn() {
		return this.cpaaBlkTlukSubDivTwn;
	}

	public void setCpaaBlkTlukSubDivTwn(String cpaaBlkTlukSubDivTwn) {
		this.cpaaBlkTlukSubDivTwn = cpaaBlkTlukSubDivTwn;
	}

	public String getCpaaCnsCd() {
		return this.cpaaCnsCd;
	}

	public void setCpaaCnsCd(String cpaaCnsCd) {
		this.cpaaCnsCd = cpaaCnsCd;
	}

	public String getCpaaCountryCd() {
		return this.cpaaCountryCd;
	}

	public void setCpaaCountryCd(String cpaaCountryCd) {
		this.cpaaCountryCd = cpaaCountryCd;
	}

	public String getCpaaCrtBy() {
		return this.cpaaCrtBy;
	}

	public void setCpaaCrtBy(String cpaaCrtBy) {
		this.cpaaCrtBy = cpaaCrtBy;
	}

	public Calendar getCpaaCrtDate() {
		return this.cpaaCrtDate;
	}

	public void setCpaaCrtDate(Calendar cpaaCrtDate) {
		this.cpaaCrtDate = cpaaCrtDate;
	}

	public String getCpaaFltFlrDoorBlk() {
		return this.cpaaFltFlrDoorBlk;
	}

	public void setCpaaFltFlrDoorBlk(String cpaaFltFlrDoorBlk) {
		this.cpaaFltFlrDoorBlk = cpaaFltFlrDoorBlk;
	}

	public Calendar getCpaaLstUpdTmstmp() {
		return this.cpaaLstUpdTmstmp;
	}

	public void setCpaaLstUpdTmstmp(Calendar cpaaLstUpdTmstmp) {
		this.cpaaLstUpdTmstmp = cpaaLstUpdTmstmp;
	}

	public String getCpaaModfBy() {
		return this.cpaaModfBy;
	}

	public void setCpaaModfBy(String cpaaModfBy) {
		this.cpaaModfBy = cpaaModfBy;
	}

	public Calendar getCpaaModfDate() {
		return this.cpaaModfDate;
	}

	public void setCpaaModfDate(Calendar cpaaModfDate) {
		this.cpaaModfDate = cpaaModfDate;
	}

	public String getCpaaPinCd() {
		return this.cpaaPinCd;
	}

	public void setCpaaPinCd(String cpaaPinCd) {
		this.cpaaPinCd = cpaaPinCd;
	}

	public String getCpaaPostOffc() {
		return this.cpaaPostOffc;
	}

	public void setCpaaPostOffc(String cpaaPostOffc) {
		this.cpaaPostOffc = cpaaPostOffc;
	}

	public String getCpaaPrmsBldg() {
		return this.cpaaPrmsBldg;
	}

	public void setCpaaPrmsBldg(String cpaaPrmsBldg) {
		this.cpaaPrmsBldg = cpaaPrmsBldg;
	}

	public String getCpaaRdStreetLn() {
		return this.cpaaRdStreetLn;
	}

	public void setCpaaRdStreetLn(String cpaaRdStreetLn) {
		this.cpaaRdStreetLn = cpaaRdStreetLn;
	}

	public String getCpaaStateCd() {
		return this.cpaaStateCd;
	}

	public void setCpaaStateCd(String cpaaStateCd) {
		this.cpaaStateCd = cpaaStateCd;
	}

	public String getCpaaVillArLoclty() {
		return this.cpaaVillArLoclty;
	}

	public void setCpaaVillArLoclty(String cpaaVillArLoclty) {
		this.cpaaVillArLoclty = cpaaVillArLoclty;
	}

	public void setPk(CripPrpAthrpAddrPK pk) {
		this.pk = pk;
	}

	public CripPrpAthrpAddrPK getPk() {
		return pk;
	}

	public void setCpaaAddrProof(String cpaaAddrProof) {
		this.cpaaAddrProof = cpaaAddrProof;
	}

	public String getCpaaAddrProof() {
		return cpaaAddrProof;
	}

	public void setCpaaTxId(Long cpaaTxId) {
		this.cpaaTxId = cpaaTxId;
	}

	public Long getCpaaTxId() {
		return cpaaTxId;
	}

	public String getCpaaFileid() {
		return cpaaFileid;
	}

	public void setCpaaFileid(String cpaaFileid) {
		this.cpaaFileid = cpaaFileid;
	}

	public String getCpaaIpAddress() {
		return cpaaIpAddress;
	}

	public void setCpaaIpAddress(String cpaaIpAddress) {
		this.cpaaIpAddress = cpaaIpAddress;
	}
}
