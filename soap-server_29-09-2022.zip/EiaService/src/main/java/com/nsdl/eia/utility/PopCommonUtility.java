package com.nsdl.eia.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.nsdl.eia.constants.NIRConstants;

import com.nsdl.eia.xmBean.AccountOpeningFormBean;

import org.apache.commons.io.FileUtils;
//import org.apache.log4j.Logger;
//
//import com.itextpdf.text.pdf.AcroFields;
//import com.itextpdf.text.pdf.PdfReader;
//import com.itextpdf.text.pdf.PdfStamper;
//import com.ndml.nir.app.pop.service.PopDropdownService;
//import com.ndml.nir.common.constants.NIRConstants;
//import com.ndml.nir.pop.beans.AccountOpeningFormBean;

public class PopCommonUtility {
	// private static final Logger LOGGER =
	// Logger.getLogger(PopCommonUtility.class);
	private static Logger LOGGER = LogManager.getLogger(PopCommonUtility.class);

	public static final String EIA_PDF_TEMPLATE_PATH = "/app/nir/nir-properties/Templates/PDF/NDMLeIAApplicationForm.pdf";

	public static final String EIA_PDF_OUTPUT_PATH = NIRConstants.BASE_FILE_SYSTEM_PATH + "PDF/OnlineEiaApplication/";

	// static PopDropdownService popDropdownService = new PopDropdownServiceImpl();
	//
	// static Map<?, ?> stateMap = popDropdownService.getStateDD();
	//
	// static Map<?, ?> countryMap = popDropdownService.getCountryDD();
	//
	// public static Map<String, String> bankNameMap =
	// popDropdownService.getBankDDMap();
	//
	// static Map<?, ?> bankAccountMap =
	// popDropdownService.getListByCode("BNKACT_TYP");
	//
	// static Map<?, ?> relationshipProofMap = popDropdownService.getRelationShip();

	public static SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

	public static String fillerMethodNullBlank1(Object input) {
		if (input == null || input.toString().trim().equals(NIRConstants.BLANK_STRING)) {
			return null;
		} else {
			return input.toString().trim();
		}
	}

	public static String fillerMethodNullBlank2(Object input) {
		if (input == null || input.toString().trim().equals(NIRConstants.BLANK_STRING)) {
			return NIRConstants.BLANK_STRING;
		} else {
			return input.toString().trim();
		}
	}

	public static String fillerMethodNullBlankToLower(Object input) {
		if (input == null || input.toString().trim().equals(NIRConstants.BLANK_STRING)) {
			return NIRConstants.BLANK_STRING;
		} else {
			return input.toString().trim().toLowerCase();
		}
	}

	public static String setFullName(Object fName, Object mName, Object lName) {
		try {
			String fullName = ((fName == null || fName.toString().trim().equals(NIRConstants.BLANK_STRING)) ? ""
					: (fName.toString().trim() + " "))
					+ ((mName == null || mName.toString().trim().equals(NIRConstants.BLANK_STRING)) ? ""
							: (mName.toString().trim() + " "))
					+ ((lName == null || lName.toString().trim().equals(NIRConstants.BLANK_STRING)) ? ""
							: (lName.toString().trim()));
			LOGGER.info("Returning with fullName-->" + fullName);
			return fullName.trim();
		} catch (Exception e) {
			LOGGER.fatal("Exception in setFullName method--->" + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
//
//	public String generateEiaApplicationPDF(AccountOpeningFormBean accountOpeningFormBean) {
//		LOGGER.info("#### 21072015 : EIA PDF Output path-->" + EIA_PDF_OUTPUT_PATH);
//		Calendar cal = Calendar.getInstance();
//		String templateFileName = "eiaApplicationForm_" + accountOpeningFormBean.getAckNo() + ".pdf";
//		// String year = String.valueOf(cal.get(Calendar.YEAR));
//		// String month = (new
//		// SimpleDateFormat("MMM").format(cal.getTime())).toUpperCase();
//		// String date = (new
//		// SimpleDateFormat("dd-MMM-yyy").format(cal.getTime())).toUpperCase();
//		// String newDir = EIA_PDF_OUTPUT_PATH + year + "/" + month + "/" + date + "/";
//		String newDir = EIA_PDF_OUTPUT_PATH + SDF.format(new java.util.Date()) + File.separator;
//		String completeOnlineEiaPDFPath = newDir + templateFileName;
//		LOGGER.info("#### 21072015 : Complete PDF file path-->" + completeOnlineEiaPDFPath);
//		if (!(new File(newDir)).exists()) {
//			try {
//				FileUtils.forceMkdir(new File(newDir));
//			} catch (IOException e) {
//				e.printStackTrace();
//				LOGGER.fatal("Exception occured while creating directory for online Eia PDF-->" + e.getMessage());
//				return null;
//			}
//		}
//		// pdf Generation Code Start Here
//		try {
//			PdfReader templatePdfReader = new PdfReader(EIA_PDF_TEMPLATE_PATH);
//			PdfStamper stamper;
//			stamper = new PdfStamper(templatePdfReader, new FileOutputStream(completeOnlineEiaPDFPath));
//			AcroFields templateFields = stamper.getAcroFields();
//			/*
//			 * Set<String> fldNames = templateFields.getFields().keySet(); for (String
//			 * fldName : fldNames) { LOGGER.info("Fields in PDF are-->" + fldName + " -- " +
//			 * templateFields.getField(fldName)); }
//			 */
//			/*--------------------Type of eIA--------------------*/
//			LOGGER.info("#### 21072015 : Ack no-->" + accountOpeningFormBean.getAckNo());
//			templateFields.setField("Ack_No", fillerMethodNullBlank2(accountOpeningFormBean.getAckNo()));
//			if (fillerMethodNullBlank2(accountOpeningFormBean.getAccountType()).equals("02"))
//				templateFields.setField("NRI", "Yes");
//			else
//				templateFields.setField("OrdRes", "Yes");
//			/*------------Applicant's Details------------------------------*/
//			templateFields.setField("P1_PAN",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getPan()));
//			templateFields.setField("P1_UID",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getUid()));
//			templateFields.setField("P1_Frst_Nm",
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getFirstNameOfCustomer());
//			templateFields.setField("P1_Mid_Nm",
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getMiddleNameOfCustomer());
//			templateFields.setField("P1_Lst_Nm",
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getLastNameOfCustomer());
//			if (accountOpeningFormBean.getProposalDetailBeanList().get(0).getGender().equals("M")) {
//				templateFields.setField("Male", "Yes");
//			} else if (accountOpeningFormBean.getProposalDetailBeanList().get(0).getGender().equals("F")) {
//				templateFields.setField("Female", "Yes");
//			} else {
//				templateFields.setField("Gndr_Others", "Yes");
//			}
//			templateFields.setField("P1_Fthr_Nm",
//					setFullName(accountOpeningFormBean.getProposalDetailBeanList().get(0).getFatherOrHusbandFirstName(),
//							accountOpeningFormBean.getProposalDetailBeanList().get(0).getFatherOrHusbandMiddleName(),
//							accountOpeningFormBean.getProposalDetailBeanList().get(0).getFatherOrHusbandLastName()));
//			String dateDOB = accountOpeningFormBean.getProposalDetailBeanList().get(0).getDateOfBirth();
//			String d[] = dateDOB.split("-");
//			templateFields.setField("P1_DOB", fillerMethodNullBlank2(d[0] + d[1] + d[2]));
//			templateFields.setField("P1_IDProof",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getIdProof()));
//			/*------------------------------Permanent Address------------------------------------------*/
//			templateFields.setField("P1_Perm_Addr1", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentAddress1()));
//			templateFields.setField("P1_Perm_Addr2", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentAddress2()));
//			templateFields.setField("P1_Perm_Addr3", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentAddress3()));
//			templateFields.setField("P1_Perm_Lndmrk", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentAddress4()));
//			templateFields.setField("P1_Perm_City", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentAddress5()));
//			templateFields.setField("P1_Perm_Cntry", fillerMethodNullBlank2(countryMap.get(fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentCountry()))));
//			if (accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentCountry() != null
//					&& (accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentCountry()
//							.equalsIgnoreCase(NIRConstants.CNTY_IND)
//							|| accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentCountry()
//									.equalsIgnoreCase(NIRConstants.CNTY_IND_CODE))) {
//				LOGGER.info("Permanent country for P1 is India-->");
//				templateFields.setField("P1_Perm_State", fillerMethodNullBlank2(stateMap.get(fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentStateDD()))));
//				templateFields.setField("P1_Perm_Pin", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentPinCode()));
//			} else {
//				LOGGER.info("Permanent country for P1 is not India-->");
//				templateFields.setField("P1_Perm_State", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentStateText()));
//				templateFields.setField("P1_Perm_Pin", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(0).getPermanentPinCodeExt()));
//			}
//			templateFields.setField("P1_Perm_Addr_Proof", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getPerAddProofP1()));
//			/*--------------------------Correspondence Address----------------------------------------------*/
//			templateFields.setField("P1_Corr_Addr1", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceAddress1()));
//			templateFields.setField("P1_Corr_Addr2", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceAddress2()));
//			templateFields.setField("P1_Corr_Addr3", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceAddress3()));
//			templateFields.setField("P1_Corr_Lndmrk", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceAddress4()));
//			templateFields.setField("P1_Corr_City", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceAddress5()));
//			templateFields.setField("P1_Corr_Cntry", fillerMethodNullBlank2(countryMap.get(fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceCountry()))));
//			if (accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceCountry() != null
//					&& (accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceCountry()
//							.equalsIgnoreCase(NIRConstants.CNTY_IND)
//							|| accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceCountry()
//									.equalsIgnoreCase(NIRConstants.CNTY_IND_CODE))) {
//				LOGGER.info("Correspondence country for P1 is India-->");
//				templateFields.setField("P1_Corr_State", fillerMethodNullBlank2(stateMap.get(fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceStateDD()))));
//				templateFields.setField("P1_Corr_Pin", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondencePinCode()));
//			} else {
//				LOGGER.info("Correspondence country for P1 is not India-->");
//				templateFields.setField("P1_Corr_State", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceStateText()));
//				templateFields.setField("P1_Corr_Pin", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondencePinCodeExt()));
//			}
//			templateFields.setField("P1_Corr_Addr_Proof", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrAddProofP1()));
//			if (fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getCorrespondenceAddressSameAsPermanent())
//							.equalsIgnoreCase("Y")) {
//				templateFields.setField("P1_Same_addr_YES", "Yes");
//			} else {
//				templateFields.setField("P1_Same_Addr_NO", "Yes");
//			}
//			/*--------------------------------Contact Details-----------------------------------------*/
//			templateFields.setField("P1_Tel_No",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getTelephoneNo()));
//			templateFields.setField("P1_Alt_Tel_No", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(0).getTelephoneNoAlt()));
//			templateFields.setField("P1_Fax",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getFaxNo()));
//			templateFields.setField("P1_Mobile",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getMobileNo()));
//			templateFields.setField("P1_Email1",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getEmailId()));
//			templateFields.setField("P1_Email2",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getEmailIdAlt()));
//			templateFields.setField("eIA_No",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).geteIANo()));
//			templateFields.setField("Dt_Rcpt_Appl", fillerMethodNullBlank2(accountOpeningFormBean.getFormSubDate()));
//			templateFields.setField("App_No", fillerMethodNullBlank2(accountOpeningFormBean.getApplicationNo()));
//			templateFields.setField("Ifsc", fillerMethodNullBlank2(accountOpeningFormBean.getBankIFSCCode()));
//			templateFields.setField("AP_ID",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(0).getApOrICCode()));
//			/*--------------------------------Bank Details------------------------------*/
//			if ((fillerMethodNullBlank2(accountOpeningFormBean.getBankAccountType())).equals("01")) {
//				templateFields.setField("Saving", "Yes");
//			} else if ((fillerMethodNullBlank2(accountOpeningFormBean.getBankAccountType())).equals("02")) {
//				templateFields.setField("Current", "Yes");
//			}
//			templateFields.setField("Bnk_Acct_No", fillerMethodNullBlank2(accountOpeningFormBean.getBankAccountNo()));
//			LOGGER.info("Bank code-->" + accountOpeningFormBean.getBankName());
//			if (accountOpeningFormBean.getBankName() != null
//					&& !accountOpeningFormBean.getBankName().equalsIgnoreCase("999")) {
//				templateFields.setField("Bnk_Name", fillerMethodNullBlank2(
//						bankNameMap.get(fillerMethodNullBlank2(accountOpeningFormBean.getBankName()))));
//			} else {
//				templateFields.setField("Bnk_Name", fillerMethodNullBlank2(accountOpeningFormBean.getBankNameOthers()));
//			}
//			templateFields.setField("Bnk_Brnch", fillerMethodNullBlank2(accountOpeningFormBean.getBankAddress1()));
//			templateFields.setField("Bnk_City", fillerMethodNullBlank2(accountOpeningFormBean.getBankAddress2()));
//			templateFields.setField("Micr", fillerMethodNullBlank2(accountOpeningFormBean.getBankMICRCode()));
//			LOGGER.info("Value of BankCancelChk-->" + accountOpeningFormBean.getBankCancelChk());
//			if (accountOpeningFormBean.getBankCancelChk() != null
//					&& (accountOpeningFormBean.getBankCancelChk().equalsIgnoreCase("Y")
//							|| accountOpeningFormBean.getBankCancelChk().equalsIgnoreCase("YES"))) {
//				templateFields.setField("Cancelled_Chq", "Yes");
//			} else {
//				templateFields.setField("Cancelled_Chq", "No");
//			}
//			/*------------------------------------Authorised Representative Details------------------------*/
//			templateFields.setField("P3_Frst_Nm",
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getFirstNameOfCustomer());
//			templateFields.setField("P3_Mid_Nm",
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getMiddleNameOfCustomer());
//			templateFields.setField("P3_Lst_Nm",
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getLastNameOfCustomer());
//			if (accountOpeningFormBean.getProposalDetailBeanList().get(2).getGender().equals("M")) {
//				templateFields.setField("P3_Male", "Yes");
//			} else if (accountOpeningFormBean.getProposalDetailBeanList().get(2).getGender().equals("F")) {
//				templateFields.setField("P3_Female", "Yes");
//			} else {
//				templateFields.setField("P3_Gndr_Others", "Yes");
//			}
//			String date1 = accountOpeningFormBean.getProposalDetailBeanList().get(2).getDateOfBirth();
//			String d1[] = date1.split("-");
//			templateFields.setField("P3_DOB", fillerMethodNullBlank2(d1[0] + d1[1] + d1[2]));
//			templateFields.setField("P3_PAN",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(2).getPan()));
//			templateFields.setField("P3_UID",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(2).getUid()));
//			if (accountOpeningFormBean.getProposalDetailBeanList().get(2).getRelationshipProof() != null
//					&& !accountOpeningFormBean.getProposalDetailBeanList().get(2).getRelationshipProof()
//							.equalsIgnoreCase("99")) {
//				templateFields.setField("P3_P1_Rltn",
//						fillerMethodNullBlank2(relationshipProofMap.get(fillerMethodNullBlank2(
//								accountOpeningFormBean.getProposalDetailBeanList().get(2).getRelationshipProof()))));
//			} else {
//				templateFields.setField("P3_P1_Rltn", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(2).getRelationshipProofOthers()));
//			}
//			/*------------------------------ Address------------------------------------------*/
//			if (accountOpeningFormBean.getProposalDetailBeanList().get(2).getAddressSameAsP1Address() != null) {
//				if (accountOpeningFormBean.getProposalDetailBeanList().get(2).getAddressSameAsP1Address()
//						.equalsIgnoreCase("P")) {
//					templateFields.setField("Same_Perm_Addr_P3", "Yes");
//				} else if (accountOpeningFormBean.getProposalDetailBeanList().get(2).getAddressSameAsP1Address()
//						.equals("C")) {
//					templateFields.setField("Same_Corr_Addr_P3", "Yes");
//				}
//			}
//			templateFields.setField("P3_Addr1", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentAddress1()));
//			templateFields.setField("P3_Addr2", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentAddress2()));
//			templateFields.setField("P3_Addr3", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentAddress3()));
//			templateFields.setField("P3_Lndmrk", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentAddress4()));
//			templateFields.setField("P3_City", fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentAddress5()));
//			templateFields.setField("P3_Cntry", fillerMethodNullBlank2(countryMap.get(fillerMethodNullBlank2(
//					accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentCountry()))));
//			if (accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentCountry() != null
//					&& (accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentCountry()
//							.equalsIgnoreCase(NIRConstants.CNTY_IND)
//							|| accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentCountry()
//									.equalsIgnoreCase(NIRConstants.CNTY_IND_CODE))) {
//				LOGGER.info("Permanent country for P3 is India-->");
//				templateFields.setField("P3_State", fillerMethodNullBlank2(stateMap.get(fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentStateDD()))));
//				templateFields.setField("P3_Pin", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentPinCode()));
//			} else {
//				LOGGER.info("Permanent country for P3 is not India-->");
//				templateFields.setField("P3_State", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentStateText()));
//				templateFields.setField("P3_Pin", fillerMethodNullBlank2(
//						accountOpeningFormBean.getProposalDetailBeanList().get(2).getPermanentPinCodeExt()));
//			}
//			/*--------------------------------Contact Details-----------------------------------------*/
//			templateFields.setField("P3_Tel",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(2).getTelephoneNo()));
//			templateFields.setField("P3_Mobile",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(2).getMobileNo()));
//			templateFields.setField("P3_Email",
//					fillerMethodNullBlank2(accountOpeningFormBean.getProposalDetailBeanList().get(2).getEmailId()));
//			// templateFields.setField("P3_Notify", "Yes");
//			if (accountOpeningFormBean.getSentMailToAuth() != null
//					&& fillerMethodNullBlank2(accountOpeningFormBean.getSentMailToAuth()).equals("1")) {
//				templateFields.setField("P3_Notify", "Yes");
//				templateFields.setField("P3_No_Notify", "No");
//			} else {
//				templateFields.setField("P3_Notify", "No");
//				templateFields.setField("P3_No_Notify", "Yes");
//			}
//			stamper.setFormFlattening(true);
//			/*----------------------------------------------------------------------------------------*/
//			stamper.close();
//			templatePdfReader.close();
//		} catch (Exception e) {
//			LOGGER.fatal("Exception in wrting PDF-->" + e.getMessage());
//			e.printStackTrace();
//			return null;
//		}
//		return completeOnlineEiaPDFPath;
//	}
}
