package com.nsdl.eia.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nsdl.eia.otherentity.CripSysParam;
import com.nsdl.eia.otherentity.NirPartnerMstr;

public interface CripSysParamRepository extends JpaRepository<CripSysParam, Long> {
	@Query(value = "SELECT CSP_PARAM_VAL FROM NIR.CRIP_SYS_PARAM WHERE CSP_PARAM_CD=:cspParamCd", nativeQuery = true)
	String getParamValForParamCd(@Param("cspParamCd") String cspParamCd);
}