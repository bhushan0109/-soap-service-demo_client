package com.nsdl.eia.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "nir.crip_crop_person_dtls")

public class CripCropPersonDtls implements Serializable, Auditable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String[] getId() {
		String[] id = new String[2];
		id[0] = "CPD_EIA_ACCT_ID:" + pk.cpdEiaAcctId;
		id[1] = "CPD_PRS_FLAG" + pk.cpdPrsFlag;
		return id;
	}

	@Embeddable
	public static class CripCropPersonDtlsPK implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Column(name = "CPD_EIA_ACCT_ID")
		private String cpdEiaAcctId;

		@Column(name = "CPD_PRS_FLAG")
		private String cpdPrsFlag;

		public String getCpdEiaAcctId() {
			return cpdEiaAcctId;
		}

		public void setCpdEiaAcctId(String cpdEiaAcctId) {
			this.cpdEiaAcctId = cpdEiaAcctId;
		}

		public String getCpdPrsFlag() {
			return cpdPrsFlag;
		}

		public void setCpdPrsFlag(String cpdPrsFlag) {
			this.cpdPrsFlag = cpdPrsFlag;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((this.cpdEiaAcctId == null) ? 0 : this.cpdEiaAcctId.hashCode());
			result = prime * result + ((this.cpdPrsFlag == null) ? 0 : this.cpdPrsFlag.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CripCropPersonDtlsPK other = (CripCropPersonDtlsPK) obj;
			if (cpdEiaAcctId == null) {
				if (other.cpdEiaAcctId != null)
					return false;
			} else if (!cpdEiaAcctId.equals(other.cpdEiaAcctId))
				return false;
			if (cpdPrsFlag == null) {
				if (other.cpdPrsFlag != null)
					return false;
			} else if (!cpdPrsFlag.equals(other.cpdPrsFlag))
				return false;
			return true;
		}

	}

	@EmbeddedId
	private CripCropPersonDtlsPK pk = new CripCropPersonDtlsPK();

	@Column(name = "CPD_ACK_ID")
	private String cpdAckId;

	@Column(name = "CPD_PRS_NM")
	private String cpdPrsNm;

	@Column(name = "CPD_PRS_PAN")
	private String cpdPrsPan;

	@Column(name = "CPD_PRS_UID")
	private String cpdPrsUid;

	@Column(name = "CPD_PRS_MOB_NO")
	private String cpdPrsMobNo;

	@Column(name = "CPD_PRS_PH")
	private String cpdPrsPh;

	@Column(name = "CPD_PRS_EMAIL")
	private String cpdPrsEmail;

	@Column(name = "CPD_CRT_BY")
	private String cpdCrtBy;

	@Column(name = "CPD_CRT_DATE")
	private Calendar cpdCrtDate;

	@Column(name = "CPD_MODF_BY")
	private String cpdModfBy;

	@Column(name = "CPD_MODF_DATE")
	private Calendar cpdModfDate;

	@Column(name = "CPD_TRANSACTION_ID")
	private Long cpdTransactionId;

	@Column(name = "CPD_IPADDRESS")
	private String cpdIpaddress;

	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "CPD_EIA_ACCT_ID", referencedColumnName = "CEA_EIA_ACCT_ID", insertable = false, updatable = false) })
	private CripEiaAcct cripEiaAcct;

	/*
	 * @OneToMany(mappedBy="corpPersonDtls",cascade={CascadeType.PERSIST,
	 * CascadeType.MERGE, CascadeType.REFRESH, CascadeType.REMOVE }, fetch =
	 * FetchType.LAZY) private List<CripCropDocsDtlsTemp> cripCropPersonDocList;
	 */

	public String getCpdAckId() {
		return cpdAckId;
	}

	public void setCpdAckId(String cpdAckId) {
		this.cpdAckId = cpdAckId;
	}

	public String getCpdPrsNm() {
		return cpdPrsNm;
	}

	public void setCpdPrsNm(String cpdPrsNm) {
		this.cpdPrsNm = cpdPrsNm;
	}

	public String getCpdPrsPan() {
		return cpdPrsPan;
	}

	public void setCpdPrsPan(String cpdPrsPan) {
		this.cpdPrsPan = cpdPrsPan;
	}

	public String getCpdPrsUid() {
		return cpdPrsUid;
	}

	public void setCpdPrsUid(String cpdPrsUid) {
		this.cpdPrsUid = cpdPrsUid;
	}

	public String getCpdPrsMobNo() {
		return cpdPrsMobNo;
	}

	public void setCpdPrsMobNo(String cpdPrsMobNo) {
		this.cpdPrsMobNo = cpdPrsMobNo;
	}

	public String getCpdPrsPh() {
		return cpdPrsPh;
	}

	public void setCpdPrsPh(String cpdPrsPh) {
		this.cpdPrsPh = cpdPrsPh;
	}

	public String getCpdPrsEmail() {
		return cpdPrsEmail;
	}

	public void setCpdPrsEmail(String cpdPrsEmail) {
		this.cpdPrsEmail = cpdPrsEmail;
	}

	public String getCpdCrtBy() {
		return cpdCrtBy;
	}

	public void setCpdCrtBy(String cpdCrtBy) {
		this.cpdCrtBy = cpdCrtBy;
	}

	public Calendar getCpdCrtDate() {
		return cpdCrtDate;
	}

	public void setCpdCrtDate(Calendar cpdCrtDate) {
		this.cpdCrtDate = cpdCrtDate;
	}

	public String getCpdModfBy() {
		return cpdModfBy;
	}

	public void setCpdModfBy(String cpdModfBy) {
		this.cpdModfBy = cpdModfBy;
	}

	public Calendar getCpdModfDate() {
		return cpdModfDate;
	}

	public void setCpdModfDate(Calendar cpdModfDate) {
		this.cpdModfDate = cpdModfDate;
	}

	public Long getCpdTransactionId() {
		return cpdTransactionId;
	}

	public void setCpdTransactionId(Long cpdTransactionId) {
		this.cpdTransactionId = cpdTransactionId;
	}

	public String getCpdIpaddress() {
		return cpdIpaddress;
	}

	public void setCpdIpaddress(String cpdIpaddress) {
		this.cpdIpaddress = cpdIpaddress;
	}

	public CripEiaAcct getCripEiaAcct() {
		return cripEiaAcct;
	}

	public void setCripEiaAcct(CripEiaAcct cripEiaAcct) {
		this.cripEiaAcct = cripEiaAcct;
	}

	/*
	 * public List<CripCropDocsDtlsTemp> getCripCropPersonDocList() { return
	 * cripCropPersonDocList; }
	 * 
	 * 
	 * public void setCripCropPersonDocList(List<CripCropDocsDtlsTemp>
	 * cripCropPersonDocList) { this.cripCropPersonDocList = cripCropPersonDocList;
	 * }
	 */

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public CripCropPersonDtlsPK getPk() {
		return pk;
	}

	public void setPk(CripCropPersonDtlsPK pk) {
		this.pk = pk;
	}

}
