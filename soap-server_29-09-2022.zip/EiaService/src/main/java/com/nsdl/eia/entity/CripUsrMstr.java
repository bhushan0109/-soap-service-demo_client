package com.nsdl.eia.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the crip_usr_mstr database table.
 */
@Entity
@Table(name = "nir_security.CRIP_USR_MSTR")
public class CripUsrMstr implements Serializable, Auditable {
	private static final long serialVersionUID = 1L;

	public String[] getId() {
		String[] id = new String[2];
		id[0] = String.valueOf("cum_seq:" + cumSeq);
		id[1] = String.valueOf("CUM_LOGIN_ID:" + cumLoginId);
		return id;
	}

	@Id
	@TableGenerator(name = "Crip", table = "NIR.CRIP_ID_GNRTR", pkColumnName = "CIG_GEN_KEY", valueColumnName = "CIG_GEN_VALUE", pkColumnValue = "USR_ID", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "Crip")
	@Column(name = "cum_seq")
	private long cumSeq;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cum_acct_lock_tmstmp")
	private Calendar cumAcctLockTmstmp;

	@Column(name = "cum_add_line1")
	private String cumAddLine1;

	@Column(name = "cum_add_line2")
	private String cumAddLine2;

	@Column(name = "cum_add_line3")
	private String cumAddLine3;

	@Column(name = "cum_alt_email_id")
	private String cumAltEmailId;

	@Column(name = "cum_ap_or_ic_brnch_cd")
	private String cumApOrIcBrnchCd;

	@Column(name = "cum_ap_or_ic_cd")
	private String cumApOrIcCd;

	@Column(name = "cum_auth_type")
	private String cumAuthType;

	@Column(name = "cum_authorized_by")
	private String cumAuthorizedBy;

	@Column(name = "cum_bad_login_cnt")
	private Integer cumBadLoginCnt;

	@Column(name = "cum_browser")
	private String cumBrowser;

	@Column(name = "cum_ca_id")
	private Integer cumCaId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cum_cert_exp_dt")
	private Calendar cumCertExpDt;

	@Column(name = "cum_cert_sno")
	private String cumCertSno;

	@Column(name = "cum_city")
	private String cumCity;

	@Column(name = "cum_crt_by")
	private String cumCrtBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CUM_CRT_DATE")
	private Calendar cumCrtDate;

	@Column(name = "cum_dept")
	private String cumDept;

	@Column(name = "cum_desig")
	private String cumDesig;

	@Column(name = "cum_email_id")
	private String cumEmailId;

	@Column(name = "cum_emp_id")
	private String cumEmpId;

	@Column(name = "cum_entt_cd")
	private String cumEnttCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cum_failed_login_timestamp")
	private Calendar cumFailedLoginTimestamp;

	@Column(name = "cum_forg_ansr")
	private String cumForgAnsr;

	@Column(name = "cum_forg_ques")
	private String cumForgQues;

	@Column(name = "cum_frst_nm")
	private String cumFrstNm;

	@Column(name = "cum_last_ip_addr")
	private String cumLastIpAddr;

	@Column(name = "cum_login_id")
	private String cumLoginId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CUM_LST_LOGIN_DATE")
	private Calendar cumLstLoginDate;

	@Column(name = "cum_lst_nm")
	private String cumLstNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CUM_LST_UPD_TMSTMP")
	private Calendar cumLstUpdTmstmp;

	@Column(name = "cum_mid_nm")
	private String cumMidNm;

	@Column(name = "cum_mobl_num")
	private String cumMoblNum;

	@Column(name = "cum_modf_by")
	private String cumModfBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CUM_MODF_DATE")
	private Calendar cumModfDate;

	@Column(name = "cum_os")
	private String cumOs;

	@Column(name = "cum_phone_no")
	private String cumPhoneNo;

	@Column(name = "cum_pin_cd")
	private String cumPinCd;

	@Column(name = "cum_pwd")
	private String cumPwd;

	@Temporal(TemporalType.DATE)
	@Column(name = "cum_pwd_expr_date")
	private Date cumPwdExprDate;

	@Column(name = "cum_pwd_expr_flg")
	private Integer cumPwdExprFlg;

	@Column(name = "cum_rl_cd")
	private Integer cumRlCd;

	@Column(name = "cum_stat_id")
	private String cumStatId;

	@Column(name = "cum_state_cd")
	private String cumStateCd;

	@Column(name = "cum_tx_id")
	private long cumTxId;

	@Column(name = "cum_usr_logged_in")
	private Integer cumUsrLoggedIn;

	@Column(name = "cum_usr_mgmt_tx_id")
	private long cumUsrMgmtTxId;

	@Temporal(TemporalType.DATE)
	@Column(name = "cum_usr_valid_upto_dt")
	private Date cumUsrValidUptoDt;

	@Column(name = "CUM_EMAIL_SENT")
	private String cumEmailSent;

	@Column(name = "CUM_SIGLE_OTP_VAL")
	private String cumSingleOtpVal;

	// added by amirja on 03-05-2019
	@Column(name = "cum_otp_generation_time")
	private java.sql.Timestamp cumOTPGenerationTime;

	// added by amirja on 03-05-2019
	@Column(name = "cum_max_otp_limit")
	private int cumMaxOtpLimit;

	// Added for corporate Eia
	@Column(name = "cum_eia_acct_id")
	private String cumEiaAcctId;

	public String getCumEiaAcctId() {
		return cumEiaAcctId;
	}

	public void setCumEiaAcctId(String cumEiaAcctId) {
		this.cumEiaAcctId = cumEiaAcctId;
	}

	public CripUsrMstr() {
	}

	public Calendar getCumAcctLockTmstmp() {
		return this.cumAcctLockTmstmp;
	}

	public void setCumAcctLockTmstmp(Calendar cumAcctLockTmstmp) {
		this.cumAcctLockTmstmp = cumAcctLockTmstmp;
	}

	public String getCumAddLine1() {
		return this.cumAddLine1;
	}

	public void setCumAddLine1(String cumAddLine1) {
		this.cumAddLine1 = cumAddLine1;
	}

	public String getCumAddLine2() {
		return this.cumAddLine2;
	}

	public void setCumAddLine2(String cumAddLine2) {
		this.cumAddLine2 = cumAddLine2;
	}

	public String getCumAddLine3() {
		return this.cumAddLine3;
	}

	public void setCumAddLine3(String cumAddLine3) {
		this.cumAddLine3 = cumAddLine3;
	}

	public String getCumAltEmailId() {
		return this.cumAltEmailId;
	}

	public void setCumAltEmailId(String cumAltEmailId) {
		this.cumAltEmailId = cumAltEmailId;
	}

	public String getCumApOrIcBrnchCd() {
		return this.cumApOrIcBrnchCd;
	}

	public void setCumApOrIcBrnchCd(String cumApOrIcBrnchCd) {
		this.cumApOrIcBrnchCd = cumApOrIcBrnchCd;
	}

	public String getCumApOrIcCd() {
		return this.cumApOrIcCd;
	}

	public void setCumApOrIcCd(String cumApOrIcCd) {
		this.cumApOrIcCd = cumApOrIcCd;
	}

	public String getCumAuthType() {
		return this.cumAuthType;
	}

	public void setCumAuthType(String cumAuthType) {
		this.cumAuthType = cumAuthType;
	}

	public String getCumAuthorizedBy() {
		return this.cumAuthorizedBy;
	}

	public void setCumAuthorizedBy(String cumAuthorizedBy) {
		this.cumAuthorizedBy = cumAuthorizedBy;
	}

	public Integer getCumBadLoginCnt() {
		return this.cumBadLoginCnt;
	}

	public void setCumBadLoginCnt(Integer cumBadLoginCnt) {
		this.cumBadLoginCnt = cumBadLoginCnt;
	}

	public String getCumBrowser() {
		return this.cumBrowser;
	}

	public void setCumBrowser(String cumBrowser) {
		this.cumBrowser = cumBrowser;
	}

	public Integer getCumCaId() {
		return this.cumCaId;
	}

	public void setCumCaId(Integer cumCaId) {
		this.cumCaId = cumCaId;
	}

	public Calendar getCumCertExpDt() {
		return this.cumCertExpDt;
	}

	public void setCumCertExpDt(Calendar cumCertExpDt) {
		this.cumCertExpDt = cumCertExpDt;
	}

	public String getCumCertSno() {
		return this.cumCertSno;
	}

	public void setCumCertSno(String cumCertSno) {
		this.cumCertSno = cumCertSno;
	}

	public String getCumCity() {
		return this.cumCity;
	}

	public void setCumCity(String cumCity) {
		this.cumCity = cumCity;
	}

	public String getCumCrtBy() {
		return this.cumCrtBy;
	}

	public void setCumCrtBy(String cumCrtBy) {
		this.cumCrtBy = cumCrtBy;
	}

	public Calendar getCumCrtDate() {
		return this.cumCrtDate;
	}

	public void setCumCrtDate(Calendar cumCrtDate) {
		this.cumCrtDate = cumCrtDate;
	}

	public String getCumDept() {
		return this.cumDept;
	}

	public void setCumDept(String cumDept) {
		this.cumDept = cumDept;
	}

	public String getCumDesig() {
		return this.cumDesig;
	}

	public void setCumDesig(String cumDesig) {
		this.cumDesig = cumDesig;
	}

	public String getCumEmailId() {
		return this.cumEmailId;
	}

	public void setCumEmailId(String cumEmailId) {
		this.cumEmailId = cumEmailId;
	}

	public String getCumEmpId() {
		return this.cumEmpId;
	}

	public void setCumEmpId(String cumEmpId) {
		this.cumEmpId = cumEmpId;
	}

	public String getCumEnttCd() {
		return this.cumEnttCd;
	}

	public void setCumEnttCd(String cumEnttCd) {
		this.cumEnttCd = cumEnttCd;
	}

	public Calendar getCumFailedLoginTimestamp() {
		return this.cumFailedLoginTimestamp;
	}

	public void setCumFailedLoginTimestamp(Calendar cumFailedLoginTimestamp) {
		this.cumFailedLoginTimestamp = cumFailedLoginTimestamp;
	}

	public String getCumForgAnsr() {
		return this.cumForgAnsr;
	}

	public void setCumForgAnsr(String cumForgAnsr) {
		this.cumForgAnsr = cumForgAnsr;
	}

	public String getCumForgQues() {
		return this.cumForgQues;
	}

	public void setCumForgQues(String cumForgQues) {
		this.cumForgQues = cumForgQues;
	}

	public String getCumFrstNm() {
		return this.cumFrstNm;
	}

	public void setCumFrstNm(String cumFrstNm) {
		this.cumFrstNm = cumFrstNm;
	}

	public String getCumLastIpAddr() {
		return this.cumLastIpAddr;
	}

	public void setCumLastIpAddr(String cumLastIpAddr) {
		this.cumLastIpAddr = cumLastIpAddr;
	}

	public String getCumLoginId() {
		return this.cumLoginId;
	}

	public void setCumLoginId(String cumLoginId) {
		this.cumLoginId = cumLoginId;
	}

	public Calendar getCumLstLoginDate() {
		return this.cumLstLoginDate;
	}

	public void setCumLstLoginDate(Calendar cumLstLoginDate) {
		this.cumLstLoginDate = cumLstLoginDate;
	}

	public String getCumLstNm() {
		return this.cumLstNm;
	}

	public void setCumLstNm(String cumLstNm) {
		this.cumLstNm = cumLstNm;
	}

	public Calendar getCumLstUpdTmstmp() {
		return this.cumLstUpdTmstmp;
	}

	public void setCumLstUpdTmstmp(Calendar cumLstUpdTmstmp) {
		this.cumLstUpdTmstmp = cumLstUpdTmstmp;
	}

	public String getCumMidNm() {
		return this.cumMidNm;
	}

	public void setCumMidNm(String cumMidNm) {
		this.cumMidNm = cumMidNm;
	}

	public String getCumMoblNum() {
		return this.cumMoblNum;
	}

	public void setCumMoblNum(String cumMoblNum) {
		this.cumMoblNum = cumMoblNum;
	}

	public String getCumModfBy() {
		return this.cumModfBy;
	}

	public void setCumModfBy(String cumModfBy) {
		this.cumModfBy = cumModfBy;
	}

	public Calendar getCumModfDate() {
		return this.cumModfDate;
	}

	public void setCumModfDate(Calendar cumModfDate) {
		this.cumModfDate = cumModfDate;
	}

	public String getCumOs() {
		return this.cumOs;
	}

	public void setCumOs(String cumOs) {
		this.cumOs = cumOs;
	}

	public String getCumPhoneNo() {
		return this.cumPhoneNo;
	}

	public void setCumPhoneNo(String cumPhoneNo) {
		this.cumPhoneNo = cumPhoneNo;
	}

	public String getCumPinCd() {
		return this.cumPinCd;
	}

	public void setCumPinCd(String cumPinCd) {
		this.cumPinCd = cumPinCd;
	}

	public String getCumPwd() {
		return this.cumPwd;
	}

	public void setCumPwd(String cumPwd) {
		this.cumPwd = cumPwd;
	}

	public Date getCumPwdExprDate() {
		return this.cumPwdExprDate;
	}

	public void setCumPwdExprDate(Date cumPwdExprDate) {
		this.cumPwdExprDate = cumPwdExprDate;
	}

	public Integer getCumPwdExprFlg() {
		return this.cumPwdExprFlg;
	}

	public void setCumPwdExprFlg(Integer cumPwdExprFlg) {
		this.cumPwdExprFlg = cumPwdExprFlg;
	}

	public Integer getCumRlCd() {
		return this.cumRlCd;
	}

	public void setCumRlCd(Integer cumRlCd) {
		this.cumRlCd = cumRlCd;
	}

	public long getCumSeq() {
		return this.cumSeq;
	}

	public void setCumSeq(long cumSeq) {
		this.cumSeq = cumSeq;
	}

	public String getCumStatId() {
		return this.cumStatId;
	}

	public void setCumStatId(String cumStatId) {
		this.cumStatId = cumStatId;
	}

	public String getCumStateCd() {
		return this.cumStateCd;
	}

	public void setCumStateCd(String cumStateCd) {
		this.cumStateCd = cumStateCd;
	}

	public long getCumTxId() {
		return this.cumTxId;
	}

	public void setCumTxId(long cumTxId) {
		this.cumTxId = cumTxId;
	}

	public Integer getCumUsrLoggedIn() {
		return this.cumUsrLoggedIn;
	}

	public void setCumUsrLoggedIn(Integer cumUsrLoggedIn) {
		this.cumUsrLoggedIn = cumUsrLoggedIn;
	}

	public long getCumUsrMgmtTxId() {
		return this.cumUsrMgmtTxId;
	}

	public void setCumUsrMgmtTxId(long cumUsrMgmtTxId) {
		this.cumUsrMgmtTxId = cumUsrMgmtTxId;
	}

	public Date getCumUsrValidUptoDt() {
		return this.cumUsrValidUptoDt;
	}

	public void setCumUsrValidUptoDt(Date cumUsrValidUptoDt) {
		this.cumUsrValidUptoDt = cumUsrValidUptoDt;
	}

	public String getCumEmailSent() {
		return cumEmailSent;
	}

	public void setCumEmailSent(String cumEmailSent) {
		this.cumEmailSent = cumEmailSent;
	}

	public String getCumSingleOtpVal() {
		return cumSingleOtpVal;
	}

	public void setCumSingleOtpVal(String cumSingleOtpVal) {
		this.cumSingleOtpVal = cumSingleOtpVal;
	}

	public java.sql.Timestamp getCumOTPGenerationTime() {
		return cumOTPGenerationTime;
	}

	public void setCumOTPGenerationTime(java.sql.Timestamp cumOTPGenerationTime) {
		this.cumOTPGenerationTime = cumOTPGenerationTime;
	}

	public int getCumMaxOtpLimit() {
		return cumMaxOtpLimit;
	}

	public void setCumMaxOtpLimit(int cumMaxOtpLimit) {
		this.cumMaxOtpLimit = cumMaxOtpLimit;
	}

}