package com.nsdl.eia.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.nsdl.eia.api.add.AddRequest;
import com.nsdl.eia.api.add.Result;
import com.nsdl.eia.api.loaneligibility.Acknowledgement;
import com.nsdl.eia.api.loaneligibility.CustomerRequest;
import com.nsdl.eia.service.OtherService;

@Endpoint
@CrossOrigin(origins = "*")
public class OtherServiceEndPoint {
	private static final String NAMESPACE_ADD = "http://www.nsdl.com/soapdemo/api/add";
	private static final String NAMESPACE = "http://www.nsdl.com/soapdemo/api/loanEligibility";

	// ----------------------------- this above url in xsd file copy that one first
	// paste above
	@Autowired
	private OtherService service;

	// http://localhost:8080/ws/loanEligibility.wsdl
	// part > url-servlet path-bean name .wsdl
	@PayloadRoot(namespace = NAMESPACE, localPart = "CustomerRequest")
	// ---------------------------------------------- above local part is customer
	// request
	@ResponsePayload
	public Acknowledgement getLoanStatus(@RequestPayload CustomerRequest request) {
		System.out.println();
		return service.checkLoanEligibility(request);
	}

	// http://localhost:8080/ws/addition.wsdl
	// url-servlet path-bean name .wsdl
	@PayloadRoot(namespace = NAMESPACE_ADD, localPart = "AddRequest")
	// ---------------------------------------------- above local part is customer
	// request
	@ResponsePayload
	public Result getLoanStatus(@RequestPayload AddRequest request) {
		return service.addition(request);
	}

}