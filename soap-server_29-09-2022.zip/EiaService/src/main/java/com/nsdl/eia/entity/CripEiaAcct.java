package com.nsdl.eia.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


//import com.ndml.nir.audit.interceptor.Auditable;

/**
 * The persistent class for the CRIP_EIA_ACCT database table.
 */
@Entity
@Table(name = "NIR.CRIP_EIA_ACCT")
public class CripEiaAcct implements Serializable, Auditable {
	private static final long serialVersionUID = 1L;

	public String[] getId() {
		String[] id = new String[1];
		id[0] = "CEA_EIA_ACCT_ID:" + ceaEiaAcctId;
		return id;
	}

	@Id
	@Column(name = "CEA_EIA_ACCT_ID")
	private String ceaEiaAcctId;

	@Column(name = "CEA_ENTITY_CD")
	private String ceaEntityCd;

	/* CR New Field Added by Ajit */
	@Column(name = "CEA_KYC_CAT")
	private String ceaKycCat;
	/* End CR New Field Added by Ajit */
	@Column(name = "CEA_EIA_ACCT_CATID")
	private String ceaEiaAcctCatid;

	@Column(name = "CEA_EIA_ACCT_TYPE")
	private String ceaEiaAcctType;

	@Column(name = "CEA_EIA_ACCT_STATUS")
	private String ceaEiaAcctStatus;

	@Column(name = "CEA_KYC_FLAG")
	private String ceaKycFlag;

	@Column(name = "CEA_ACK_ID")
	private String ceaAckId;

	@Column(name = "CEA_APPL_ID")
	private String ceaApplId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEA_APPL_DT")
	private Calendar ceaApplDt;

	@Column(name = "CEA_USR_ID")
	private String ceaUsrId;

	@Column(name = "CEA_PWD")
	private String ceaPwd;

	@Column(name = "CEA_EIA_FILE_ID")
	private String ceaEiaFileId;

	@Column(name = "CEA_ATHRP_SMS_FLG")
	private String ceaAthrpSmsFlg;

	@Column(name = "cea_othrcat_desc")
	private String ceaOthrcatDesc;

	@Column(name = "cea_fileid")
	private String ceaFileId;

	@Column(name = "cea_ipaddress")
	private String ceaIpAddress;

	@Column(name = "cea_transaction_id")
	private Long ceaTransactionId;

	@Column(name = "CEA_DEDUP_FLG")
	private String ceaDedupFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEA_DUP_FND_DT")
	private Calendar ceaDupFndDt;

	@Column(name = "CEA_EIA_DEDUP_STATUS")
	private String ceaEiaDedupStatus;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEA_CRT_DATE")
	private Calendar ceaCrtDate;

	@Column(name = "CEA_CRT_BY")
	private String ceaCrtBy;

	@Column(name = "CEA_MODF_BY")
	private String ceaModfBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEA_MODF_DATE")
	private Calendar ceaModfDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEA_LST_UPD_TMSTMP")
	private Calendar ceaLstUpdTmstmp;

	@Column(name = "cea_online_flg")
	private String ceaOnlineFlg;

	@Column(name = "cea_prntr_flg")
	private String ceaPrntrFlg;

	@Column(name = "CEA_TOT_APPLCNT")
	private long ceaTotApplcnt;

	@Column(name = "cea_ap_or_ic_cd")
	private String ceaInsCmpnyCd;

	@Column(name = "cea_ap_or_ic_brnch_cd")
	private String ceaApOrIcBrnchCd;

	@Column(name = "cea_is_mandatory_data_present")
	private String ceaIsMandatoryDataPresent;

	@Column(name = "cea_reg_mail_sent")
	private String cea_reg_mail_sent;

	// 07082015 Start
	@Column(name = "cea_on_behalf_of_ic")
	private String ceaOnBehalfOfIc;

	@Column(name = "cea_entity_created_by")
	private String ceaEntityCreatedBy;
	// 07082015 End
	// CR- 6345 Start Ajit
	@Column(name = "cea_sourced_by")
	private String ceaSourcedBy;

	@Column(name = "cea_lot_number")
	private String ceaLotNumber;

	@Column(name = "cea_web_param") /****
									 * Added By Mayur J on 28-02-2019 to store Insurance company web-site hit
									 * parameter
									 *****/
	private String ceaWebParam;

	public String getCeaWebParam() {
		return ceaWebParam;
	}

	public void setCeaWebParam(String ceaWebParam) {
		this.ceaWebParam = ceaWebParam;
	}

	// CR- 6345 End Ajit

	// Start 20042017
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cea_eia_status_date")
	private Calendar ceaEiaStatusDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cea_eia_actvn_date")
	private Calendar ceaEiaActvnDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cea_dedup_date")
	private Calendar ceaDedupDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cea_eia_img_upload_date")
	private Calendar ceaEiaImgUploadDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cea_eia_itrex_inquiry_resp_date ")
	private Calendar ceaEiaItrexInquiryRespDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ccr_crt_date")
	private Calendar ccrCrtDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "cea_cis_inq_dt")
	private Calendar ceacisinqdt;

	// Added by Bala for mobile application eia generation 16May2019
	@Column(name = "cea_mode_of_transaction")
	private String ceamodeoftransaction;

	// Added by Amolb for premier_services

	@Column(name = "cea_premier_service_subscription_link")
	private String ceapremierservicesubscriptionlink;

	public String getCeapremierservicesubscriptionlink() {
		return ceapremierservicesubscriptionlink;
	}

	public void setCeapremierservicesubscriptionlink(String ceapremierservicesubscriptionlink) {
		this.ceapremierservicesubscriptionlink = ceapremierservicesubscriptionlink;
	}

	/******************
	 * Added By Mayur J on 11-01-2019 to store nameMatching score
	 *****************/
	/* Commented on 13-03-2019 as we are not going with this on production */
	/*
	 * @Column(name="cea_namematched_score") private Double nameMatchedScore;
	 * 
	 * 
	 * public Double getNameMatchedScore() { return nameMatchedScore; }
	 * 
	 * public void setNameMatchedScore(Double nameMatchedScore) {
	 * this.nameMatchedScore = nameMatchedScore; }
	 */

	public String getCeamodeoftransaction() {
		return ceamodeoftransaction;
	}

	public void setCeamodeoftransaction(String ceamodeoftransaction) {
		this.ceamodeoftransaction = ceamodeoftransaction;
	}

	/**********************************************************************************************/

	/*******************************************
	 * Added By Mayur J On 11-07-2019 for Corporate_Eia
	 ******************************************/

	@Column(name = "cea_corp_entity_cd")
	private String ceaCorpEntityCd;

	public String getCeaCorpEntityCd() {
		return ceaCorpEntityCd;
	}

	public void setCeaCorpEntityCd(String ceaCorpEntityCd) {
		this.ceaCorpEntityCd = ceaCorpEntityCd;
	}

	@Column(name = "cea_corp_entity_other")
	private String ceaCorpEntityOther;

	public String getCeaCorpEntityOther() {
		return ceaCorpEntityOther;
	}

	public void setCeaCorpEntityOther(String ceaCorpEntityOther) {
		this.ceaCorpEntityOther = ceaCorpEntityOther;
	}

	@OneToMany(mappedBy = "cripEiaAcct", cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	private Set<CripCropPersonDtls> cripCropPersonList;

	public Set<CripCropPersonDtls> getCripCropPersonList() {
		return cripCropPersonList;
	}

	public void setCripCropPersonList(Set<CripCropPersonDtls> cripCropPersonList) {
		this.cripCropPersonList = cripCropPersonList;
	}

	/**************************************************************************************************************************/

	public Calendar getCeacisinqdt() {
		return ceacisinqdt;
	}

	public void setCeacisinqdt(Calendar ceacisinqdt) {
		this.ceacisinqdt = ceacisinqdt;
	}

	public Calendar getCeaEiaStatusDate() {
		return ceaEiaStatusDate;
	}

	public void setCeaEiaStatusDate(Calendar ceaEiaStatusDate) {
		this.ceaEiaStatusDate = ceaEiaStatusDate;
	}

	public Calendar getCeaEiaActvnDate() {
		return ceaEiaActvnDate;
	}

	public void setCeaEiaActvnDate(Calendar ceaEiaActvnDate) {
		this.ceaEiaActvnDate = ceaEiaActvnDate;
	}

	public Calendar getCeaDedupDate() {
		return ceaDedupDate;
	}

	public void setCeaDedupDate(Calendar ceaDedupDate) {
		this.ceaDedupDate = ceaDedupDate;
	}

	public Calendar getCeaEiaImgUploadDate() {
		return ceaEiaImgUploadDate;
	}

	public void setCeaEiaImgUploadDate(Calendar ceaEiaImgUploadDate) {
		this.ceaEiaImgUploadDate = ceaEiaImgUploadDate;
	}

	public Calendar getCeaEiaItrexInquiryRespDate() {
		return ceaEiaItrexInquiryRespDate;
	}

	public void setCeaEiaItrexInquiryRespDate(Calendar ceaEiaItrexInquiryRespDate) {
		this.ceaEiaItrexInquiryRespDate = ceaEiaItrexInquiryRespDate;
	}

	public Calendar getCcrCrtDate() {
		return ccrCrtDate;
	}

	public void setCcrCrtDate(Calendar ccrCrtDate) {
		this.ccrCrtDate = ccrCrtDate;
	}

	public String getCeaIsMandatoryDataPresent() {
		return ceaIsMandatoryDataPresent;
	}

	public void setCeaIsMandatoryDataPresent(String ceaIsMandatoryDataPresent) {
		this.ceaIsMandatoryDataPresent = ceaIsMandatoryDataPresent;
	}

	public CripEiaAcct() {
		super();
	}

	public String getCeaEiaAcctId() {
		return this.ceaEiaAcctId;
	}

	public void setCeaEiaAcctId(String ceaEiaAcctId) {
		this.ceaEiaAcctId = ceaEiaAcctId;
	}

	public String getCeaAckId() {
		return this.ceaAckId;
	}

	public void setCeaAckId(String ceaAckId) {
		this.ceaAckId = ceaAckId;
	}

	public String getCeaCrtBy() {
		return this.ceaCrtBy;
	}

	public void setCeaCrtBy(String ceaCrtBy) {
		this.ceaCrtBy = ceaCrtBy;
	}

	public String getCeaEiaAcctCatid() {
		return this.ceaEiaAcctCatid;
	}

	public void setCeaEiaAcctCatid(String ceaEiaAcctCatid) {
		this.ceaEiaAcctCatid = ceaEiaAcctCatid;
	}

	public String getCeaEiaAcctStatus() {
		return this.ceaEiaAcctStatus;
	}

	public void setCeaEiaAcctStatus(String ceaEiaAcctStatus) {
		this.ceaEiaAcctStatus = ceaEiaAcctStatus;
	}

	public String getCeaEiaAcctType() {
		return this.ceaEiaAcctType;
	}

	public void setCeaEiaAcctType(String ceaEiaAcctType) {
		this.ceaEiaAcctType = ceaEiaAcctType;
	}

	public String getCeaKycFlag() {
		return this.ceaKycFlag;
	}

	public void setCeaKycFlag(String ceaKycFlag) {
		this.ceaKycFlag = ceaKycFlag;
	}

	public String getCeaModfBy() {
		return this.ceaModfBy;
	}

	public void setCeaModfBy(String ceaModfBy) {
		this.ceaModfBy = ceaModfBy;
	}

	public String getCeaApplId() {
		return ceaApplId;
	}

	public void setCeaApplId(String ceaApplId) {
		this.ceaApplId = ceaApplId;
	}

	public Calendar getCeaCrtDate() {
		return ceaCrtDate;
	}

	public Calendar getCeaApplDt() {
		return ceaApplDt;
	}

	public void setCeaApplDt(Calendar ceaApplDt) {
		this.ceaApplDt = ceaApplDt;
	}

	public String getCeaEiaFileId() {
		return ceaEiaFileId;
	}

	public void setCeaEiaFileId(String ceaEiaFileId) {
		this.ceaEiaFileId = ceaEiaFileId;
	}

	public String getCeaAthrpSmsFlg() {
		return ceaAthrpSmsFlg;
	}

	public void setCeaAthrpSmsFlg(String ceaAthrpSmsFlg) {
		this.ceaAthrpSmsFlg = ceaAthrpSmsFlg;
	}

	public String getCeaInsCmpnyCd() {
		return ceaInsCmpnyCd;
	}

	public void setCeaInsCmpnyCd(String ceaInsCmpnyCd) {
		this.ceaInsCmpnyCd = ceaInsCmpnyCd;
	}

	public void setCeaCrtDate(Calendar ceaCrtDate) {
		this.ceaCrtDate = ceaCrtDate;
	}

	public Calendar getCeaLstUpdTmstmp() {
		return ceaLstUpdTmstmp;
	}

	public void setCeaLstUpdTmstmp(Calendar ceaLstUpdTmstmp) {
		this.ceaLstUpdTmstmp = ceaLstUpdTmstmp;
	}

	public Calendar getCeaModfDate() {
		return ceaModfDate;
	}

	public void setCeaModfDate(Calendar ceaModfDate) {
		this.ceaModfDate = ceaModfDate;
	}

	public String getCeaPwd() {
		return this.ceaPwd;
	}

	public void setCeaPwd(String ceaPwd) {
		this.ceaPwd = ceaPwd;
	}

	public String getCeaUsrId() {
		return this.ceaUsrId;
	}

	public void setCeaUsrId(String ceaUsrId) {
		this.ceaUsrId = ceaUsrId;
	}

	@OneToMany(mappedBy = "cripEiaAcct", cascade = { CascadeType.PERSIST,
			// CascadeType.MERGE, CascadeType.REFRESH, CascadeType.REMOVE }, fetch =
			// FetchType.LAZY) //AmolB.21 Dec. 2018
			CascadeType.MERGE, CascadeType.REFRESH, CascadeType.REMOVE }, fetch = FetchType.EAGER)
	private Set<CripEiaPrpsrAthrp> cripEiaPrpAthrp;

	@OneToOne(mappedBy = "cripEiaAcct", cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	private CripEiaBnkDtl cripEiaBnkDtl;

	@OneToMany(mappedBy = "cripEiaAcct", cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	private Set<CripDocUpldDtl> cripDocUpldDtl;

	public CripEiaBnkDtl getCripEiaBnkDtl() {
		return cripEiaBnkDtl;
	}

	public void setCripEiaBnkDtl(CripEiaBnkDtl cripEiaBnkDtl) {
		this.cripEiaBnkDtl = cripEiaBnkDtl;
	}

	public Set<CripEiaPrpsrAthrp> getCripEiaPrpAthrp() {
		return cripEiaPrpAthrp;
	}

	public void setCripEiaPrpAthrp(Set<CripEiaPrpsrAthrp> cripEiaPrpAthrp) {
		this.cripEiaPrpAthrp = cripEiaPrpAthrp;
	}

	/*
	 * @OneToMany(mappedBy = "cripEiaAcct", cascade = { CascadeType.PERSIST,
	 * CascadeType.MERGE, CascadeType.REFRESH , CascadeType.REMOVE}, fetch =
	 * FetchType.LAZY) private Set<CripPlcy> cripPlcy; public Set<CripPlcy>
	 * getCripPlcy() { return cripPlcy; } public void setCripPlcy(Set<CripPlcy>
	 * cripPlcy) { this.cripPlcy = cripPlcy; }
	 */
	public String getCeaDedupFlg() {
		return ceaDedupFlg;
	}

	public void setCeaDedupFlg(String ceaDedupFlg) {
		this.ceaDedupFlg = ceaDedupFlg;
	}

	public Calendar getCeaDupFndDt() {
		return ceaDupFndDt;
	}

	public void setCeaDupFndDt(Calendar ceaDupFndDt) {
		this.ceaDupFndDt = ceaDupFndDt;
	}

	public String getCeaEiaDedupStatus() {
		return ceaEiaDedupStatus;
	}

	public void setCeaEiaDedupStatus(String ceaEiaDedupStatus) {
		this.ceaEiaDedupStatus = ceaEiaDedupStatus;
	}

	public void setCeaOnlineFlg(String ceaOnlineFlg) {
		this.ceaOnlineFlg = ceaOnlineFlg;
	}

	public String getCeaOnlineFlg() {
		return ceaOnlineFlg;
	}

	public void setCeaPrntrFlg(String ceaPrntrFlg) {
		this.ceaPrntrFlg = ceaPrntrFlg;
	}

	public String getCeaPrntrFlg() {
		return ceaPrntrFlg;
	}

	public void setCeaTotApplcnt(long ceaTotApplcnt) {
		this.ceaTotApplcnt = ceaTotApplcnt;
	}

	public long getCeaTotApplcnt() {
		return ceaTotApplcnt;
	}

	public void setCeaOthrcatDesc(String ceaOthrcatDesc) {
		this.ceaOthrcatDesc = ceaOthrcatDesc;
	}

	public String getCeaOthrcatDesc() {
		return ceaOthrcatDesc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getCeaTransactionId() {
		return ceaTransactionId;
	}

	public void setCeaTransactionId(Long ceaTransactionId) {
		this.ceaTransactionId = ceaTransactionId;
	}

	public String getCeaIpAddress() {
		return ceaIpAddress;
	}

	public void setCeaIpAddress(String ceaIpAddress) {
		this.ceaIpAddress = ceaIpAddress;
	}

	public void setCeaApOrIcBrnchCd(String ceaApOrIcBrnchCd) {
		this.ceaApOrIcBrnchCd = ceaApOrIcBrnchCd;
	}

	public String getCeaApOrIcBrnchCd() {
		return ceaApOrIcBrnchCd;
	}

	public void setCeaEntityCd(String ceaEntityCd) {
		this.ceaEntityCd = ceaEntityCd;
	}

	public String getCeaEntityCd() {
		return ceaEntityCd;
	}

	public String getCeaFileId() {
		return ceaFileId;
	}

	public void setCeaFileId(String ceaFileId) {
		this.ceaFileId = ceaFileId;
	}

	public Set<CripDocUpldDtl> getCripDocUpldDtl() {
		return cripDocUpldDtl;
	}

	public void setCripDocUpldDtl(Set<CripDocUpldDtl> cripDocUpldDtl) {
		this.cripDocUpldDtl = cripDocUpldDtl;
	}

	public String getCea_reg_mail_sent() {
		return cea_reg_mail_sent;
	}

	public void setCea_reg_mail_sent(String cea_reg_mail_sent) {
		this.cea_reg_mail_sent = cea_reg_mail_sent;
	}

	public String getCeaOnBehalfOfIc() {
		return ceaOnBehalfOfIc;
	}

	public void setCeaOnBehalfOfIc(String ceaOnBehalfOfIc) {
		this.ceaOnBehalfOfIc = ceaOnBehalfOfIc;
	}

	public String getCeaEntityCreatedBy() {
		return ceaEntityCreatedBy;
	}

	public void setCeaEntityCreatedBy(String ceaEntityCreatedBy) {
		this.ceaEntityCreatedBy = ceaEntityCreatedBy;
	}

	public String getCeaKycCat() {
		return ceaKycCat;
	}

	public void setCeaKycCat(String ceaKycCat) {
		this.ceaKycCat = ceaKycCat;
	}

	public String getCeaSourcedBy() {
		return ceaSourcedBy;
	}

	public void setCeaSourcedBy(String ceaSourcedBy) {
		this.ceaSourcedBy = ceaSourcedBy;
	}

	public String getCeaLotNumber() {
		return ceaLotNumber;
	}

	public void setCeaLotNumber(String ceaLotNumber) {
		this.ceaLotNumber = ceaLotNumber;
	}

}