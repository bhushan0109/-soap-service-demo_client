package com.nsdl.eia.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nsdl.eia.otherentity.CripSeqGnrtr;

public interface CripSeqGnrtrRepository extends JpaRepository<CripSeqGnrtr, Long> {

	@Query(value = "SELECT * FROM NIR.CRIP_SEQ_GNRTR WHERE CSG_GEN_KEY=:csgGenKey", nativeQuery = true)
	CripSeqGnrtr findByCsgGenKey(@Param("csgGenKey") String csgGenKey);
	
	@Query(value = "SELECT * FROM NIR.CRIP_SEQ_GNRTR WHERE CSG_GEN_KEY=:csgGenKey", nativeQuery = true)
	List<Object[]> findByCsgGenKeyObject(@Param("csgGenKey") String csgGenKey);

}
