package com.nsdl.eia;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.nsdl.eia.otherentity.NirPartnerMstr;
import com.nsdl.eia.repository.CripUsrMstrRepo;
import com.nsdl.eia.repository.NirPartnerMstrRepository;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@SpringBootApplication
@RestController
public class SoapDemoApplication  extends SpringBootServletInitializer{
	  private static Logger logger = LogManager.getLogger(SoapDemoApplication.class);
	  @Autowired
	  NirPartnerMstrRepository nirPartnerMstrRepository;
	public static void main(String[] args) {
		SpringApplication.run(SoapDemoApplication.class, args);
	}
	

	@GetMapping("/test/{name}")
	public String greeting(@PathVariable String name) {
		
//		long count = nirPartnerMstrRepository.count();
//		List<NirPartnerMstr> findByPartnerId = nirPartnerMstrRepository.findByPartnerId("ABCAPITAL");
//		System.out.println(findByPartnerId);
		String requestxml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
				"<eIA_Acc_Details>\n" + 
				"	<File_Header>\n" + 
				"		<File_id>1</File_id>\n" + 
				"		<From/>\n" + 
				"		<Date_Of_Generation>20200713</Date_Of_Generation>\n" + 
				"		<Num_Of_eIA_Acc_Details/>\n" + 
				"	</File_Header>\n" + 
				"	<Person_eIA_Detail>\n" + 
				"		<Id/>\n" + 
				"		<eIADetails>\n" + 
				"			<AccCategory>1</AccCategory>\n" + 
				"			<TypeOfAcc>2</TypeOfAcc>\n" + 
				"			<AppNo>1GPB018502</AppNo>\n" + 
				"			<Insurance_Cmpny_Cd>20</Insurance_Cmpny_Cd>\n" + 
				"			<Date_Of_Receipt>20200713</Date_Of_Receipt>\n" + 
				"		</eIADetails>\n" + 
				"		<Applicant_Detail>\n" + 
				"			<No_Of_Applicant>1</No_Of_Applicant>\n" + 
				"			<Applicant Name=\"Sole/First Proposer\">\n" + 
				"				<First_Name>YOGISH</First_Name>\n" + 
				"				<Middle_Name/>\n" + 
				"				<Last_Name>A D</Last_Name>\n" + 
				"				<Father_Husband_Name>DHANAPPA SHETTY</Father_Husband_Name>\n" + 
				"				<Gender>M</Gender>\n" + 
				"				<DOB>19950303</DOB>\n" + 
				"				<PAN>AHXPM9802E </PAN>\n" + 
				"				<UID/>\n" + 
				"				<Address Name=\"Permanent\">\n" + 
				"					<AddLine1>SO DHANAPPA SHETTY</AddLine1>\n" + 
				"					<AddLine2/>\n" + 
				"					<AddLine3/>\n" + 
				"					<Land_Mark/>\n" + 
				"					<City>CHIKMAGALALUR</City>\n" + 
				"					<State>09</State>\n" + 
				"					<Country>101</Country>\n" + 
				"					<PIN_Code>456456</PIN_Code>\n" + 
				"				</Address>\n" + 
				"				<Address Name=\"Correspondence\">\n" + 
				"					<AddLine1>SO DHANAPPA SHETTY</AddLine1>\n" + 
				"					<AddLine2>3RD CROSS ALLAMPURA</AddLine2>\n" + 
				"					<AddLine3>CHIKMAGALALUR</AddLine3>\n" + 
				"					<Land_Mark/>\n" + 
				"					<City>Dummy</City>\n" + 
				"					<State>09</State>\n" + 
				"					<Country>101</Country>\n" + 
				"					<PIN_Code>456456</PIN_Code>\n" + 
				"				</Address>\n" + 
				"				<Communication_Detail>\n" + 
				"					<Telephone_Number/>\n" + 
				"					<Alt_Telephone_Number/>\n" + 
				"					<Telephone_Number/>\n" + 
				"					<Alt_Telephone_Number/>\n" + 
				"					<Mob_Number>8955555555</Mob_Number>\n" + 
				"					<FAX/>\n" + 
				"					<Primary_email/>\n" + 
				"					<Alternate_email/>\n" + 
				"				</Communication_Detail>\n" + 
				"			</Applicant>\n" + 
				"			<Bank_Details>\n" + 
				"				<Bank_Name/>\n" + 
				"				<Other_Bank_Name/>\n" + 
				"				<Branch/>\n" + 
				"				<City/>\n" + 
				"				<Bank_Account_Number/>\n" + 
				"				<Bank_Account_Type/>\n" + 
				"				<Bank_MICR_Code/>\n" + 
				"				<Bank_IFSC_Code/>\n" + 
				"				<Cancelled_Cheque/>\n" + 
				"			</Bank_Details>\n" + 
				"			<Authorized_Representative>\n" + 
				"				<First_Name>YOGISH</First_Name>\n" + 
				"				<Middle_Name/>\n" + 
				"				<Last_Name>A D</Last_Name>\n" + 
				"				<Father_Husband_Name>DHANAPPA SHETTY</Father_Husband_Name>\n" + 
				"				<Gender>M</Gender>\n" + 
				"				<DOB>19950303</DOB>\n" + 
				"				<PAN>AXHPY7575J</PAN>\n" + 
				"				<UID/>\n" + 
				"				<Address Name=\"Permanent\">\n" + 
				"					<AddLine1 />\n" + 
				"					<AddLine2 />\n" + 
				"					<AddLine3 />\n" + 
				"					<Land_Mark />\n" + 
				"					<City />\n" + 
				"					<State />\n" + 
				"					<Country />\n" + 
				"					<PIN_Code />\n" + 
				"				</Address>\n" + 
				"				<Communication_Detail>\n" + 
				"					<Telephone_Number />\n" + 
				"					<Mob_Number />\n" + 
				"					<Relationship />\n" + 
				"					<Relationship_Other />\n" + 
				"					<Primary_email />\n" + 
				"				</Communication_Detail>\n" + 
				"				<Communication_Flag />\n" + 
				"			</Authorized_Representative>\n" + 
				"			<Other_Detail>\n" + 
				"				<ID_Proof>0</ID_Proof>\n" + 
				"				<Address_Proof>0</Address_Proof>\n" + 
				"				<Correspondence_Address_Proof>0</Correspondence_Address_Proof>\n" + 
				"				<DOB_Proof>0</DOB_Proof>\n" + 
				"			</Other_Detail>\n" + 
				"		</Applicant_Detail>\n" + 
				"	</Person_eIA_Detail>\n" + 
				"</eIA_Acc_Details>";
		String uid="TmlraGlsSw==";
		String pwd="bnNkbEAxMjM0";
		String bussinessPartnerId="MIBPL";
		String requestReferenceNumber="9999999999";
		
		String apiname="http://localhost:8080/NIR/onlineEiaAccountOpeningByPartnerNJ.html";
		String url = apiname + "?requestxml=" + requestxml + "&uid=" + uid + "&pwd=" + pwd + "&bussinessPartnerId=" + bussinessPartnerId + "&requestReferenceNumber=" + requestReferenceNumber;
		
		try {

			RestTemplate restTemplate = new RestTemplate();

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.add(HttpHeaders.AUTHORIZATION, "urAccessToken");

			HttpEntity httpEntity = new HttpEntity(httpHeaders);

			ResponseEntity<String> commonResponse = restTemplate.exchange(url, HttpMethod.POST, httpEntity,
					String.class);
			
			System.out.println(commonResponse);
			commonResponse.getBody();
//			logger.info("updateStage << commonResponse :  " + commonResponse);
//			response = CommonUtil.parseDto(commonResponse.getBody(), UserDTO.class);
//			logger.info("response :  " + response);
		} catch (Exception e) {
			throw e;
		}
		
//		 logger.debug("This is a debug message 1 ");
//	        logger.info("This is an info message 2 ");
//	        logger.warn("This is a warn message  3 ");
//	        logger.error("This is an error message  4");
//	        logger.fatal("This is a fatal message  5");
		
		
	        logger.debug("Request {}", name);
		if (name.equalsIgnoreCase("test")) {
			throw new RuntimeException("Opps Exception raised....");
		}
		String response = "Hi " + name+" "+10+ "  Welcome to Java";
		logger.debug("Response {}", response);
		return response;
	}

}
