package com.nsdl.eia.eiaxml.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Address {
	 private String landMark;
	    private Integer state;
	    private Integer country;
	    private String city;
	    private String addLine1;
	    private String addLine2;
	    private String addLine3;
	    private Integer pINCode;
	    private String name;
	
}
