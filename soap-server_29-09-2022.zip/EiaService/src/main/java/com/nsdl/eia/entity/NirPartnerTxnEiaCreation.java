package com.nsdl.eia.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name = "nir_partner_txn_eia_creation")
public class NirPartnerTxnEiaCreation implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(initialValue = 1, allocationSize = 1, sequenceName = "nir_partner_txn_eia_creation_nptec_transaction_reference_seq", name = "eiaforNJSeq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "eiaforNJSeq")
	@Column(name = "nptec_transaction_reference")
	private long nptectransactionreference;

	@Column(name = "nptec_partner_id")
	private String nptecpartnerid;

	@Column(name = "nptec_request_reference_number")
	private long nptecrequestreferencenumber;

	//@org.hibernate.annotations.Type(type = "com.ndml.nir.app.partners.domains.SQLXMLType")
	@Column(name = "nptec_request_xml")
	private String nptecrequestxml;

	//@org.hibernate.annotations.Type(type = "com.ndml.nir.app.partners.domains.SQLXMLType")
	@Column(name = "nptec_response_xml")
	private String nptecresponsexml;

	@Column(name = "nptec_visitor_ip")
	private String nptecvisitorip;

	@Column(name = "nptec_createddate")
	private Date npteccreateddate;

	@Column(name = "nptec_createdby")
	private String npteccreatedby;

	@Column(name = "nptec_updatedby")
	private String nptecupdateddby;

	@Column(name = "nptec_updateddate")
	private Date nptecupdateddate;

	/**********
	 * Added By Mayur J on 08-06-2020 For eIA status post service for partner
	 ************/

	@Column(name = "nptec_ack_id")
	private String nptecAckId;

}
