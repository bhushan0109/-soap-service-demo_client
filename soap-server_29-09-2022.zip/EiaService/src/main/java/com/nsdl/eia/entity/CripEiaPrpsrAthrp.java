package com.nsdl.eia.entity;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the CRIP_EIA_PRPSR_ATHRP database table.
 */
@Entity
@Table(name = "NIR.CRIP_EIA_PRPSR_ATHRP")
public class CripEiaPrpsrAthrp implements Serializable, Auditable {
	@Override
	public String[] getId() {
		String[] id = new String[2];
		id[0] = "CEPA_EIA_ACCT_ID:" + pk.cepaEiaAcctId;
		id[1] = "CEPA_PRP_ATHRP_FLAG:" + pk.cepaPrpAthrpFlag;
		return id;
	}

	@Embeddable
	public static class CripEiaPrpsrAthrpPK implements Serializable {
		private static final long serialVersionUID = 1L;

		@Column(name = "CEPA_EIA_ACCT_ID")
		private String cepaEiaAcctId;

		@Column(name = "CEPA_PRP_ATHRP_FLAG")
		private String cepaPrpAthrpFlag;

		public CripEiaPrpsrAthrpPK() {
			super();
		}

		public CripEiaPrpsrAthrpPK(String cepaEiaAcctId, String cepaPrpAthrpFlag) {
			this.cepaEiaAcctId = cepaEiaAcctId;
			this.cepaPrpAthrpFlag = cepaPrpAthrpFlag;
		}

		public String getCepaEiaAcctId() {
			return this.cepaEiaAcctId;
		}

		public void setCepaEiaAcctId(String cepaEiaAcctId) {
			this.cepaEiaAcctId = cepaEiaAcctId;
		}

		public String getCepaPrpAthrpFlag() {
			return this.cepaPrpAthrpFlag;
		}

		public void setCepaPrpAthrpFlag(String cepaPrpAthrpFlag) {
			this.cepaPrpAthrpFlag = cepaPrpAthrpFlag;
		}

		public boolean equals(Object other) {
			if (this == other) {
				return true;
			}
			if (!(other instanceof CripEiaPrpsrAthrpPK)) {
				return false;
			}
			CripEiaPrpsrAthrpPK castOther = (CripEiaPrpsrAthrpPK) other;
			return this.cepaEiaAcctId.equals(castOther.cepaEiaAcctId)
					&& this.cepaPrpAthrpFlag.equals(castOther.cepaPrpAthrpFlag);
		}

		public int hashCode() {
			final int prime = 31;
			int hash = 17;
			hash = hash * prime + this.cepaEiaAcctId.hashCode();
			hash = hash * prime + this.cepaPrpAthrpFlag.hashCode();
			return hash;
		}
	}

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CripEiaPrpsrAthrpPK pk = new CripEiaPrpsrAthrpPK();

	@Column(name = "CEPA_CRT_BY")
	private String cepaCrtBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEPA_CRT_DATE")
	private Calendar cepaCrtDate;

	@Column(name = "CEPA_FATHR_FRST_NM")
	private String cepaFathrFrstNm;

	@Column(name = "CEPA_FATHR_LST_NM")
	private String cepaFathrLstNm;

	@Column(name = "CEPA_FATHR_MID_NM")
	private String cepaFathrMidNm;

	@Column(name = "CEPA_FATHR_TITLE_ID")
	private String cepaFathrTitleId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEPA_LST_UPD_TMSTMP")
	private Calendar cepaLstUpdTmstmp;

	@Column(name = "CEPA_MARITAL_STAT")
	private String cepaMaritalStat;

	@Column(name = "CEPA_MODF_BY")
	private String cepaModfBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CEPA_MODF_DATE")
	private Calendar cepaModfDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "CEPA_PRP_ATHRP_DOB")
	private Calendar cepaPrpAthrpDob;

	@Column(name = "CEPA_PRP_ATHRP_FRST_NM")
	private String cepaPrpAthrpFrstNm;

	@Column(name = "CEPA_PRP_ATHRP_GNDR")
	private String cepaPrpAthrpGndr;

	@Column(name = "CEPA_PRP_ATHRP_LST_NM")
	private String cepaPrpAthrpLstNm;

	@Column(name = "CEPA_PRP_ATHRP_MID_NM")
	private String cepaPrpAthrpMidNm;

	@Column(name = "CEPA_PRP_ATHRP_PAN")
	private String cepaPrpAthrpPan;

	@Column(name = "cepa_othr_rltn_desc")
	private String cepaOthrRltnDesc;

	/*
	 * @Lob()
	 * 
	 * @Column(name="CEPA_PRP_ATHRP_PHOTO") private byte[] cepaPrpAthrpPhoto;
	 * 
	 * @Lob()
	 * 
	 * @Column(name="CEPA_PRP_ATHRP_SIGN") private byte[] cepaPrpAthrpSign;
	 */
	@Column(name = "CEPA_PRP_ATHRP_STAT")
	private String cepaPrpAthrpStat;

	@Column(name = "CEPA_PRP_ATHRP_UID")
	private String cepaPrpAthrpUid;

	/******************** Added By Mayur J on 20-07-2018 ********************/

	@Column(name = "CEPA_PRP_ATHRP_VID")
	private String cepaPrpAthrpVid;

	public String getCepaPrpAthrpVid() {
		return cepaPrpAthrpVid;
	}

	public void setCepaPrpAthrpVid(String cepaPrpAthrpVid) {
		this.cepaPrpAthrpVid = cepaPrpAthrpVid;
	}

	/***********************************************************************/

	@Column(name = "CEPA_PRPSR_TITLE_ID")
	private String cepaPrpsrTitleId;

	@Column(name = "CEPA_RLTNSHP_ID")
	private String cepaRltnshpId;

	@Column(name = "CEPA_PHN_1")
	private String cepaPhn1;

	@Column(name = "CEPA_PHN_2")
	private String cepaPhn2;

	@Column(name = "CEPA_MOB_NO")
	private String cepaMobNo;

	@Column(name = "CEPA_FAX")
	private String cepaFax;

	@Column(name = "CEPA_EMAIL_1")
	private String cepaEmail1;

	@Column(name = "CEPA_EMAIL_2")
	private String cepaEmail2;

	@Column(name = "CEPA_DOB_PROOF")
	private String cepaDobProof;

	@Column(name = "CEPA_ID_PROOF")
	private String cepaIdProof;

	@Column(name = "CEPA_ADDR_FLAG")
	private String cepaAddrFlag;

	@Column(name = "CEPA_TRANSACTION_ID")
	private Long cepaTxId;

	@Column(name = "CEPA_IPADDRESS")
	private String cepaIpaddress;

	@Column(name = "CEPA_FILEID")
	private String cepaFileid;

	/**************
	 * Added By Mayur J on 10-06-2019 For Corporate Eia
	 *******************************/

	@Column(name = "cepa_corp_entity_nm")
	private String cepaCorpEntityNm;

	@Column(name = "cepa_prp_athrp_corp_regno")
	private String cepaPrpAthrpCorpRegno;

	public String getCepaCorpEntityNm() {
		return cepaCorpEntityNm;
	}

	@Column(name = "cepa_int_opted")
	private String cepaIntOpted;

	@Column(name = "cepa_int_Freq")
	private int cepaIntFreq;

	public String getCepaIntOpted() {
		return cepaIntOpted;
	}

	public void setCepaIntOpted(String cepaIntOpted) {
		this.cepaIntOpted = cepaIntOpted;
	}

	public int getCepaIntFreq() {
		return cepaIntFreq;
	}

	public void setCepaIntFreq(int cepaIntFreq) {
		this.cepaIntFreq = cepaIntFreq;
	}

	@Column(name = "cepa_doc_othrthn_pan")
	private String cepaDocOthrthnPan;

	public String getCepaDocOthrthnPan() {
		return cepaDocOthrthnPan;
	}

	public void setCepaDocOthrthnPan(String cepaDocOthrthnPan) {
		this.cepaDocOthrthnPan = cepaDocOthrthnPan;
	}

	public void setCepaCorpEntityNm(String cepaCorpEntityNm) {
		this.cepaCorpEntityNm = cepaCorpEntityNm;
	}

	public String getCepaPrpAthrpCorpRegno() {
		return cepaPrpAthrpCorpRegno;
	}

	public void setCepaPrpAthrpCorpRegno(String cepaPrpAthrpCorpRegno) {
		this.cepaPrpAthrpCorpRegno = cepaPrpAthrpCorpRegno;
	}

	/****************************************************************************/

	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "CEPA_EIA_ACCT_ID", referencedColumnName = "CEA_EIA_ACCT_ID", insertable = false, updatable = false) })
	private CripEiaAcct cripEiaAcct;

	@OneToMany(mappedBy = "cripEiaPrpsrAthrp", cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	private Set<CripEiaPrpAthrpAddr> cripEiaPrpAthrpAddr;

	public CripEiaPrpsrAthrp() {
		super();
	}

	public CripEiaAcct getCripEiaAcct() {
		return cripEiaAcct;
	}

	public Set<CripEiaPrpAthrpAddr> getCripPrpAthrpAddr() {
		return cripEiaPrpAthrpAddr;
	}

	public void setCripPrpAthrpAddr(Set<CripEiaPrpAthrpAddr> cripEiaPrpAthrpAddr) {
		this.cripEiaPrpAthrpAddr = cripEiaPrpAthrpAddr;
	}

	public void setCripEiaAcct(CripEiaAcct cripEiaAcct) {
		this.cripEiaAcct = cripEiaAcct;
	}

	public String getCepaCrtBy() {
		return this.cepaCrtBy;
	}

	public void setCepaCrtBy(String cepaCrtBy) {
		this.cepaCrtBy = cepaCrtBy;
	}

	public Calendar getCepaCrtDate() {
		return this.cepaCrtDate;
	}

	public void setCepaCrtDate(Calendar cepaCrtDate) {
		this.cepaCrtDate = cepaCrtDate;
	}

	public String getCepaFathrFrstNm() {
		return this.cepaFathrFrstNm;
	}

	public void setCepaFathrFrstNm(String cepaFathrFrstNm) {
		this.cepaFathrFrstNm = cepaFathrFrstNm;
	}

	public String getCepaFathrLstNm() {
		return this.cepaFathrLstNm;
	}

	public void setCepaFathrLstNm(String cepaFathrLstNm) {
		this.cepaFathrLstNm = cepaFathrLstNm;
	}

	public String getCepaFathrMidNm() {
		return this.cepaFathrMidNm;
	}

	public void setCepaFathrMidNm(String cepaFathrMidNm) {
		this.cepaFathrMidNm = cepaFathrMidNm;
	}

	public String getCepaFathrTitleId() {
		return this.cepaFathrTitleId;
	}

	public void setCepaFathrTitleId(String cepaFathrTitleId) {
		this.cepaFathrTitleId = cepaFathrTitleId;
	}

	public Calendar getCepaLstUpdTmstmp() {
		return this.cepaLstUpdTmstmp;
	}

	public void setCepaLstUpdTmstmp(Calendar cepaLstUpdTmstmp) {
		this.cepaLstUpdTmstmp = cepaLstUpdTmstmp;
	}

	public String getCepaMaritalStat() {
		return this.cepaMaritalStat;
	}

	public void setCepaMaritalStat(String cepaMaritalStat) {
		this.cepaMaritalStat = cepaMaritalStat;
	}

	public String getCepaModfBy() {
		return this.cepaModfBy;
	}

	public void setCepaModfBy(String cepaModfBy) {
		this.cepaModfBy = cepaModfBy;
	}

	public Calendar getCepaModfDate() {
		return this.cepaModfDate;
	}

	public void setCepaModfDate(Calendar cepaModfDate) {
		this.cepaModfDate = cepaModfDate;
	}

	public Calendar getCepaPrpAthrpDob() {
		return this.cepaPrpAthrpDob;
	}

	public void setCepaPrpAthrpDob(Calendar cepaPrpAthrpDob) {
		this.cepaPrpAthrpDob = cepaPrpAthrpDob;
	}

	public String getCepaPrpAthrpFrstNm() {
		return this.cepaPrpAthrpFrstNm;
	}

	public void setCepaPrpAthrpFrstNm(String cepaPrpAthrpFrstNm) {
		this.cepaPrpAthrpFrstNm = cepaPrpAthrpFrstNm;
	}

	public String getCepaPrpAthrpGndr() {
		return this.cepaPrpAthrpGndr;
	}

	public void setCepaPrpAthrpGndr(String cepaPrpAthrpGndr) {
		this.cepaPrpAthrpGndr = cepaPrpAthrpGndr;
	}

	public String getCepaPrpAthrpLstNm() {
		return this.cepaPrpAthrpLstNm;
	}

	public void setCepaPrpAthrpLstNm(String cepaPrpAthrpLstNm) {
		this.cepaPrpAthrpLstNm = cepaPrpAthrpLstNm;
	}

	public String getCepaPrpAthrpMidNm() {
		return this.cepaPrpAthrpMidNm;
	}

	public void setCepaPrpAthrpMidNm(String cepaPrpAthrpMidNm) {
		this.cepaPrpAthrpMidNm = cepaPrpAthrpMidNm;
	}

	public String getCepaPrpAthrpPan() {
		return this.cepaPrpAthrpPan;
	}

	public void setCepaPrpAthrpPan(String cepaPrpAthrpPan) {
		this.cepaPrpAthrpPan = cepaPrpAthrpPan;
	}

	/*
	 * public byte[] getCepaPrpAthrpPhoto() { return this.cepaPrpAthrpPhoto; }
	 * public void setCepaPrpAthrpPhoto(byte[] cepaPrpAthrpPhoto) {
	 * this.cepaPrpAthrpPhoto = cepaPrpAthrpPhoto; } public byte[]
	 * getCepaPrpAthrpSign() { return this.cepaPrpAthrpSign; } public void
	 * setCepaPrpAthrpSign(byte[] cepaPrpAthrpSign) { this.cepaPrpAthrpSign =
	 * cepaPrpAthrpSign; }
	 */
	public String getCepaPrpAthrpStat() {
		return this.cepaPrpAthrpStat;
	}

	public void setCepaPrpAthrpStat(String cepaPrpAthrpStat) {
		this.cepaPrpAthrpStat = cepaPrpAthrpStat;
	}

	public String getCepaPrpAthrpUid() {
		return this.cepaPrpAthrpUid;
	}

	public void setCepaPrpAthrpUid(String cepaPrpAthrpUid) {
		this.cepaPrpAthrpUid = cepaPrpAthrpUid;
	}

	public String getCepaPhn1() {
		return cepaPhn1;
	}

	public void setCepaPhn1(String cepaPhn1) {
		this.cepaPhn1 = cepaPhn1;
	}

	public String getCepaPhn2() {
		return cepaPhn2;
	}

	public void setCepaPhn2(String cepaPhn2) {
		this.cepaPhn2 = cepaPhn2;
	}

	public String getCepaMobNo() {
		return cepaMobNo;
	}

	public void setCepaMobNo(String cepaMobNo) {
		this.cepaMobNo = cepaMobNo;
	}

	public String getCepaFax() {
		return cepaFax;
	}

	public void setCepaFax(String cepaFax) {
		this.cepaFax = cepaFax;
	}

	public String getCepaEmail1() {
		return cepaEmail1;
	}

	public void setCepaEmail1(String cepaEmail1) {
		this.cepaEmail1 = cepaEmail1;
	}

	public String getCepaEmail2() {
		return cepaEmail2;
	}

	public void setCepaEmail2(String cepaEmail2) {
		this.cepaEmail2 = cepaEmail2;
	}

	public Long getCepaTxId() {
		return cepaTxId;
	}

	public void setCepaTxId(Long cepaTxId) {
		this.cepaTxId = cepaTxId;
	}

	public String getCepaPrpsrTitleId() {
		return this.cepaPrpsrTitleId;
	}

	public void setCepaPrpsrTitleId(String cepaPrpsrTitleId) {
		this.cepaPrpsrTitleId = cepaPrpsrTitleId;
	}

	public String getCepaRltnshpId() {
		return this.cepaRltnshpId;
	}

	public void setCepaRltnshpId(String cepaRltnshpId) {
		this.cepaRltnshpId = cepaRltnshpId;
	}

	public void setPk(CripEiaPrpsrAthrpPK pk) {
		this.pk = pk;
	}

	public CripEiaPrpsrAthrpPK getPk() {
		return pk;
	}

	public void setCepaAddrFlag(String cepaAddrFlag) {
		this.cepaAddrFlag = cepaAddrFlag;
	}

	public String getCepaAddrFlag() {
		return cepaAddrFlag;
	}

	public void setCepaDobProof(String cepaDobProof) {
		this.cepaDobProof = cepaDobProof;
	}

	public String getCepaDobProof() {
		return cepaDobProof;
	}

	public void setCepaOthrRltnDesc(String cepaOthrRltnDesc) {
		this.cepaOthrRltnDesc = cepaOthrRltnDesc;
	}

	public String getCepaOthrRltnDesc() {
		return cepaOthrRltnDesc;
	}

	public void setCepaIdProof(String cepaIdProof) {
		this.cepaIdProof = cepaIdProof;
	}

	public String getCepaIdProof() {
		return cepaIdProof;
	}

	public String getCepaIpaddress() {
		return cepaIpaddress;
	}

	public void setCepaIpaddress(String cepaIpaddress) {
		this.cepaIpaddress = cepaIpaddress;
	}

	public String getCepaFileid() {
		return cepaFileid;
	}

	public void setCepaFileid(String cepaFileid) {
		this.cepaFileid = cepaFileid;
	}

	public Set<CripEiaPrpAthrpAddr> getCripEiaPrpAthrpAddr() {
		return cripEiaPrpAthrpAddr;
	}

	public void setCripEiaPrpAthrpAddr(Set<CripEiaPrpAthrpAddr> cripEiaPrpAthrpAddr) {
		this.cripEiaPrpAthrpAddr = cripEiaPrpAthrpAddr;
	}
}