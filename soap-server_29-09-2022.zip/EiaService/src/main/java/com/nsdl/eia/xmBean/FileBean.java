package com.nsdl.eia.xmBean;

import java.io.Serializable;

import lombok.Data;

@Data
public class FileBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private String fileId;

	private String filename;

	private String filepath;

	private String username;

	private String fileSrvrPathCode;

	private String eiaNumber;

	private String eiaFileType;

	private String eiaDocDate;

	private String eiaDocRemark;

	private String docUploadedByFlag;

	private String ipinNumber;

	private String serverPath;

	private String fileStatus;

	// CR5276 Start
	private String proofFileAckNumber;
	// Swapnali added
	private String corporateDrPan;
	private String DocNameOther;
	// Added by Amol b for Hbase download 8July 2019
	private String rowKeyDoc;

	// End Hbase download 8July 2019

}
