package com.nsdl.eia.utility;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.apache.commons.codec.binary.Hex;
//import org.apache.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

//import com.nsdl.eia.service.EiaService;

public class Encryption {
	private static Cipher cipher;

	private static PublicKey publicKey;

	private static Logger LOGGER = LogManager.getLogger(Encryption.class);
	// public static final Logger LOG = Logger.getLogger(Encryption.class);

	public Encryption(String pubMod, String pubExp) {
		try {
			cipher = Cipher.getInstance("RSA");
			BigInteger m = new BigInteger(pubMod);
			BigInteger e = new BigInteger(pubExp);
			LOGGER.info("m " + m);
			LOGGER.info("e " + e);
			RSAPublicKeySpec keySpec = new RSAPublicKeySpec(m, e);
			KeyFactory fact = KeyFactory.getInstance("RSA");
			publicKey = fact.generatePublic(keySpec);
		} catch (InvalidKeySpecException e1) {
			e1.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}

	public String encrypt(String plaintext, PublicKey pubKey) throws Exception {
		LOGGER.info("pubKey " + pubKey);
		cipher.init(Cipher.ENCRYPT_MODE, pubKey);
		byte[] bytes = plaintext.getBytes("UTF-8");
		byte[] encrypted = blockCipher(bytes, Cipher.ENCRYPT_MODE);
		char[] encryptedTranspherable = Hex.encodeHex(encrypted);
		return new String(encryptedTranspherable);
	}

	public byte[] blockCipher(byte[] bytes, int mode) throws IllegalBlockSizeException, BadPaddingException {
		// string initialize 2 buffers.
		// scrambled will hold intermediate results
		byte[] scrambled = new byte[0];
		// toReturn will hold the total result
		byte[] toReturn = new byte[0];
		// if we encrypt we use 100 byte long blocks. Decryption requires 128 byte long
		// blocks (because of RSA)
		int length = (mode == Cipher.ENCRYPT_MODE) ? 10 : 128;
		// another buffer. this one will hold the bytes that have to be modified in this
		// step
		byte[] buffer = new byte[length];
		for (int i = 0; i < bytes.length; i++) {
			// if we filled our buffer array we have our block ready for de- or encryption
			if ((i > 0) && (i % length == 0)) {
				// execute the operation
				scrambled = cipher.doFinal(buffer);
				// add the result to our total result.
				toReturn = append(toReturn, scrambled);
				// here we calculate the length of the next buffer required
				int newlength = length;
				// if newlength would be longer than remaining bytes in the bytes array we
				// shorten it.
				if (i + length > bytes.length) {
					newlength = bytes.length - i;
				}
				// clean the buffer array
				buffer = new byte[newlength];
			}
			// copy byte into our buffer.
			buffer[i % length] = bytes[i];
		}
		// this step is needed if we had a trailing buffer. should only happen when
		// encrypting.
		// example: we encrypt 110 bytes. 100 bytes per run means we "forgot" the last
		// 10 bytes. they are in the buffer array
		scrambled = cipher.doFinal(buffer);
		// final step before we can return the modified data.
		toReturn = append(toReturn, scrambled);
		return toReturn;
	}

	private byte[] append(byte[] prefix, byte[] suffix) {
		byte[] toReturn = new byte[prefix.length + suffix.length];
		for (int i = 0; i < prefix.length; i++) {
			toReturn[i] = prefix[i];
		}
		for (int i = 0; i < suffix.length; i++) {
			toReturn[i + prefix.length] = suffix[i];
		}
		return toReturn;
	}

	public static PublicKey getPublicKey() {
		return publicKey;
	}

	public static void setPublicKey(PublicKey publicKey) {
		Encryption.publicKey = publicKey;
	}
}