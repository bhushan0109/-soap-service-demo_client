package com.nsdl.eia.otherentity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the CRIP_SYS_PARAM database table.
 */
@Entity
@Table(name = "NIR.CRIP_SYS_PARAM")
public class CripSysParam implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CSP_PARAM_CD")
	private String cspParamCd;

	@Column(name = "CSP_PARAM_DESC")
	private String cspParamDesc;

	@Column(name = "CSP_PARAM_VAL")
	private String cspParamVal;

	public CripSysParam() {
		super();
	}

	public String getCspParamCd() {
		return this.cspParamCd;
	}

	public void setCspParamCd(String cspParamCd) {
		this.cspParamCd = cspParamCd;
	}

	public String getCspParamDesc() {
		return this.cspParamDesc;
	}

	public void setCspParamDesc(String cspParamDesc) {
		this.cspParamDesc = cspParamDesc;
	}

	public String getCspParamVal() {
		return this.cspParamVal;
	}

	public void setCspParamVal(String cspParamVal) {
		this.cspParamVal = cspParamVal;
	}
}