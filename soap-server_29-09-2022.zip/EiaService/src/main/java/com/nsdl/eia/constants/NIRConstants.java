package com.nsdl.eia.constants;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

public class NIRConstants {

	public static String BASE_FILE_SYSTEM_PATH = "/app/nir/filesystem/";

	/*
	 * static{
	 * 
	 * QueryImpl queryImpl = new QueryImpl(); List<CripSysParam> listTest =
	 * queryImpl.getBasePath();
	 * 
	 * System.out.println("Path from NIR Constants :: " +listTest + "Value :: "
	 * +listTest.get(0).getCspParamVal()) ; BASE_FILE_SYSTEM_PATH =
	 * listTest.get(0).getCspParamVal();
	 * 
	 * 
	 * }
	 */
	public static final String version = "v3.67 08-05-2017 18:10";

	private static final long serialVersionUID = 1L;

	public static final String WAS_REMOTE_JNDI_QUEUE = "com.ndml.nir.app.producer.ejb.QueueProducerRemote";

	public static final String JBOSS_REMOTE_JNDI_QUEUE = "QueueProducerBean/com.ndml.nir.app.producer.ejb.QueueProducerRemote";

	public static final String LIC_FLAG = "01";

	public static final String GENERAL_FLAG = "02";

	public static final String GENERAL_HEALTH_FLAG = "03";

	// Added by Swapnali For Other Policy Flag
	public static final String GENERAL_OTHER_FLAG = "04";

	// End Other Policy Flag

	public static final String APPOINTEE_FLAG = "A";

	public static final String NOMINEE_FLAG = "N";

	public static final String POLICY_FLAG = "01";

	public static final String RIDER_FLAG = "02";

	public static final String POLICY_CAT_CD = "PLCY_CAT";

	public static final String LIFE_PLCY_TYPE = "LF_PLC_TYP";

	public static final String GENDER_CODE = "GNDR_TYPE";

	public static final String RELATION_CODE = "RLTN_FLAG";

	public static final String TITLE_CODE = "NM_TITLE";

	public static final String BNKACCTYPE_CODE = "BNKACT_TYP";

	public static final String PREM_FREQ_CODE = "PREM_FREQ";

	public static final String DMS_STATUS_OK = "2";

	public static final String DMS_STATUS_PENDING = "1";

	public static final String MINTIMESTAMP = " 00:00:00:000";

	public static final String MAXTIMESTAMP = " 23:59:59:999";

	public static final String ACCOUNTCATEGORYCODE = "EIAAC_CAT";

	public static final String ACCOUNTSTATUSCODE = "ACCT_STAT";

	public static final String CODE_FOR_APP_STATUS = "APPL_STAT";

	public static final String CODE_FOR_REGISTR_STATUS = "02";

	public static final String CODE_FOR_WILDCARD = "%";

	public static final String MAIL_SENDING_FLAG = "TRUE";

	public static final String PWD_EXP_FLAG_ACTIVE = "1";

	public static final String LOGIN_ATTEMPT_RIGHT = "RIGHT";

	public static final String LOGIN_ATTEMPT_WRONG = "WRONG";

	public static final String PWD_EXP_FLAG_LOCK = "6";

	public static final String FP_PHY_DISPATCH = "2";

	public static final String FP_HINT_QUES = "3";

	// added by amirja on 17-05-2019 for forgot password with otp
	public static final String FP_MOBILE_OTP = "11";

	public static final String PWD_EXP_FLAG_NEW_ACC = "4";

	public static final String FP_KEY_FLDS = "5";

	public static final String FP_REQ_STATUS_UNS = "01";

	public static final String FP_REQ_STATUS_SER = "02";

	public static final String FP_REQ_STATUS_HARD_CLOSED = "03";

	public static final String MAX_BAD_LOGIN_CNT = "MaxBadLoginCnt";

	public static final String PWD_HSTRY_CNT = "PwdHstryCnt";

	public static final String PUB_KEY_MOD = "PubKeyMod";

	public static final String PUB_KEY_EXP = "PubKeyExp";

	public static final String PRIV_KEY_MOD = "PrivKeyMod";

	public static final String PRIV_KEY_EXP = "PrivKeyExp";

	public static final String RSA = "RSA";

	public static final String PWD_EXPR_DAYS = "PwdExprDays";

	public static final String CHANGE_PWD = "changePwd";

	public static final String FGT_PWD = "forgotPwd";

	public static final String STRING_FALSE = "false";

	public static final String STRING_TRUE = "true";

	public static final String STRING_EXP_ACC = "expiredAcc";

	public static final String PWD_EXPIRE = "pwdExpire";

	public static final String SEC_QUES = "SEC_QUES";

	public static final String SINGLE_QUOTE = "'";

	public static final String PERMANENT_ADDRESS_FLAG = "p";

	public static final String CORESSPONDANT_ADDRESS_FLAG = "c";

	public static final String DSC_TYPE = "01";

	public static final String PWD_TYPE = "02";

	public static final String CRL_FOLDER_PATH = "FormSignerCRLPath";

	public static final String CERTS_FOLDER_PATH = "FormSignerCertsPath";

	public static final String JASPERFILES = "JasperReportFilePath";

	public static final String JASPERREPORTS = "OutputFilePath";

	public static final String ACCOUNT_TYPE = "EIAAC_CORP";

	public static final String SHA = "sha";

	public static final String ENCODER = "encoder";

	public static final String CODE_FOR_UPDATE_FILE_EIA = "20";

	public static final String CODE_FOR_UPDATE_FILE_IPIN = "21";

	public static final String CODE_FOR_EIA_FILE_UPLOAD_IN_SYS_PARAM = "01";

	public static final String CODE_FOR_EIA_UPDATE_FILE_UPLOAD_IN_SYS_PARAM = "26";

	public static final String SEQUENCE_KEY_FOR_FILE = "FILE_SEQ";

	public static final String CODE_FOR_IPIN_FILE_UPLOAD_IN_SYS_PARAM = "04";

	public static final String CODE_FOR_EIA_IMAGE_UPLAOD_IN_SYS_PARAM = "07";

	public static final String CODE_FOR_EIA_INDEXFILE_UPLAOD_IN_SYS_PARAM = "08";

	public static final String FLAG_FOR_DOC_UPLOADED_BY_KYC = "01";

	public static final String FLAG_FOR_DOC_UPLOADED_BY_INSURANCE = "02";

	public static final String FLAG_FOR_DOC_UPLOADED_BY_UNKNOWN = "00";

	public static final String FOLDER_NAME_FOR_INDEXFILE_UPLOADED_BY_KYC = "KYC";

	public static final String FOLDER_NAME_FOR_INDEXFILE_UPLOADED_BY_INSURANCE = "INSURANCE";

	public static final String FOLDER_NAME_FOR_INDEXFILE_UPLOADED_BY_UNKNOWN = "UNKNOWN";

	public static final String DMS_KYC_PATH = "DMSServerKycPath";

	public static final String DMS_IPIN_PATH = "DMSServerIpinDocPath";

	public static final String FOLDER_NAME_FOR_COMPLETED_FILES = "COMPLETED";

	public static final String FOLDER_NAME_FOR_TEMP_FILES = "TEMP";

	public static final String FOLDER_NAME_FOR_LOG_FILES = "LOG";

	public static final String FOLDER_NAME_FOR_FILES = "FILES";

	public static final String FOLDER_NAME_FOR_FAILED_FILES = "FAILED";

	public static final String FOLDER_NAME_FOR_SIGNATURE = "SIGNATURE";

	public static final String KYC_DOC_TYPES = "DOC_TYPE";

	public static final String ALLOWED_DOC_TYPES[] = { "0010", "0100", "0110", "1000", "1010", "1100", "1110", "0001" };

	public static final String ALLOWED_IMAGE_EXTENSIONS[] = { ".tif", ".jpg", ".jpeg", ".pdf", ".png", ".xps" };

	public static final String FILE_UPLOADED = "UPLOADED";

	public static final String FORM_FILE_FLAG_FOR_XML_FILE = "01";

	public static final String XML_FILE_UPLOAD_STATUS_INITIAL = "01";

	public static final String DMS_VERIFY_FLAG = "VERIFY_SIGN_FOR_DMS";

	public static final String FIRST_PROPOSER = "P1";

	public static final String NAME_SEPARATOR = " ";

	public static final String CHECKER_DECISION_CATEGORY_CODE = "CHKR_DEC";

	public static final String CHECKER_MAKER_DECISION_CATEGORY_CODE = "MKRCHR_DEC";

	public static final String ACCOUNT_STATUS_CATEGORY_CODE = "HLDCS_STAT";

	public static final String USER_NAME_SESION_VARIABLE = "userId";

	public static final String CHECKER_DECISION_ACCEPTED_VALUE = "01";

	public static final String CHECKER_DECISION_REJECTED_VALUE = "02";

	public static final String CRIP_SNDX_HLD_RLS_DOMAIN_NAME = "CripSndxHldRl";

	public static final String CRIP_SNDX_HLD_RLS_HISTORY_DOMAIN_NAME = "CripSndxHldRlsHistory";

	public static final String MAKER_DECISION_ACTIVE_HISTORY = "01";

	public static final String MAKER_DECISION_INACTIVE_HISTORY = "02";

	public static final String CHECKER_DECISION_ACCEPTED_HISTORY = "03";

	public static final String CHECKER_DECISION_REJECTED_HISTORY = "04";

	public static final String CASE_STATUS_WAITING_FOR_MAKER = "00";

	public static final String CASE_STATUS_WAITING_FOR_CHECKER = "01";

	public static final String CASE_STATUS_ACEPTED_BY_CHECKER = "02";

	public static final String CHECKER_DATA_UPDATED_COMPLETED = "completed";

	public static final String CHECKER_DATA_UPDATED_INCOMPLETED = "incompleted";

	public static final String ALTERNATIVE_NULL_VALUE = "---";

	public static final String DUPLICATE = "Duplicate";

	public static final String P1 = "P1";

	public static final String P2 = "P2";

	public static final String P3 = "P3";

	public static final String T1 = "T1";

	public static final String T2 = "T2";

	public static final String T3 = "T3";

	public static final String T4 = "T4";

	public static final String T5 = "T5";

	public static final String T6 = "T6";

	public static final String T7 = "T7";

	public static final String T8 = "T8";

	public static final String T9 = "T9";

	public static final String T10 = "T10";

	public static final String T11 = "T11";

	public static final String T12 = "T12";

	public static final String T13 = "T13";

	public static final String T14 = "T14";

	public static final String T15 = "T15";

	public static final String T16 = "T16";

	public static final String T17 = "T17";

	public static final String T18 = "T18";

	public static final String T19 = "T19";

	public static final String T20 = "T20";

	public static final String T21 = "T21";

	public static final String T22 = "T22";

	public static final String T23 = "T23";

	public static final String T28 = "T28";

	public static final String T29 = "T29";

	public static final String AUDIT_UPDATE_CHAR = "U";

	public static final String ADR_PRF = "ADR_PRF";

	public static final String AGE_PRF = "AGE_PRF";

	public static final String PDF_CROP_DIMENSIONS_PHOTO = "PDF_CROP_DIMENSIONS_PHOTO";

	public static final String PDF_CROP_DIMENSIONS_SIGN = "PDF_CROP_DIMENSIONS_SIGN";

	public static final String FLAG_SOLE_PROPOSER = "P1";

	public static final String FLAG_SECOND_PROPOSER = "P2";

	public static final String FLAG_AUTH_REPRESENTATIVE = "P3";

	public static final String FLAG_PERMANENT_ADDRESS = "p";

	public static final String FLAG_CORRESPONDENCE_ADDRESS = "c";

	public static final String FLAG_FOR_INTERNATIONAL_STATES = "00";

	public static final String FLAG_FOR_NA = "NA";

	public static final String USR_STAT = "USR_STAT";

	public static final String USR_TYPE = "USR_TYPE";

	public static final String ENTITY_CD = "ENTITY_CD";

	public static final String AUTH_TYPE = "AUTH_TYPE";

	public static final String USERINACTIVE = "02";

	public static final String USERSUSPENDED = "03";

	public static final String DSCAPIFORM = "form";

	public static final String DSCAPIFILE = "file";

	public static final String FP_AUTH_NO_EXPIRES = "05";

	public static final String RABBITMQ_MSG_SEPERATOR = "~";

	public static final String SMS_TEMPLATE_FORGOT_LOGIN = "T8";

	public static final String EMAIL_TEMPLATE_FORGOT_LOGIN = "T8";

	public static final String SMS_TEMPLATE_FORGOT_PASSWORD = "T9";

	public static final String EMAIL_TEMPLATE_FORGOT_PASSWORD = "T9";

	public static final String SMS_TEMPLATE_EKYC_OTP = "T28";

	public static final String EMAIL_TEMPLATE_EKYC_OTP = "T28";

	public static final String DATE_FORMAT_AUTH_NO = "yyyyMMdd";

	public static final String DATEFORMAT1 = "dd-MM-yyyy";

	public static final String DATEFORMAT2 = "dd-MM-yyyy hh:mm:ss:SSS";

	public static final String DATEFORMAT3 = "d MMM yyyy";

	public static final String DATEFORMAT4 = "dd-MMM-yyyy HH:mm:ss:SSS";

	public static final String DATEFORMAT5 = "dd-MMM-yyyy";

	public static final String DATE_FORMAT_NOW = "dd-MM-yyyy HH:mm:ss";

	public static final String YEARS = "Year(s)";

	public static final String FLAG_YES = "Y";

	public static final String FLAG_NO = "N";

	public static final String FLAG_CN = "CN=";

	public static final String FLAG_OU = "OU=";

	public static final String CNTY_IND = "IN";

	public static final String CNTY_IND_CODE = "101";

	public static final String BLANK_STRING = "";

	public static final String ZERO = "0";

	public static final String ONE = "1";

	public static final String TWO = "2";

	public static final String ZERO_ZERO = "00";

	public static final String ZERO_ONE = "01";

	public static final String ZERO_TWO = "02";

	public static final String ZERO_THREE = "03";

	public static final String ZERO_FOUR = "04";

	public static final String ZERO_FIVE = "05";

	public static final String COMMA = ",";

	public static final int INTEGER_ONE = 1;

	public static final int INTEGER_TWO = 2;

	public static final int INTEGER_FOUR = 4;

	public static final int INTEGER_THREE = 3;

	public static final int INTEGER_SIX = 6;

	public static final int INTEGER_SIXTY = 60;

	public static final String UPDATE_FLAG = "updateFlag";

	public static final String DOT = ".";

	public static final String CSV_EXT = ".csv";

	public static final String TXT_EXT = ".txt";

	public static final String XLS_EXT = ".xls";

	public static final String XLSX_EXT = ".xlsx";

	public static final String XML_EXT = ".xml";

	public static final String ZIP_EXT = ".zip";

	public static final String CREATEDBYUSER = "XMLParser";

	// RMQ Related
	public static final String RMQ_QUEUES_LIST_BEAN_NAME = "queuesList";

	public static final String RMQ_QKEY_QUEUE_VALIDATION = "queueValidation";

	public static final String STRING_BLANK_VALUE = "";

	public static final String ELEMENT_ADMIN_TEMPLATE_NAME = "AdminTemplate";

	public static final String ELEMENT_PRODUCER_TEMPLATE_NAME = "ProducerTemplate";

	public static final String RMQ_MESSAGE_SEPARATOR = "|";

	public static final String RMQ_MESSAGE_TYPE_SEPARATOR = ":";

	public static final String RMQ_TYPE_WAITING_FORMAT_VALIDATION = "01";

	public static final String RMQ_TYPE_WAITING_BUSINESS_VALIDATION = "02";

	public static final String RMQ_STATUS_PENDING = "01";

	public static final String RMQ_STATUS_COMPLETED = "02";

	public static final String RMQ_NOT_SENT = "00";

	public static final String RMQ_CONFIG_FILE_NAME = "classpath:amqp-config.xml";

	public static final String RMQ_FORMAT_VALIDATION_QUEUE = "formatValidationQueue";

	public static final String RMQ_FORMAT_VALIDATION_ADMIN_TEMPLATE = "formatValidationAdminTemplate";

	public static final String RMQ_FORMAT_VALIDATION_PRODUCER_TEMPLATE = "formatValidationProducerTemplate";

	public static final String RMQ_USER_ID = "rmq_master";

	public static final String RMQ_TYPE_WAITING_EIA_FORMAT_VALIDATION = "11";

	public static final String RMQ_STATUS_NOT_SENT = "00";

	public static final String FORMAT_VALIDATION_HIBERNATE_CONFIGFILE = "formatValidationHibernateConfigFile";

	public static final String APPLICATION_CONTEXT_FILE = "producerConfiguration.xml";

	public static final int RMQ_MESSAGE_ONLY_STRING = 0;

	public static final int RMQ_MESSAGE_BEAN_CONVERSION_REQUIRED = 1;

	public static final String SESSION_FACTORY = "session-factory";

	public static final String HIBERNATE_CONNECTION_DRIVER_CLASS = "hibernate.connection.driver_class";

	public static final String HIBERNATE_CONNECTION_PASSWORD = "hibernate.connection.password";

	public static final String HIBERNATE_CONNECTION_URL = "hibernate.connection.url";

	public static final String HIBERNATE_CONNECTION_USERNAME = "hibernate.connection.username";

	public static final String HIBERNATE_DIALECT = "hibernate.dialect";

	public static final String SHOW_SQL = "show_sql";

	public static final String HBM2DDL_AUTO = "hbm2ddl.auto";

	public static final String HIBERNATE_CURRENT_SESSION_CONTEXT_CLASS = "hibernate.current_session_context_class";

	public static final String HIBERNATE_CURRENT_SESSION_CONTEXT_VALUE = "thread";

	public static final String HIBERNATE_VALIDATOR_APPLY_TO_DDL = "hibernate.validator.apply_to_ddl";

	public static final String HIBERNATE_VALIDATOR_AUTOREGISTER_LISTENERS = "hibernate.validator.autoregister_listeners";

	public static final String BOOLEAN_TRUE_STRING_VALUE = "true";

	public static final String BOOLEAN_FALSE_STRING_VALUE = "false";

	public static final String HIBERNATE_AUDIT_FILE_PATH = "/app/nir/nir-properties/hibernateAudit.cfg.xml";

	public static final String HIBERNATE_CFG_FILE_PATH = "/app/nir/nir-properties/nir-hibernate.cfg.xml";

	public static final String EMAIL_PROPERTY_FILE = "/app/nir/nir-properties/crip-email.properties";

	public static final String CIS_PROPERTY_FILE = "/app/nir/nir-properties/cis-listener.properties";

	public static final String NIR_DAO_PROPERTY_FILE = "/app/nir/nir-properties/nir-dao.properties";

	public static final String NIR_FILE_TRANSFER_PROPERTY_FILE = "/app/nir/nir-properties/nir-fileTransfer.properties";

	public static final String NIR_AADHAAR_SITE_SCRAPPING_PROPERTY_FILE = "/app/nir/nir-properties/nir-aadhaarSiteScrapping.properties";

	public static final String NIR_APP_SERVER_PROPERTIES_FILE = "/app/nir/nir-properties/nir-app-server.properties";

	public static final String NIR_WEB_SERVER_PROPERTIES_FILE = "/app/nir/nir-properties/nir-web-server.properties";

	public static final String NIR_THIRD_PARTY_LOGIN_PROPERTIES_FILE = "/app/nir/nir-properties/nir-third-party-login.properties";

	public static final String NIR_GENERAL_INSURANCE_MOTOR_JRXML = "/app/nir/nir-properties/Jrxml/NIR-MotorPolicyPdf.jrxml";

	public static final String EIA_LOGGER_COMMON = "EIACommonLogger";

	public static final String EIA_LOGGER_LISTNER = "EIAListnerLogger";

	public static final String POLICY_LOGGER_COMMON = "PolicyCommonLogger";

	public static final String POLICY_LOGGER_LISTNER = "PolicyListnerLogger";

	public static final String MASTER_LOGGER_COMMON = "MasterCommonLogger";

	public static final String MASTER_LOGGER_LISTNER = "MasterListnerLogger";

	public static final String LOG4J_APPENDER_XML_VALIDATION = "logFileMaster";

	public static final String DEDUPE_LOGGER = "DedupeLogger";

	public static final String DEDUPE_LOGGER_LISTNER = "DedupeListnerLogger";

	public static final String BUKL_EMAIL_PRODUCER_LOGGER = "BulkEmailProducerLogger";

	public static final String BUKL_EMAIL_LISTNER_LOGGER = "BulkEmailListnerLogger";

	public static final String INSTANT_EMAIL_LISTNER_LOGGER = "InstantEmailListnerLogger";

	public static final String BUKL_SMS_PRODUCER_LOGGER = "BulkSmsProducerLogger";

	public static final String BUKL_SMS_LISTNER_LOGGER = "BulkSmsListnerLogger";

	public static final String INSTANT_SMS_LISTNER_LOGGER = "InstantSmsListnerLogger";

	public static final String MESSAGE_ALERT_LISTNER_LOGGER = "MessageAlertListnerLogger";

	public static final String WS_LOGGER_EIA = "WsLoggerEIA";

	public static final String CIS_WS_LOGGER = "CisWsLogger";

	public static final String LOG4J_PROPERTY_FILE_PATH_SERVER = "/app/nir/nir-properties/Logger/log4j.properties";

	public static final String LOG4J_PROPERTY_FILE_PATH_EJB = "/app/nir/nir-properties/Logger/EJB/log4j.properties";

	public static final String LOG4J_PROPERTY_FILE_PATH_WAR_EIA = "/app/nir/nir-properties/Logger/WAR/EIA/log4j.properties";

	public static final String LOG4J_PROPERTY_FILE_PATH_WAR_POLICY = "/app/nir/nir-properties/Logger/WAR/POLICY/log4j.properties";

	public static final String LOG4J_PROPERTY_FILE_PATH_WAR_DEDUPE = "/app/nir/nir-properties/Logger/WAR/DEDUPE/log4j.properties";

	public static final String LOG4J_PROPERTY_FILE_PATH_WAR_MASTER = "/app/nir/nir-properties/Logger/WAR/MASTER/log4j.properties";

	public static final String LOG4J_PROPERTY_FILE_PATH_WAR_EMAIL = "/app/nir/nir-properties/Logger/WAR/EMAIL/log4j.properties";

	public static final String LOG4J_PROPERTY_FILE_PATH_WAR_SMS = "/app/nir/nir-properties/Logger/WAR/SMS/log4j.properties";

	/*----------------------------------------------------*/
	public static final String DEDUPE_CONFIG_FILE = "/app/nir/nir-properties/nir-dedupe.properties";

	public static final String cisWsStoreDir = NIRConstants.BASE_FILE_SYSTEM_PATH + "Webservice/CISWebservice/";

	public static final String eiaWsStoreDir = NIRConstants.BASE_FILE_SYSTEM_PATH + "Webservice/EIAWebservice/";

	public static final String DATE_FORMAT = "dd-MM-yyyy";

	public static final int SOUNDEX_THRESHOLD = 50;

	public static final double SOUNDEX_CUTOFFPER = 97;

	public static final String SOUNDX_CRTBY = "DEDUPE";

	public static final String CRON_CRT_BY = "TCS";

	public static final String HOLD_STATUS = "03";

	public static final String TIME_STAMP_FORMAT = "dd-MMM-yyyy HH:mm:ss";

	public static final String SMS_OTP_TEMPLATE_FIRST_LOGIN = "T18";

	public static final String SMS_SINGLE_OTP_TEMPLATE_FIRST_LOGIN = "T27";

	public static final String EMAIL_OTP_TEMPLATE_FIRST_LOGIN = "T18";

	public static final String EMAIL_SINGLE_OTP_TEMPLATE_FIRST_LOGIN = "T27";

	public static final String SINGLE_SMS_OTP_TEMPLATE_FIRST_LOGIN = "T25";

	public static final String SINGLE_EMAIL_OTP_TEMPLATE_FIRST_LOGIN = "T25";

	public static final String SMS_PWD_CHANGE_TEMPLATE = "T19";

	public static final String EMAIL_PWD_CHANGE_TEMPLATE = "T19";

	public static final String SMS_PWD_SET_TEMPLATE = "T20";

	public static final String EMAIL_PWD_SET_TEMPLATE = "T20";

	public static final String SMS_TEMPLATE_FOR_LOCKED_ACNT = "T22";

	public static final String EMAIL_TEMPLATE_FOR_LOCKED_ACNT = "T22";

	public static final String SMS_TEMPLATE_FOR_POLICY_CONVERSION = "T23";

	public static final String EMAIL_TEMPLATE_FOR_POLICY_CONVERSION = "T23";

	public static final String EMAIL_TEMPLATE_FOR_AUTHORIZED_REPRESENTATIVE = "T24";

	public static final String SMS_TEMPLATE_FOR_AUTHORIZED_REPRESENTATIVE = "T24";

	public static final String MEESAGE_ALERT_CONFIG_FILE = "/app/nir/nir-properties/nir-alerts.properties";

	public static final int IR = 35;

	public static final int INSURER = 36;

	public static final int DOWNLOAD_ALL = 1;

	public static final int DOWNLOAD_PENDING = 2;

	public static Map<String, String> FILE_EXTENSION_MAP = new LinkedHashMap<String, String>();

	// Starts Amol B 13th March file validation check file content.
	public static Map<String, String> FILE_CONTENT_MAP = new LinkedHashMap<String, String>();
	// End
	static {
		FILE_EXTENSION_MAP.put("jpg", "jpg");
		FILE_EXTENSION_MAP.put("pdf", "pdf");
		FILE_EXTENSION_MAP.put("jpeg", "jpeg");
		FILE_EXTENSION_MAP.put("tif", "tif");
	}

	static {
		FILE_CONTENT_MAP.put("jpg", "image/jpeg");
		FILE_CONTENT_MAP.put("pdf", "application/pdf");
		FILE_CONTENT_MAP.put("jpeg", "image/jpeg");
		FILE_CONTENT_MAP.put("tif", "image/tiff");
	}
	/* Start Ajit 26-10-2016 EIA_Deactivation_Status_Added */
	public static final String EIA_DEACT_STATUS = "EIA_DEACT_STATUS";
	/* End Ajit 26-10-2016 EIA_Deactivation_Status_Added */
	/* Start Ajit Policy Deletion PLCY_TYPE Added */
	public static final String PLCY_TYPE = "PLCY_TYPE";
	/* End Ajit Policy Deletion PLCY_TYPE Added */

	// Added by amol to store aadhaar details
	public static final String PHOTO_SIGN_FILE_PATH_WEB = NIRConstants.BASE_FILE_SYSTEM_PATH + "Aadhar_Files/Photos/";
	public static final String AADHAR_PDF_FILE_PATH_WEB = NIRConstants.BASE_FILE_SYSTEM_PATH + "Aadhar_Files/Pdf/";
	// End aadhaar details

	// Added by sumedh to get cert for Mbil partner
	public static final String MBIL_PARTNER_CONFIG_FILE = "/app/nir/nir-properties/nir-PartnerConfiguration.properties";
	public static final String SMS_TEMPLATE_PARNER = "T29";
	public static final String EMAIL_TEMPLATE_FOR_PARTNER = "T29";

	/* Start Ajit PolicyDataService */
	public static final int REQUESTED_BY = 35;
	public static final int DOWNLOAD_OPTION = 2;
	public static final String DESTINATIONFILEPATHPLCY = NIRConstants.BASE_FILE_SYSTEM_PATH + "IPIN/FILE";
	public static final String DESTINATIONFILEPATHEIA = NIRConstants.BASE_FILE_SYSTEM_PATH + "EIA/FILE";
	public static final String ERROR_PATH_EIA = NIRConstants.BASE_FILE_SYSTEM_PATH + "EIA/ERROR/";
	public static final String ERROR_PATH_PLCY = NIRConstants.BASE_FILE_SYSTEM_PATH + "IPIN/ERROR/";
	public static final String AUTOUPLOAD_LOGGER = "AutouploadLogger";
	/* End Ajit Policy PolicyDataService */
	// "/app/nir/filesystem/";

	public static final String CORPORATE_ADDRESS = "C1";
	// Ended by Sumedh

}
