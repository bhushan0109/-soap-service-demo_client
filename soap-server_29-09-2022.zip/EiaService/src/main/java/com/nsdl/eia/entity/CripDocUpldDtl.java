package com.nsdl.eia.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the CRIP_DOC_UPLD_DTLS database table.
 */
@Entity
@Table(name = "NIR.CRIP_DOC_UPLD_DTLS")
public class CripDocUpldDtl implements Serializable {// , Auditable {
	private static final long serialVersionUID = 1L;

	// public String[] getId() {
	// String[] id = new String[3];
	// id[0] = "CDUD_EIA_ACCT_ID:" +
	// (cdudEiaAcctId!=null&&!cdudEiaAcctId.trim().equalsIgnoreCase("")?cdudEiaAcctId:"NP");
	// id[1] = "CDUD_FILE_ID:" + cdudFileId;
	// id[2] = "CDUD_DOC_TYPE:" + cdudDocType;
	// return id;
	// }
	@Id
	@TableGenerator(name = "NIR", table = "NIR.CRIP_ID_GNRTR", pkColumnName = "CIG_GEN_KEY", valueColumnName = "CIG_GEN_VALUE", pkColumnValue = "IMAGE_ID", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "NIR")
	@Column(name = "CDUD_SR_NO")
	private Long cdudSrNo;

	@Column(name = "CDUD_ACK_NO")
	private String cdudAckNo;

	@Column(name = "CDUD_CRT_BY")
	private String cdudCrtBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CDUD_CRT_DATE")
	private Calendar cdudCrtDate;

	@Column(name = "CDUD_DOC_NAME")
	private String cdudDocName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CDUD_DOC_RECIEPT_DT")
	private Calendar cdudDocRecieptDt;

	// FTR 5458 Start
	// @Column(name = "CDUD_DOC_REF_NO")
	// private String cdudDocRefNo;
	// FTR 5458 End

	@Column(name = "CDUD_DOC_SRVR_PATH")
	private String cdudDocSrvrPath;

	@Column(name = "CDUD_DOC_TYPE")
	private String cdudDocType;

	@Column(name = "CDUD_EIA_ACCT_ID")
	private String cdudEiaAcctId;

	@Column(name = "CDUD_FILE_ID")
	private String cdudFileId;

	@Column(name = "CDUD_LST_UPD_TMSTMP")
	private Timestamp cdudLstUpdTmstmp;

	@Column(name = "CDUD_MODF_BY")
	private String cdudModfBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CDUD_MODF_DATE")
	private Calendar cdudModfDate;

	@Column(name = "CDUD_RECEIPT_NO")
	private String cdudReceiptNo;

	@Column(name = "CDUD_REMARKS")
	private String cdudRemarks;

	@Column(name = "CDUD_STATUS")
	private String cdudStatus;

	@Column(name = "CDUD_DOC_CAT")
	private String cdudDocCat;

	@Column(name = "CDUD_IPIN_NO")
	private Long cdudIpinNo;
	// Added for Hbase download 29Nov.2018 Amol B
	@Column(name = "CDUD_ROWKEY_DOC")
	private String cdudRowKeyDoc;

	// Swapnali added cdud_corporate_dr_pan
	/*
	 * @Column(name="cdud_corporate_dr_pan") private String cdudCorporateDrPan;
	 * 
	 * @Column(name="cdud_doc_name_other") private String cdudDocNameOther;
	 */

	/*
	 * public String getCdudDocNameOther() { return cdudDocNameOther; }
	 * 
	 * public void setCdudDocNameOther(String cdudDocNameOther) {
	 * this.cdudDocNameOther = cdudDocNameOther; }
	 * 
	 * public String getCdudCorporateDrPan() { return cdudCorporateDrPan; }
	 * 
	 * public void setCdudCorporateDrPan(String cdudCorporateDrPan) {
	 * this.cdudCorporateDrPan = cdudCorporateDrPan; }
	 */

	public String getCdudRowKeyDoc() {
		return cdudRowKeyDoc;
	}

	public void setCdudRowKeyDoc(String cdudRowKeyDoc) {
		this.cdudRowKeyDoc = cdudRowKeyDoc;
	}

	public Long getCdudIpinNo() {
		return cdudIpinNo;
	}

	public void setCdudIpinNo(Long cdudIpinNo) {
		this.cdudIpinNo = cdudIpinNo;
	}

	public String getCdudDocCat() {
		return cdudDocCat;
	}

	public void setCdudDocCat(String cdudDocCat) {
		this.cdudDocCat = cdudDocCat;
	}

	public CripDocUpldDtl() {
	}

	public long getCdudSrNo() {
		return this.cdudSrNo;
	}

	public void setCdudSrNo(long cdudSrNo) {
		this.cdudSrNo = cdudSrNo;
	}

	public String getCdudAckNo() {
		return this.cdudAckNo;
	}

	public void setCdudAckNo(String cdudAckNo) {
		this.cdudAckNo = cdudAckNo;
	}

	public String getCdudCrtBy() {
		return this.cdudCrtBy;
	}

	public void setCdudCrtBy(String cdudCrtBy) {
		this.cdudCrtBy = cdudCrtBy;
	}

	public Calendar getCdudCrtDate() {
		return this.cdudCrtDate;
	}

	public void setCdudCrtDate(Calendar cdudCrtDate) {
		this.cdudCrtDate = cdudCrtDate;
	}

	public String getCdudDocName() {
		return this.cdudDocName;
	}

	public void setCdudDocName(String cdudDocName) {
		this.cdudDocName = cdudDocName;
	}

	public Calendar getCdudDocRecieptDt() {
		return this.cdudDocRecieptDt;
	}

	public void setCdudDocRecieptDt(Calendar cdudDocRecieptDt) {
		this.cdudDocRecieptDt = cdudDocRecieptDt;
	}

	public String getCdudDocSrvrPath() {
		return this.cdudDocSrvrPath;
	}

	public void setCdudDocSrvrPath(String cdudDocSrvrPath) {
		this.cdudDocSrvrPath = cdudDocSrvrPath;
	}

	public String getCdudDocType() {
		return this.cdudDocType;
	}

	public void setCdudDocType(String cdudDocType) {
		this.cdudDocType = cdudDocType;
	}

	public String getCdudEiaAcctId() {
		return this.cdudEiaAcctId;
	}

	public void setCdudEiaAcctId(String cdudEiaAcctId) {
		this.cdudEiaAcctId = cdudEiaAcctId;
	}

	public String getCdudFileId() {
		return this.cdudFileId;
	}

	public void setCdudFileId(String cdudFileId) {
		this.cdudFileId = cdudFileId;
	}

	public Timestamp getCdudLstUpdTmstmp() {
		return this.cdudLstUpdTmstmp;
	}

	public void setCdudLstUpdTmstmp(Timestamp cdudLstUpdTmstmp) {
		this.cdudLstUpdTmstmp = cdudLstUpdTmstmp;
	}

	public String getCdudModfBy() {
		return this.cdudModfBy;
	}

	public void setCdudModfBy(String cdudModfBy) {
		this.cdudModfBy = cdudModfBy;
	}

	public Calendar getCdudModfDate() {
		return this.cdudModfDate;
	}

	public void setCdudModfDate(Calendar cdudModfDate) {
		this.cdudModfDate = cdudModfDate;
	}

	public String getCdudReceiptNo() {
		return this.cdudReceiptNo;
	}

	public void setCdudReceiptNo(String cdudReceiptNo) {
		this.cdudReceiptNo = cdudReceiptNo;
	}

	public String getCdudRemarks() {
		return this.cdudRemarks;
	}

	public void setCdudRemarks(String cdudRemarks) {
		this.cdudRemarks = cdudRemarks;
	}

	public String getCdudStatus() {
		return this.cdudStatus;
	}

	public void setCdudStatus(String cdudStatus) {
		this.cdudStatus = cdudStatus;
	}

	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH,
			CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "CDUD_EIA_ACCT_ID", referencedColumnName = "CEA_EIA_ACCT_ID", insertable = false, updatable = false) })
	private CripEiaAcct cripEiaAcct;

	public CripEiaAcct getCripEiaAcct() {
		return cripEiaAcct;
	}

	public void setCripEiaAcct(CripEiaAcct cripEiaAcct) {
		this.cripEiaAcct = cripEiaAcct;
	}
}