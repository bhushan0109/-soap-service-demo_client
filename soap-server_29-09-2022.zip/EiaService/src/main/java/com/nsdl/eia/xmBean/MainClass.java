//package com.nsdl.eia.xmBean;
//
//import java.io.BufferedReader;
//import java.io.FileInputStream;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.io.OutputStreamWriter;
//import java.net.ConnectException;
//import java.net.URL;
//import java.net.URLEncoder;
//import java.security.KeyManagementException;
//import java.security.NoSuchAlgorithmException;
//import java.security.SecureRandom;
//import java.util.Calendar;
//import java.util.Date;
//import java.util.Properties;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import javax.net.ssl.HttpsURLConnection;
//import javax.net.ssl.KeyManager;
//import javax.net.ssl.SSLContext;
//import javax.net.ssl.SSLSocketFactory;
//import javax.net.ssl.TrustManager;
//
//import com.ndml.nir.ITDCommon.DummyHostnameVerifier;
//import com.ndml.nir.ITDCommon.DummyTrustManager;
//import com.ndml.nir.ITDUtil.SignerUtils;
//
//public class MainClass {
//	public static String USERID = null;
//	public static String DELIMITER = null;
//	public static String PAN_URL = null;
//	public static String PASSWORD = null;
//	public static String JKSFILEPATH = null;
//	public static String SIGNFILEPATH = null;
//
//	private static final Logger LOG = LogManager.getLogger(MainClass.class);
//	private String requestData;
//
//	public String getRequestData() {
//		return requestData;
//	}
//
//	public void setRequestData(String requestData) {
//		this.requestData = requestData;
//	}
//
//	static {
//
//		Properties prop = new Properties();
//		FileInputStream fileStream = null;
//		try {
//			fileStream = new FileInputStream("/app/ITD/itd_verification.properties");
//			prop.load(fileStream);
//
//			USERID = prop.getProperty("verification.user.id");
//			DELIMITER = prop.getProperty("DELIMITER");
//			PAN_URL = prop.getProperty("verification.url");
//			PASSWORD = prop.getProperty("JKSPWD");
//			JKSFILEPATH = prop.getProperty("jks.filePath");
//			SIGNFILEPATH = prop.getProperty("sign.filePath");
//
//		} catch (Exception e) {
//			LOG.info("Exception while loading properties file in MainClass of ITD Verification" + e.getMessage());
//			e.printStackTrace();
//		} finally {
//			fileStream = null;
//			prop = null;
//		}
//
//	}
//
//	public static void main(String[] args) {
//		MainClass panObject = new MainClass();
//		// String response=panObject.getPanData("ADZPT0664M");
//		// String response=panObject.getPanData("AVVPB5809Q");
//		String response = panObject.getPanData("CSBPM7775D");
//		// 1^ZZZZZZZZZZ^N^^^^^^^^
//		// 1^AVVPB5809Q^E^BAVISKAR^AMOL^SURESH^Shri^29/08/2017^^Y^
//		// String requestData = panObject.getRequestData();
//
//		// System.out.println("Request Data in main method :-:-->> "+requestData);
//		System.out.println("Response Data in main method :-:-->> " + response);
//	}
//
//	public String getPanData(String pan) {
//
//		LOG.info("UserID " + USERID);
//		LOG.info("DELIMITER " + DELIMITER);
//		LOG.info("PAN_URL " + PAN_URL);
//		LOG.info("PASSWORD " + PASSWORD);
//		LOG.info("JKSFILEPATH " + JKSFILEPATH);
//		LOG.info("SIGNFILEPATH " + SIGNFILEPATH);
//
//		SignerUtils signer = new SignerUtils();
//		String data = USERID + DELIMITER + pan;
//
//		LOG.info("Pan Data " + data);
//
//		Date startTime = null;
//		Calendar c1 = Calendar.getInstance();
//		startTime = c1.getTime();
//
//		Date connectionStartTime = null;
//		String logMsg = "\n-";
//
//		Calendar c = Calendar.getInstance();
//		long nonce = c.getTimeInMillis();
//		String line = null;
//
//		// String signature = signer.signData(JKSFILEPATH,PASSWORD,data,SIGNFILEPATH);
//		String signature = signer.getSignature(JKSFILEPATH, PASSWORD, data, SIGNFILEPATH);
//
//		LOG.info("Sign Data " + signature);
//
//		SSLContext sslcontext = null;
//		try {
//			LOG.info("SSL Context setting Starts..");
//			sslcontext = SSLContext.getInstance("SSL");
//
//			sslcontext.init(new KeyManager[0], new TrustManager[] { new DummyTrustManager() }, new SecureRandom());
//			LOG.info("SSL Context setting End");
//		} catch (NoSuchAlgorithmException e) {
//			LOG.info(logMsg = logMsg + "::Exception: " + e.getMessage() + " ::Program Start Time:" + startTime
//					+ "::nonce= " + nonce);
//			e.printStackTrace(System.err);
//		} catch (KeyManagementException e) {
//			LOG.info(logMsg = logMsg + "::Exception: " + e.getMessage() + " ::Program Start Time:" + startTime
//					+ "::nonce= " + nonce);
//			e.printStackTrace(System.err);
//		}
//		SSLSocketFactory factory = sslcontext.getSocketFactory();
//
//		String urlParameters = "data=";
//		try {
//			urlParameters = urlParameters + URLEncoder.encode(data, "UTF-8") + "&signature="
//					+ URLEncoder.encode(signature, "UTF-8") + "&version=" + URLEncoder.encode("2", "UTF-8");
//			setRequestData(urlParameters);
//			LOG.info("URL parameter setting done " + urlParameters);
//
//		} catch (Exception e) {
//			LOG.info(logMsg = logMsg + "::Exception: " + e.getMessage() + " ::Program Start Time:" + startTime
//					+ "::nonce= " + nonce);
//			e.printStackTrace();
//		}
//		try {
//			LOG.info("Calling ITD Service.....");
//			InputStream is = null;
//
//			String ip = PAN_URL;
//			URL url = new URL(ip);
//			HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
//			connection.setRequestMethod("POST");
//			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//			connection.setRequestProperty("Content-Length", Integer.toString(urlParameters.getBytes().length));
//			connection.setRequestProperty("Content-Language", "en-US");
//			connection.setUseCaches(false);
//			connection.setDoInput(true);
//			connection.setDoOutput(true);
//			connection.setSSLSocketFactory(factory);
//			connection.setHostnameVerifier(new DummyHostnameVerifier());
//			OutputStream os = connection.getOutputStream();
//			OutputStreamWriter osw = new OutputStreamWriter(os);
//			osw.write(urlParameters);
//			osw.flush();
//			connectionStartTime = new Date();
//			logMsg = logMsg + "::Request Sent At: " + connectionStartTime;
//			logMsg = logMsg + "::Request Data: " + data;
//			osw.close();
//			is = connection.getInputStream();
//			BufferedReader in = new BufferedReader(new InputStreamReader(is));
//			line = in.readLine();
//
//			is.close();
//			in.close();
//			LOG.info("ITD Service Call done..........");
//		} catch (ConnectException e) {
//			LOG.info(logMsg = logMsg + "::Exception: " + e.getMessage() + "::Program Start Time:" + startTime
//					+ "::nonce= " + nonce);
//		} catch (Exception e) {
//			LOG.info(logMsg = logMsg + "::Exception: " + e.getMessage() + "::Program Start Time:" + startTime
//					+ "::nonce= " + nonce);
//			e.printStackTrace();
//		}
//		return line;
//	}
//}
