package com.nsdl.eia.otherentity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

//@Data
@Entity
@Table(name="nir_partner_ip_mapping")
public class NirPartnerIpMapping {

	
	@Id
	@Column(name="Seq")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long Sequence;
	
	
	
	@Column(name="npip_ip_address")
	private String ipAddress;
	
	@Column(name="npip_ip_region")
	private String ipRegion;
	
	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE,
			CascadeType.REFRESH, CascadeType.REMOVE }, fetch = FetchType.LAZY)
	@JoinColumn(name = "npip_id", nullable = false,referencedColumnName="npc_id")
	NirPartnerMstr nirPartnerMstr2;

	
		

	public Long getSequence() {
		return Sequence;
	}

	public void setSequence(Long sequence) {
		Sequence = sequence;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getIpRegion() {
		return ipRegion;
	}

	public void setIpRegion(String ipRegion) {
		this.ipRegion = ipRegion;
	}

	public NirPartnerMstr getNirPartnerMstr() {
		return nirPartnerMstr2;
	}

	public void setNirPartnerMstr(NirPartnerMstr nirPartnerMstr2) {
		this.nirPartnerMstr2 = nirPartnerMstr2;
	}

	public NirPartnerMstr getNirPartnerMstr2() {
		return nirPartnerMstr2;
	}

	public void setNirPartnerMstr2(NirPartnerMstr nirPartnerMstr2) {
		this.nirPartnerMstr2 = nirPartnerMstr2;
	}

//	@Override
//	public String toString() {
//		return "NirPartnerIpMapping [Sequence=" + Sequence + ", ipAddress=" + ipAddress + ", ipRegion=" + ipRegion
//				+ ", nirPartnerMstr2=" + nirPartnerMstr2 + "]";
//	}	
	
}