package com.nsdl.eia.xmBean;

import static org.w3c.dom.Node.ATTRIBUTE_NODE;
import static org.w3c.dom.Node.CDATA_SECTION_NODE;
import static org.w3c.dom.Node.COMMENT_NODE;
import static org.w3c.dom.Node.DOCUMENT_TYPE_NODE;
import static org.w3c.dom.Node.ELEMENT_NODE;
import static org.w3c.dom.Node.ENTITY_NODE;
import static org.w3c.dom.Node.ENTITY_REFERENCE_NODE;
import static org.w3c.dom.Node.NOTATION_NODE;
import static org.w3c.dom.Node.PROCESSING_INSTRUCTION_NODE;
import static org.w3c.dom.Node.TEXT_NODE;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentType;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.nsdl.eia.constants.NIRConstants;

public class NJEiaService {
	public static final Logger LOGGER = LogManager.getLogger(NIRConstants.EIA_LOGGER_COMMON);

	public EIAMasterBean eiaMasterBean = new EIAMasterBean();

	public String panForError = "";

	public String uidForError = "";

	public int numberOfApplicants = 1;

	public boolean isSecondProposerPresent = false;

	public boolean isEiaTagPresent = false;

	public List<AccountOpeningFormBean> startBusinessValidation(File f) {

		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		builderFactory.setNamespaceAware(true); // Set namespace aware
		builderFactory.setValidating(false); // and validating parser features
		builderFactory.setIgnoringElementContentWhitespace(true);
		DocumentBuilder builder = null;
		try {
			builder = builderFactory.newDocumentBuilder(); // Create the parser
		} catch (ParserConfigurationException e) {
			LOGGER.fatal("ParserConfigurationException in EIAValidator :" + e.getMessage());
			e.printStackTrace();
		}
		Document xmlDoc = null;
		try {
			xmlDoc = builder.parse(f);
		} catch (SAXException e) {
			LOGGER.fatal("SAXException in startBusinessValidation method :" + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			LOGGER.fatal("IOException in startBusinessValidation method :" + e.getMessage());
			e.printStackTrace();
		}
		DocumentType doctype = xmlDoc.getDoctype();
		if (doctype == null) {
			LOGGER.warn("DOCTYPE is null");
		} else {
			LOGGER.warn("DOCTYPE Internal Subset--->" + doctype.getInternalSubset());
		}
		LOGGER.warn("Calling setEIADetails method to set all beans");
		// bean set logic
		List<AccountOpeningFormBean> accountOpeningFormBeanList = setEIADetails(xmlDoc.getDocumentElement(), "");

		return accountOpeningFormBeanList;

	}

	public List<AccountOpeningFormBean> setEIADetails(Node node, String indent) {

		List<AccountOpeningFormBean> accountOpeningFormBeanList = new ArrayList<AccountOpeningFormBean>();
		try {
			LOGGER.info("In setEIADetails method of EIAValidator class---->");

			NodeList list = node.getChildNodes();
			if (list.getLength() > 0) {
				for (int i = 0; i < list.getLength(); i++) {
					if (!list.item(i).getNodeName().equalsIgnoreCase("#text")) {
						if (list.item(i).getNodeName().equalsIgnoreCase("File_Header")) {
							eiaMasterBean.seteIAFileHeaderBean(setFileHeaderBean(list.item(i)));
						} else if (list.item(i).getNodeName().equalsIgnoreCase("Person_eIA_Detail")) {
							AccountOpeningFormBean accountOpeningFormBean = setAccountOpeningFormBeanData(list.item(i));
							accountOpeningFormBeanList.add(accountOpeningFormBean);
						}
					}
				}
			}
			eiaMasterBean.setAccountOpeningFormBeanList(accountOpeningFormBeanList);
			LOGGER.info("All eia bean setting done. Is eia tag present-->" + isEiaTagPresent);

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("Exception::: " + e);

		}
		return accountOpeningFormBeanList;
	}

	public EIAFileHeaderBean setFileHeaderBean(Node node) {
		EIAFileHeaderBean eiafileHeaderBean = new EIAFileHeaderBean();
		NodeList fileHeaderChildNode = node.getChildNodes();
		if (fileHeaderChildNode.getLength() > 0) {
			for (int i = 0; i < fileHeaderChildNode.getLength(); i++) {
				if (!fileHeaderChildNode.item(i).getNodeName().equalsIgnoreCase("#text")) {
					if (fileHeaderChildNode.item(i).getNodeName().equalsIgnoreCase("File_id")) {
						eiafileHeaderBean.setFileId(fileHeaderChildNode.item(i).getTextContent());
					} else if (fileHeaderChildNode.item(i).getNodeName().equalsIgnoreCase("From")) {
						eiafileHeaderBean.setFrom(fileHeaderChildNode.item(i).getTextContent());
					} else if (fileHeaderChildNode.item(i).getNodeName().equalsIgnoreCase("Date_Of_Generation")) {
						eiafileHeaderBean.setDateOfGeneration(fileHeaderChildNode.item(i).getTextContent());
					} else if (fileHeaderChildNode.item(i).getNodeName().equalsIgnoreCase("File_Type")) {
						eiafileHeaderBean.setFileType(fileHeaderChildNode.item(i).getTextContent());
					} else if (fileHeaderChildNode.item(i).getNodeName().equalsIgnoreCase("Num_Of_eIA_Acc_Details")) {
						eiafileHeaderBean.setNumOfEIAAccountDetails(fileHeaderChildNode.item(i).getTextContent());
					} else if (fileHeaderChildNode.item(i).getNodeName().equalsIgnoreCase("FVUHash")) { // no need
						eiafileHeaderBean.setfVUHash(fileHeaderChildNode.item(i).getTextContent());
					} else if (fileHeaderChildNode.item(i).getNodeName().equalsIgnoreCase("FVUVersion")) { // no need
						eiafileHeaderBean.setfVUVersion(fileHeaderChildNode.item(i).getTextContent());
					}
				}
			}
		}
		return eiafileHeaderBean;
	}

	public AccountOpeningFormBean setAccountOpeningFormBeanData(Node node) {
		LOGGER.info("In setAccountOpeningFormBeanData--->" + node.getNodeName());
		AccountOpeningFormBean accountOpeningFormBean = new AccountOpeningFormBean();
		List<ProposalDetailBean> proposalDetailBeanList = new ArrayList<ProposalDetailBean>();
		proposalDetailBeanList.add(new ProposalDetailBean());
		proposalDetailBeanList.add(new ProposalDetailBean()); // not need
		proposalDetailBeanList.add(new ProposalDetailBean()); // not need
		accountOpeningFormBean.setProposalDetailBeanList(proposalDetailBeanList);
		NodeList accountOpeningFormBeanNodes = node.getChildNodes();
		if (accountOpeningFormBeanNodes.getLength() > 0) {
			for (int i = 0; i < accountOpeningFormBeanNodes.getLength(); i++) {
				if (!accountOpeningFormBeanNodes.item(i).getNodeName().equalsIgnoreCase("#text")) {
					if (accountOpeningFormBeanNodes.item(i).getNodeName().equalsIgnoreCase("Id")) {
						accountOpeningFormBean.setId(accountOpeningFormBeanNodes.item(i).getTextContent());
					} else if (accountOpeningFormBeanNodes.item(i).getNodeName().equalsIgnoreCase("eIADetails")) {
						NodeList eiaDetailsNodes = accountOpeningFormBeanNodes.item(i).getChildNodes();
						if (eiaDetailsNodes.getLength() > 0) {
							for (int j = 0; j < eiaDetailsNodes.getLength(); j++) {
								// LOGGER.info("EIA Detail Node Name
								// ------>"+eiaDetailsNodes.item(j).getNodeName());
								if (!eiaDetailsNodes.item(j).getNodeName().equalsIgnoreCase("#text")) {
									if (eiaDetailsNodes.item(j).getNodeName().equalsIgnoreCase("AccCategory")) {
										String text = null;
										if (eiaDetailsNodes.item(j).getTextContent() != null && !eiaDetailsNodes.item(j)
												.getTextContent().equals(NIRConstants.BLANK_STRING)) {
											int num = Integer.valueOf(eiaDetailsNodes.item(j).getTextContent());
											text = (num < 10 ? "0" : "") + num;
										} else {
											text = eiaDetailsNodes.item(j).getTextContent();
										}
										accountOpeningFormBean.setAccountCategory(text);
									}

									/* Start CR 13-05-2016 */
									if (eiaDetailsNodes.item(j).getNodeName().equalsIgnoreCase("KYCCategory")) {
										String text = null;
										if (eiaDetailsNodes.item(j).getTextContent() != null && !eiaDetailsNodes.item(j)
												.getTextContent().equals(NIRConstants.BLANK_STRING)) {
											int num = Integer.valueOf(eiaDetailsNodes.item(j).getTextContent());
											text = (num < 10 ? "0" : "") + num;
										} else {
											text = eiaDetailsNodes.item(j).getTextContent();
										}
										accountOpeningFormBean.setKycCategory(text);
									}
									/* End CR 13-05-2016 */

									else if (eiaDetailsNodes.item(j).getNodeName().equalsIgnoreCase("TypeOfAcc")) {
										String text = null;
										if (eiaDetailsNodes.item(j).getTextContent() != null && !eiaDetailsNodes.item(j)
												.getTextContent().equals(NIRConstants.BLANK_STRING)) {
											int num = Integer.valueOf(eiaDetailsNodes.item(j).getTextContent());
											text = (num < 10 ? "0" : "") + num;
										} else {
											text = eiaDetailsNodes.item(j).getTextContent();
										}
										accountOpeningFormBean.setAccountType(text);
									} else if (eiaDetailsNodes.item(j).getNodeName().equalsIgnoreCase("AppNo")) {
										accountOpeningFormBean
												.setApplicationNo(eiaDetailsNodes.item(j).getTextContent());
									} else if (eiaDetailsNodes.item(j).getNodeName()
											.equalsIgnoreCase("Insurance_Cmpny_Cd")) {
										String text = null;
										if (eiaDetailsNodes.item(j).getTextContent() != null && !eiaDetailsNodes.item(j)
												.getTextContent().equals(NIRConstants.BLANK_STRING)) {
											int num = Integer.valueOf(eiaDetailsNodes.item(j).getTextContent());
											text = (num < 10 ? "0" : "") + num;
										} else {
											text = eiaDetailsNodes.item(j).getTextContent();
										}
										accountOpeningFormBean.setIcCd(text);
									} else if (eiaDetailsNodes.item(j).getNodeName()
											.equalsIgnoreCase("Date_Of_Receipt")) {
										accountOpeningFormBean.setFormSubDate(eiaDetailsNodes.item(j).getTextContent());
									} else if (eiaDetailsNodes.item(j).getNodeName().equalsIgnoreCase("eIA")) {
										accountOpeningFormBean.setEiaNo(eiaDetailsNodes.item(j).getTextContent());
										isEiaTagPresent = true;
									}
								}
							}
						}
					} else if (accountOpeningFormBeanNodes.item(i).getNodeName().equalsIgnoreCase("Applicant_Detail")) {
						NodeList applicantDetailNodes = accountOpeningFormBeanNodes.item(i).getChildNodes();
						if (applicantDetailNodes.getLength() > 0) {
							for (int k = 0; k < applicantDetailNodes.getLength(); k++) {
								// LOGGER.info("Applicant Detail Node Name
								// ------>"+applicantDetailNodes.item(k).getNodeName());
								if (!applicantDetailNodes.item(k).getNodeName().equalsIgnoreCase("#text")) {
									if (applicantDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("No_Of_Applicant")) {
										accountOpeningFormBean
												.setNumberOfApplicants(applicantDetailNodes.item(k).getTextContent());
									} else if (applicantDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Applicant")) {
										String valueString = null;
										NamedNodeMap attrs = applicantDetailNodes.item(k).getAttributes();
										for (int t = 0; t < attrs.getLength(); t++) {
											Attr attribute = (Attr) attrs.item(t);
											/*
											 * LOGGER.info("Attributes --->"+attribute); String name =
											 * attribute.getName().toLowerCase().toString();
											 * LOGGER.info("Attribute Name------->"+name);
											 */
											valueString = attribute.getValue().toString();
											// LOGGER.info("Attribute Value String------->"+valueString);
										}
										if (valueString != null
												&& valueString.toLowerCase().equalsIgnoreCase("Second Proposer")) { // no
																													// need
											isSecondProposerPresent = true;
											numberOfApplicants = 2;
										}
										setProposalDetailBean(applicantDetailNodes.item(k), false,
												accountOpeningFormBean);
									}
									/*-------------------------new changes----------------------------*/
									else if (applicantDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Bank_Details")) {
										setBankDetails(applicantDetailNodes.item(k), accountOpeningFormBean);
									} else if (applicantDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Authorized_Representative")) {
										setProposalDetailBean(applicantDetailNodes.item(k), true,
												accountOpeningFormBean);
									} else if (applicantDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Other_Detail")) {
										NodeList otherDetailNodes = applicantDetailNodes.item(k).getChildNodes();
										int index = 0;
										if (otherDetailNodes.getLength() > 0) {
											for (int m = 0; m < otherDetailNodes.getLength(); m++) {
												if (!otherDetailNodes.item(m).getNodeName().equalsIgnoreCase("#text")) {
													if (otherDetailNodes.item(m).getNodeName()
															.equalsIgnoreCase("ID_Proof")) {
														String text = null;
														if (otherDetailNodes.item(m).getTextContent() != null
																&& !otherDetailNodes.item(m).getTextContent()
																		.equals(NIRConstants.BLANK_STRING)) {
															int num = Integer
																	.valueOf(otherDetailNodes.item(m).getTextContent());
															text = (num < 10 ? "0" : "") + num;
														} else {
															text = otherDetailNodes.item(m).getTextContent();
														}
														accountOpeningFormBean.getProposalDetailBeanList().get(index)
																.setIdProof(text);
													} else if (otherDetailNodes.item(m).getNodeName()
															.equalsIgnoreCase("Address_Proof")) {
														String text = null;
														if (otherDetailNodes.item(m).getTextContent() != null
																&& !otherDetailNodes.item(m).getTextContent()
																		.equals(NIRConstants.BLANK_STRING)) {
															int num = Integer
																	.valueOf(otherDetailNodes.item(m).getTextContent());
															text = (num < 10 ? "0" : "") + num;
														} else {
															text = otherDetailNodes.item(m).getTextContent();
														}
														accountOpeningFormBean.getProposalDetailBeanList().get(index)
																.setPermanentAddressProof(text);
													} else if (otherDetailNodes.item(m).getNodeName()
															.equalsIgnoreCase("Correspondence_Address_Proof")) {
														String text = null;
														if (otherDetailNodes.item(m).getTextContent() != null
																&& !otherDetailNodes.item(m).getTextContent()
																		.equals(NIRConstants.BLANK_STRING)) {
															int num = Integer
																	.valueOf(otherDetailNodes.item(m).getTextContent());
															text = (num < 10 ? "0" : "") + num;
														} else {
															text = otherDetailNodes.item(m).getTextContent();
														}
														accountOpeningFormBean.getProposalDetailBeanList().get(index)
																.setCorrespondenceAddressProof(text);
													} else if (otherDetailNodes.item(m).getNodeName()
															.equalsIgnoreCase("DOB_Proof")) {
														String text = null;
														if (otherDetailNodes.item(m).getTextContent() != null
																&& !otherDetailNodes.item(m).getTextContent()
																		.equals(NIRConstants.BLANK_STRING)) {
															int num = Integer
																	.valueOf(otherDetailNodes.item(m).getTextContent());
															text = (num < 10 ? "0" : "") + num;
														} else {
															text = otherDetailNodes.item(m).getTextContent();
														}
														accountOpeningFormBean.getProposalDetailBeanList().get(index)
																.setDateOfBirthProof(text);
													}
												}
											}
										}
									}
									/*---------------------------end of new changes--------------------------------*/
								}
							}
						}
					}
					/*
					 * else if (accountOpeningFormBeanNodes.item(i).getNodeName().equalsIgnoreCase(
					 * "Bank_Details")) { setBankDetails(accountOpeningFormBeanNodes.item(i),
					 * accountOpeningFormBean); } else if
					 * (accountOpeningFormBeanNodes.item(i).getNodeName().equalsIgnoreCase(
					 * "Authorized_Representative")) {
					 * setProposalDetailBean(accountOpeningFormBeanNodes.item(i), true,
					 * accountOpeningFormBean); }
					 */
					/*
					 * else if
					 * (Person_eIA_DetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase(
					 * "Other_Detail")) {
					 * person_eIA_DetailBean.setOther_Details(setOtherDetailsBean(
					 * Person_eIA_DetailBeanChildNode.item(i))); }
					 */
				}
			}
		}
		return accountOpeningFormBean;
	}

	public void setProposalDetailBean(Node node, boolean isAuthRepresentative,
			AccountOpeningFormBean accountOpeningFormBean) {
		int index = 0;
		if (isAuthRepresentative) {
			// LOGGER.info("<------------Starting data setting for Authorised
			// Representative------------------>");
			index = 2;
		}
		NodeList personDetailBeanChildNode = node.getChildNodes();
		if (personDetailBeanChildNode.getLength() > 0) {
			for (int i = 0; i < personDetailBeanChildNode.getLength(); i++) {
				// LOGGER.info("Proposal Detail Node Name
				// ------>"+personDetailBeanChildNode.item(i).getNodeName());
				if (!personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("#text")) {
					if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("First_Name")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setFirstNameOfCustomer(personDetailBeanChildNode.item(i).getTextContent());
					} else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("Middle_Name")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setMiddleNameOfCustomer(personDetailBeanChildNode.item(i).getTextContent());
					}
					if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("Last_Name")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setLastNameOfCustomer(personDetailBeanChildNode.item(i).getTextContent());
					} else if (personDetailBeanChildNode.item(i).getNodeName()
							.equalsIgnoreCase("Father_Husband_Name")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setFatherOrHusbandFirstName(personDetailBeanChildNode.item(i).getTextContent());
					} else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("Gender")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setGender(personDetailBeanChildNode.item(i).getTextContent());
					} else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("DOB")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setDateOfBirth(personDetailBeanChildNode.item(i).getTextContent());
					} else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("PAN")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setPan(personDetailBeanChildNode.item(i).getTextContent());
					} else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("UID")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setUid(personDetailBeanChildNode.item(i).getTextContent());
					}
					/* Start change add POI 18-05-2016 */
					else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("POI")) {
						accountOpeningFormBean.getProposalDetailBeanList().get(index)
								.setPoi(personDetailBeanChildNode.item(i).getTextContent());
					}
					/* End change add POI 18-05-2016 */
					else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("Address")) {
						NodeList addressNode = personDetailBeanChildNode.item(i).getChildNodes();
						if (addressNode.getLength() > 0) {
							String valueString = null;
							NamedNodeMap attrs = personDetailBeanChildNode.item(i).getAttributes();
							for (int t = 0; t < attrs.getLength(); t++) {
								Attr attribute = (Attr) attrs.item(t);
								/*
								 * LOGGER.info("Attributes --->"+attribute); String name =
								 * attribute.getName().toLowerCase().toString();
								 * LOGGER.info("Attribute Name------->"+name);
								 */
								valueString = attribute.getValue().toString();
								// LOGGER.info("Attribute Value String------->"+valueString);
							}
							if (valueString != null && valueString.toLowerCase().equalsIgnoreCase("Permanent")) {
								for (int j = 0; j < addressNode.getLength(); j++) {
									// LOGGER.info("Permanent Address Detail Node Name
									// ------>"+addressNode.item(j).getNodeName());
									if (!addressNode.item(j).getNodeName().equalsIgnoreCase("#text")) {
										if (addressNode.item(j).getNodeName().equalsIgnoreCase("AddLine1")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentAddress1(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("AddLine2")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentAddress2(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("AddLine3")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentAddress3(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("Land_Mark")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentAddress4(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("City")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentAddress5(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("Country")) {
											String text = null;
											if (addressNode.item(j).getTextContent() != null && !addressNode.item(j)
													.getTextContent().trim().equals(NIRConstants.BLANK_STRING)) {
												int num = Integer.valueOf(addressNode.item(j).getTextContent());
												// Bug 4804
												// text = (num < 10 ? "0" : "") + num;
												// 13012016 Start
												// text = (num < 10 ? "0" : String.valueOf(num)) ;
												text = String.valueOf(num);
												// 13012016 End

											} else {
												text = addressNode.item(j).getTextContent();
											}
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentCountry(text);
										} else if (addressNode.item(j).getNodeName()
												.equalsIgnoreCase("Country_Other")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentCountry(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("State")) {
											String text = null;
											try {
												if (addressNode.item(j).getTextContent() != null && !addressNode.item(j)
														.getTextContent().trim().equalsIgnoreCase("")) {
													int num = Integer.valueOf(addressNode.item(j).getTextContent());
													text = (num < 10 ? "0" : "") + num;
												} else {
													text = addressNode.item(j).getTextContent();
												}
											} catch (Exception e) {
												LOGGER.warn("Exception in converting Permanent State Code :"
														+ e.getMessage());
												text = addressNode.item(j).getTextContent();
											}
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentStateDD(text);
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("PIN_Code")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setPermanentPinCode(addressNode.item(j).getTextContent());
										}
									}
								}
							}
							if (valueString != null && valueString.toLowerCase().equalsIgnoreCase("Correspondence")) {
								for (int j = 0; j < addressNode.getLength(); j++) {
									// LOGGER.info("Correspondence Address Detail Node Name
									// ------>"+addressNode.item(j).getNodeName());
									if (!addressNode.item(j).getNodeName().equalsIgnoreCase("#text")) {
										if (addressNode.item(j).getNodeName().equalsIgnoreCase("AddLine1")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondenceAddress1(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("AddLine2")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondenceAddress2(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("AddLine3")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondenceAddress3(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("Land_Mark")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondenceAddress4(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("City")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondenceAddress5(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("State")) {
											String text = null;
											try {
												if (addressNode.item(j).getTextContent() != null && !addressNode.item(j)
														.getTextContent().trim().equalsIgnoreCase("")) {
													int num = Integer.valueOf(addressNode.item(j).getTextContent());
													text = (num < 10 ? "0" : "") + num;
												} else {
													text = addressNode.item(j).getTextContent();
												}
											} catch (Exception e) {
												LOGGER.debug("Exception in converting Correspondence State Code :"
														+ e.getMessage());
												text = addressNode.item(j).getTextContent();
											}
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondenceStateDD(text);
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("Country")) {
											String text = null;
											if (addressNode.item(j).getTextContent() != null && !addressNode.item(j)
													.getTextContent().equals(NIRConstants.BLANK_STRING)) {
												int num = Integer.valueOf(addressNode.item(j).getTextContent());
												// Bug 4804
												// text = (num < 10 ? "0" : "") + num;
												// 13012016 Start
												// text = (num < 10 ? "0" : String.valueOf(num)) ;
												text = String.valueOf(num);
												// 13012016 End
											} else {
												text = addressNode.item(j).getTextContent();
											}
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondenceCountry(text);
										} else if (addressNode.item(j).getNodeName()
												.equalsIgnoreCase("Country_Other")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondenceCountry(addressNode.item(j).getTextContent());
										} else if (addressNode.item(j).getNodeName().equalsIgnoreCase("PIN_Code")) {
											accountOpeningFormBean.getProposalDetailBeanList().get(index)
													.setCorrespondencePinCode(addressNode.item(j).getTextContent());
										}
									}
								}
							}
						}
					} else if (personDetailBeanChildNode.item(i).getNodeName()
							.equalsIgnoreCase("Communication_Detail")) {
						NodeList communicationDetailNodes = personDetailBeanChildNode.item(i).getChildNodes();
						if (communicationDetailNodes.getLength() > 0) {
							for (int k = 0; k < communicationDetailNodes.getLength(); k++) {
								// LOGGER.info("Communication Detail Node Name
								// ------>"+communicationDetailNodes.item(k).getNodeName());
								if (!communicationDetailNodes.item(k).getNodeName().equalsIgnoreCase("#text")) {
									if (communicationDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Telephone_Number")) {
										accountOpeningFormBean.getProposalDetailBeanList().get(index)
												.setTelephoneNo(communicationDetailNodes.item(k).getTextContent());
									} else if (communicationDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Alt_Telephone_Number")) {
										accountOpeningFormBean.getProposalDetailBeanList().get(index)
												.setTelephoneNoAlt(communicationDetailNodes.item(k).getTextContent());
									} else if (communicationDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Mob_Number")) {
										accountOpeningFormBean.getProposalDetailBeanList().get(index)
												.setMobileNo(communicationDetailNodes.item(k).getTextContent());
									} else if (communicationDetailNodes.item(k).getNodeName().equalsIgnoreCase("FAX")) {
										accountOpeningFormBean.getProposalDetailBeanList().get(index)
												.setFaxNo(communicationDetailNodes.item(k).getTextContent());
									} else if (communicationDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Primary_email")) {
										accountOpeningFormBean.getProposalDetailBeanList().get(index)
												.setEmailId(communicationDetailNodes.item(k).getTextContent());
									} else if (communicationDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Alternate_email")) {
										accountOpeningFormBean.getProposalDetailBeanList().get(index)
												.setEmailIdAlt(communicationDetailNodes.item(k).getTextContent());
									} else if (communicationDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Relationship")) {
										String text = null;
										if (communicationDetailNodes.item(k).getTextContent() != null
												&& !communicationDetailNodes.item(k).getTextContent()
														.equals(NIRConstants.BLANK_STRING)) {
											int num = Integer
													.valueOf(communicationDetailNodes.item(k).getTextContent());
											text = (num < 10 ? "0" : "") + num;
										} else {
											text = communicationDetailNodes.item(k).getTextContent();
										}
										accountOpeningFormBean.getProposalDetailBeanList().get(index)
												.setRelationshipProof(text);
									} else if (communicationDetailNodes.item(k).getNodeName()
											.equalsIgnoreCase("Relationship_Other")) {
										accountOpeningFormBean.getProposalDetailBeanList().get(index)
												.setRelationshipProofOthers(
														communicationDetailNodes.item(k).getTextContent());
									}
								}
							}
						}
					} else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase("Communication_Flag")) {
						accountOpeningFormBean.setSentMailToAuth(personDetailBeanChildNode.item(i).getTextContent());
					}
					/*
					 * else if (personDetailBeanChildNode.item(i).getNodeName().equalsIgnoreCase(
					 * "Other_Detail")) { NodeList otherDetailNodes =
					 * personDetailBeanChildNode.item(i).getChildNodes(); if
					 * (otherDetailNodes.getLength() > 0) { for (int m = 0; m <
					 * otherDetailNodes.getLength(); m++) { if
					 * (!otherDetailNodes.item(m).getNodeName().equalsIgnoreCase("#text")) { if
					 * (otherDetailNodes.item(m).getNodeName().equalsIgnoreCase("ID_Proof")) {
					 * String text = null; if (otherDetailNodes.item(m).getTextContent() != null &&
					 * !otherDetailNodes.item(m).getTextContent().equals(NIRConstants.BLANK_STRING))
					 * { int num = Integer.valueOf(otherDetailNodes.item(m).getTextContent()); text
					 * = (num < 10 ? "0" : "") + num; } else { text =
					 * otherDetailNodes.item(m).getTextContent(); }
					 * accountOpeningFormBean.getProposalDetailBeanList().get(index).setIdProof(text
					 * ); } else if
					 * (otherDetailNodes.item(m).getNodeName().equalsIgnoreCase("Address_Proof")) {
					 * String text = null; if (otherDetailNodes.item(m).getTextContent() != null &&
					 * !otherDetailNodes.item(m).getTextContent().equals(NIRConstants.BLANK_STRING))
					 * { int num = Integer.valueOf(otherDetailNodes.item(m).getTextContent()); text
					 * = (num < 10 ? "0" : "") + num; } else { text =
					 * otherDetailNodes.item(m).getTextContent(); }
					 * accountOpeningFormBean.getProposalDetailBeanList().get(index).
					 * setPermanentAddressProof(text); } else if
					 * (otherDetailNodes.item(m).getNodeName().equalsIgnoreCase(
					 * "Correspondence_Address_Proof")) { String text = null; if
					 * (otherDetailNodes.item(m).getTextContent() != null &&
					 * !otherDetailNodes.item(m).getTextContent().equals(NIRConstants.BLANK_STRING))
					 * { int num = Integer.valueOf(otherDetailNodes.item(m).getTextContent()); text
					 * = (num < 10 ? "0" : "") + num; } else { text =
					 * otherDetailNodes.item(m).getTextContent(); }
					 * accountOpeningFormBean.getProposalDetailBeanList().get(index).
					 * setCorrespondenceAddressProof(text); } else if
					 * (otherDetailNodes.item(m).getNodeName().equalsIgnoreCase("DOB_Proof")) {
					 * String text = null; if (otherDetailNodes.item(m).getTextContent() != null &&
					 * !otherDetailNodes.item(m).getTextContent().equals(NIRConstants.BLANK_STRING))
					 * { int num = Integer.valueOf(otherDetailNodes.item(m).getTextContent()); text
					 * = (num < 10 ? "0" : "") + num; } else { text =
					 * otherDetailNodes.item(m).getTextContent(); }
					 * accountOpeningFormBean.getProposalDetailBeanList().get(index).
					 * setDateOfBirthProof(text); } } } } }
					 */
				}
			}
		}
	}

	public static AccountOpeningFormBean setBankDetails(Node node, AccountOpeningFormBean accountOpeningFormBean) {
		NodeList bankDetailNodes = node.getChildNodes();
		if (bankDetailNodes.getLength() > 0) {
			for (int i = 0; i < bankDetailNodes.getLength(); i++) {
				if (!bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("#text")) {
					if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("Bank_Name")) {
						String text = null;
						if (bankDetailNodes.item(i).getTextContent() != null
								&& !bankDetailNodes.item(i).getTextContent().equals(NIRConstants.BLANK_STRING)) {
							int num = Integer.valueOf(bankDetailNodes.item(i).getTextContent());
							text = (num < 10 ? "0" : "") + num;
						} else {
							text = bankDetailNodes.item(i).getTextContent();
						}
						accountOpeningFormBean.setBankName(text);
					} else if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("Other_Bank_Name")) {
						accountOpeningFormBean.setBankNameOthers(bankDetailNodes.item(i).getTextContent());
					} else if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("Branch")) {
						accountOpeningFormBean.setBankAddress1(bankDetailNodes.item(i).getTextContent());
					} else if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("City")) {
						accountOpeningFormBean.setBankAddress2(bankDetailNodes.item(i).getTextContent());
					} else if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("Bank_Account_Type")) {
						String text = null;
						if (bankDetailNodes.item(i).getTextContent() != null
								&& !bankDetailNodes.item(i).getTextContent().equals(NIRConstants.BLANK_STRING)) {
							int num = Integer.valueOf(bankDetailNodes.item(i).getTextContent());
							text = (num < 10 ? "0" : "") + num;
						} else {
							text = bankDetailNodes.item(i).getTextContent();
						}
						accountOpeningFormBean.setBankAccountType(text);
					} else if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("Bank_Account_Number")) {
						accountOpeningFormBean.setBankAccountNo(bankDetailNodes.item(i).getTextContent());
					} else if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("Bank_MICR_Code")) {
						accountOpeningFormBean.setBankMICRCode(bankDetailNodes.item(i).getTextContent());
					} else if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("Bank_IFSC_Code")) {
						accountOpeningFormBean.setBankIFSCCode(bankDetailNodes.item(i).getTextContent());
					} else if (bankDetailNodes.item(i).getNodeName().equalsIgnoreCase("Cancelled_Cheque")) {
						accountOpeningFormBean.setBankCancelChk(bankDetailNodes.item(i).getTextContent());
					}
				}
			}
		}
		return accountOpeningFormBean;
	}

	static String nodeType(int type) {
		switch (type) {
		case ELEMENT_NODE:
			return "Element";
		case DOCUMENT_TYPE_NODE:
			return "Document type";
		case ENTITY_NODE:
			return "Entity";
		case ENTITY_REFERENCE_NODE:
			return "Entity reference";
		case NOTATION_NODE:
			return "Notation";
		case TEXT_NODE:
			return "Text";
		case COMMENT_NODE:
			return "Comment";
		case CDATA_SECTION_NODE:
			return "CDATA Section";
		case ATTRIBUTE_NODE:
			return "Attribute";
		case PROCESSING_INSTRUCTION_NODE:
			return "Attribute";
		}
		return "Unidentified";
	}
}