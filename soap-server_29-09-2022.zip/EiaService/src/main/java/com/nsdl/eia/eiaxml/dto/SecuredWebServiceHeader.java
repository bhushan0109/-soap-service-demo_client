package com.nsdl.eia.eiaxml.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "SecuredWebServiceHeader")
public class SecuredWebServiceHeader {

	@XmlElement(required = true)
	protected String UserID;

	@XmlElement(required = true)
	protected String Password;
	@XmlElement(required = true)
	protected String AuthenticatedToken;

	@XmlElement(required = true)
	protected String BussinessPartnerId;

	@XmlElement(required = true)
	protected String RequestReferenceNumber;

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getAuthenticatedToken() {
		return AuthenticatedToken;
	}

	public void setAuthenticatedToken(String authenticatedToken) {
		AuthenticatedToken = authenticatedToken;
	}

	public String getBussinessPartnerId() {
		return BussinessPartnerId;
	}

	public void setBussinessPartnerId(String bussinessPartnerId) {
		BussinessPartnerId = bussinessPartnerId;
	}

	public String getRequestReferenceNumber() {
		return RequestReferenceNumber;
	}

	public void setRequestReferenceNumber(String requestReferenceNumber) {
		RequestReferenceNumber = requestReferenceNumber;
	}

	@Override
	public String toString() {
		return "SecuredWebServiceHeader [UserID=" + UserID + ", Password=" + Password + ", AuthenticatedToken="
				+ AuthenticatedToken + ", BussinessPartnerId=" + BussinessPartnerId + ", RequestReferenceNumber="
				+ RequestReferenceNumber + "]";
	}

}
