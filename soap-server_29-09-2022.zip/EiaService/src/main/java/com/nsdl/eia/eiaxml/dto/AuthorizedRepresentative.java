package com.nsdl.eia.eiaxml.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AuthorizedRepresentative {
	private String firstName;
    private String middleName;
    private String uID;
    private Address address;
    private CommunicationDetail communicationDetail;
    private String lastName;
    private String dOB;
    private String gender;
    private String pAN;
    private String communicationFlag;
}
