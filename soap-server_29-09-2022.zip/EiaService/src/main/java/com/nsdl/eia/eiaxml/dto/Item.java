package com.nsdl.eia.eiaxml.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Item {
	 private String date;
	    private String mode;
	    private String unit;
	    private String current;
	    private String interactive;
}
