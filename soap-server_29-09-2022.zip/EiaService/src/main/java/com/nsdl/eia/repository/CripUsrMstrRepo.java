package com.nsdl.eia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nsdl.eia.entity.CripUsrMstr;
import com.nsdl.eia.otherentity.CripSysParam;

public interface CripUsrMstrRepo extends JpaRepository<CripUsrMstr, Long> {

	@Query(value = "SELECT count(*) FROM nir_security.CRIP_USR_MSTR WHERE cum_login_id=:cumLoginId", nativeQuery = true)
	long isUserIdPresent(@Param("cumLoginId") String cumLoginId);
}
