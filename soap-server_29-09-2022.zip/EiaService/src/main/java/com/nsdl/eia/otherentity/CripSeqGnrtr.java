package com.nsdl.eia.otherentity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name = "NIR.CRIP_SEQ_GNRTR")
public class CripSeqGnrtr implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CSG_GEN_KEY")
	private String csgGenKey;

	@Column(name = "CSG_GEN_VALUE")
	private String csgGenValue;

	@Column(name = "CSG_VALUE_LEN")
	private long csgValueLen;

	public CripSeqGnrtr() {
		super();
	}

}