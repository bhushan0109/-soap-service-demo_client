# soap-service-demo
soap web-service-demo-spring boot server

date=18/09/2022

approach to devlop soap(simple object access protocol) ws\
1) contract fist
wsdl-> java
2) contract last
java-> wsdl(Web Services Description Language)

we are using contact first approch
we did not write WSDL in spring boot 
we need to write xsd(XML Schema Definition) file
==============================================================================
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-web-services</artifactId>
</dependency>

<dependency>
		<groupId>wsdl4j</groupId>
		<artifactId>wsdl4j</artifactId>
</dependency>
=============================================================================
we need to write xsd(XML Schema Definition) file
src/main/resources
and create 
new-other-xml- schema file
and give the file name 
getEIA.xsd


it will auto generated
<?xml version="1.0" encoding="UTF-8"?>
<schema xmlns="http://www.w3.org/2001/XMLSchema"
	targetNamespace="http://www.example.org/NewXMLSchema"
	xmlns:tns="http://www.example.org/NewXMLSchema"
	elementFormDefault="qualified">
</schema>


write your input request object and output request object in xsd file

for generating binding classes we need to add one plugin -xjc plugin

============================================================================================
	<plugin>
				<groupId>org.springframework.boot</groupId>
				<artifactId>spring-boot-maven-plugin</artifactId>
			</plugin>
			<plugin>
				<groupId>org.codehaus.mojo</groupId>
				<artifactId>jaxb2-maven-plugin</artifactId>
				<version>1.6</version>
				<executions>
					<execution>
						<id>xjc</id>
						<goals>
							<goal>xjc</goal>
						</goals>
					</execution>
				</executions>
				<configuration>
					<schemaDirectory>${project.basedir}/src/main/resources/</schemaDirectory>
					<outputDirectory>${project.basedir}/src/main/java</outputDirectory>
					<clearOutputDir>false</clearOutputDir>
				</configuration>
			</plugin>
===============================================================================

mavn clean and maven install
.setting folder delete if error
auto all java object will created after maven install

new create  endpoint packege and service and config
now write own implementaion
in service class
next service endpoint


now next final step config
we only writing xsd file now for generation wsdl file do some config
java base config file


then last run the project
and hit the url
check wsdl generated or not
http://localhost:8080/insta-eia-service/ws/loanEligibility.wsdl
url-servlet path-bean name .wsdl

now if ALL IS OK THEN  TEST SOAP UI tool for testing
copy the url
http://localhost:8082/ws/UnieIA.wsdl
click on soap- give the any project name
and paste the url
![image](https://user-images.githubusercontent.com/75246941/190923037-514239dd-9bb7-4000-be23-07f6cd5d880b.png)


![image](https://user-images.githubusercontent.com/75246941/190922938-5122169c-cea8-4574-9162-bdfa696e7620.png)


https://base64.guru/converter/decode/file
https://base64.guru/converter/encode/file


http://localhost:8082/ws/UnieIA.wsdl
http://172.19.83.45:8082/ws/UnieIA.wsdl
http://172.19.83.45:8080/ws/UnieIA.wsdl
http://localhost:8082/insta-eia-service/ws/UnieIA.wsdl


=====================================local host===================================================
 ==>spring boot
http://localhost:8082/ws/UnieIA.wsdl
http://localhost:8082/insta-eia-service/ws/UnieIA.wsdl  => tomcat
https://10.250.10.51/insta-eia-service/ws/UnieIA.wsdl

uat:
https://10.250.10.212/NIR/loginInitial.html
regretion
=============================================================================
https://10.250.10.51/insta-eia-service/
http://localhost:8082/ws/UnieIA.wsdl
https://10.250.10.51/insta-eia-service/ws/UnieIA.wsdl
https://pilot.nironline.ndml.in/insta-eia-service/ws/UnieIA.wsdl
https://pilot.nironline.ndml.in/insta-eia-service/ws/


http://localhost:8082/ws/
https://10.250.10.51/insta-eia-service/ws
https://pilot.nironline.ndml.in/insta-eia-service/ws/

InstaDataExchange

http://localhost:8082/ws/InstaDataExchange.wsdl
https://10.250.10.51/insta-eia-service/ws
https://10.250.10.51/insta-eia-service/ws/InstaDataExchange.wsdl
http://localhost:8082/ws/InstaDataExchange.wsdl


Mon Nov 21 15:09:24 IST 2022: DEBUG: http-outgoing >> 
POST /insta-eia-service/ws HTTP/1.1
Accept-Encoding: gzip,deflate
Content-Type: text/xml;charset=UTF-8
SOAPAction: "http://tempuri.org/EiaRequest"
Content-Length: 1836
Host: localhost:8080
Connection: Keep-Alive
User-Agent: Apache-HttpClient/4.5.5 (Java/16.0.1)

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
   <soapenv:Header>
      <tem:SecuredWebServiceHeader>
         <!--Optional:-->
         <tem:Username>iTrex123==</tem:Username>
         <!--Optional:-->
         <tem:Password>bithrexdg==</tem:Password>
         <!--Optional:-->
         <tem:AuthenticatedToken/>
      </tem:SecuredWebServiceHeader>
   </soapenv:Header>
   <soapenv:Body>
      <tem:EiaRequest>
         <!--Optional:-->
         <tem:TRID>6666666666</tem:TRID>
         <!--Optional:-->
         <tem:eIANo>3000000000001</tem:eIANo>
         <!--Optional:-->
         <tem:FileContent>UEsDBBQAAAAIAP2zX1WBCUTIjgIAAA0HAAANAAAAbmV3IGluc3RhLnhtbIVVXW+bMBR9n7T/gPK+GpKSEsl1R2FtUAmgNqm6vVgE3NYS2MiQqvn3M4QScMjGk+85x/fD9r3Am8880z6IKCln1xPjQp9ohCU8pezterJZ3/2wJjfo+zdIPBvbSYJdUsU0KyWkaRq8oxnBSxKnRByQDqQpuoTga9lxblwRHL7ie8KIiCvKGZrqhmkYMx2CEbLbGOzymlLTMCA4wxwSBCcZwkgWy1mjP2iPQSQ22N7C0q0jU3vjYl8H7Jt92XpfkPBVsrXoaAw8FUXAkTGdXZrzK8uE4AD0JR4rdyJmCcFOXrA9dlJkyLMZgdtdssiRvOtQGU1iVqlVDkgtiHNyPXniGZFHJcpKiwQveEnEpL+h3tPQuNajJ0EZ/YhLCHqgIl/RNM1IQ2lAJf24c0WqdwrBEVCjxtU7EXi5K7cxS8+4kw+mvt8VBO1K4d3wFhkLy5DfFILaUgSRHaDblR1F5sKY30JQ24pk47mngZOH3w56aT4IGkN1HJdlwUWFXtpLh6CDjtJG6vqn/p95RcRYYDtNBSnL9vocLqRVcFm7fCHqzbV6nzJioMB7tJ/t9XIT2Y/2KvJ8CDru7LYpegh9O/C0SAs7/fS8foaefwX3tu+H4WOnn43oHVrt0XoZupto82dpQ9AAp7qnSjYcmsnLO6xGPPEdq+r+1GXzfRmnssgLsMNTguaWOdctCDpAOWDQnrCKOzzPd4wmzXjqtZYSZ8W3WA6mrXyL1uLKtBbGdCET68EjuQmax2KPSV773L7vChkk03Xd+PlWQxcJzyEYqtSs/5ceBF3rD+Cw6bLRcqDnYjkU+Gs91rq1ohm+QNweXqs1Ifgnf9qtx4BHY1DFaL694gYUBGMzvxmbg1/GX1BLAQIfABQAAAAIAP2zX1WBCUTIjgIAAA0HAAANACQAAAAAAAAAIAAAAAAAAABuZXcgaW5zdGEueG1sCgAgAAAAAAABABgA6g7pfErt2AGfYkyIzOrYAZ9iTIjM6tgBUEsFBgAAAAABAAEAXwAAALkCAAAAAA==</tem:FileContent>
      </tem:EiaRequest>
   </soapenv:Body>
</soapenv:Envelope>

Mon Nov 21 15:09:25 IST 2022: DEBUG: http-incoming << 
HTTP/1.1 200 
Accept: text/xml, text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2
SOAPAction: ""
Content-Type: text/xml;charset=utf-8
Content-Length: 325
Date: Mon, 21 Nov 2022 09:39:25 GMT
Keep-Alive: timeout=20
Connection: keep-alive

<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/"><SOAP-ENV:Header/><SOAP-ENV:Body><ns2:EiaResponse xmlns:ns2="http://tempuri.org/"><ns2:TRID>6666666666</ns2:TRID><ns2:STATUS>E</ns2:STATUS><ns2:ERROR_DESC>Technical Issue Found</ns2:ERROR_DESC></ns2:EiaResponse></SOAP-ENV:Body></SOAP-ENV:Envelope>

https://10.250.10.51/insta-eia-service/ws/UnieIA.wsdl
http://172.19.83.45:8082/insta-eia-service/ws/UnieIA.wsdl
http://172.19.83.45:8082/insta-eia-service/ws/UniInstaDataExchange.wsdl

LOCALHOST:
http://localhost:8083/insta-eia-service/ws/UnieIA.wsdl 
http://localhost:8082/insta-eia-service/ws/getEIA.wsdl
http://localhost:8082/insta-eia-service/ws/test.wsdl

REG:
https://121.242.223.217/insta-eia-service/ws/UnieIA.wsdl
https://pilot.nironline.ndml.in/insta-eia-service/ws/UnieIA.wsdl used
https://pilot.nironline.ndml.in/insta-eia-service/ws/getEIA.wsdl



LOCALHOST:
http://localhost:8082/insta-eia-service/ws/UniInstaDataExchange.wsdl 
https://pilot.nironline.ndml.in/insta-eia-service/ws/UniInstaDataExchange.wsdl




https://aswinprasanthblog.wordpress.com/2016/03/21/how-to-send-a-filebase64binary-in-web-service-request-using-soap-ui/
