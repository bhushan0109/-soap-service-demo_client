package org.tempuri.config;


import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.ws.WebServiceMessageFactory;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.soap.SoapVersion;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.DefaultWsdl11Definition;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;
import org.springframework.ws.wsdl.wsdl11.Wsdl11Definition;
import org.springframework.xml.xsd.SimpleXsdSchema;
import org.springframework.xml.xsd.XsdSchema;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Configuration
@EnableWs
public class SoapWSConfig extends WsConfigurerAdapter {
	private static Logger logger = LogManager.getLogger(SoapWSConfig.class);

	@Bean
	public ServletRegistrationBean<MessageDispatcherServlet> messageDispatcherServlet(ApplicationContext context) {
		MessageDispatcherServlet servlet = new MessageDispatcherServlet();
		servlet.setApplicationContext(context);
		servlet.setTransformWsdlLocations(true);
		return new ServletRegistrationBean<MessageDispatcherServlet>(servlet, "/ws/*");
	}

	// Note: no used xsd only used wdsl bean currently [this bean not used]
	@Bean(name = "getEIA") // any name we can give
	public DefaultWsdl11Definition defaultWsdl11Definition3(XsdSchema schema3) {
		DefaultWsdl11Definition defaultWsdl11Definition = new DefaultWsdl11Definition();

		defaultWsdl11Definition.setPortTypeName("getEIA"); // any name we can give
		defaultWsdl11Definition.setLocationUri("/ws"); // same url we provide which mapped to servlet
		defaultWsdl11Definition.setTargetNamespace("http://tempuri.org/"); // target name url which is on xsd
		defaultWsdl11Definition.setSchema(schema3);
		// defaultWsdl11Definition.setCreateSoap12Binding(true);
		defaultWsdl11Definition.setCreateSoap11Binding(true);

		// defaultWsdl11Definition.setRequestSuffix("Request");
		// defaultWsdl11Definition.setResponseSuffix("Response");
		// wsdl11Definition.setFaultSuffix("commonFault");
		return defaultWsdl11Definition;

	}

	// no used only for java xml tag base generation
	@Bean
	public XsdSchema schema3() {
		return new SimpleXsdSchema(new ClassPathResource("getEIA.xsd"));
	}

	@Bean
	WebServiceMessageFactory messageFactory() {
		SaajSoapMessageFactory messageFactory = new SaajSoapMessageFactory();
		messageFactory.setSoapVersion(SoapVersion.SOAP_11);

		// messageFactory.setSoapVersion(SoapVersion.SOAP_11);
		logger.info("SoapVersion ==>" + SoapVersion.SOAP_11);
		return messageFactory;
	}

	// http in wsdl append by war file
	// http://localhost:8082/insta-eia-service/ws/UnieIA.wsdl
	@Bean(name = "UnieIA")
	public Wsdl11Definition defaultWsdl11Definition() {
		SimpleWsdl11Definition wsdl11Definition = new SimpleWsdl11Definition();
		wsdl11Definition.setWsdl(new ClassPathResource("eia.wsdl"));

		return wsdl11Definition;
	}

	// http://localhost:8082/insta-eia-service/ws/UniInstaDataExchange.wsdl
	@Bean(name = "UniInstaDataExchange")
	public Wsdl11Definition defaultWsdl11Definition6() {
		SimpleWsdl11Definition wsdl11Definition = new SimpleWsdl11Definition();
		wsdl11Definition.setWsdl(new ClassPathResource("instaDataExchange.wsdl"));

		return wsdl11Definition;
	}

	// Note: no used xsd only used wdsl bean currently [this bean not used]
	@Bean(name = "InstaDataExchange") // any name we can give
	public DefaultWsdl11Definition defaultWsdl11Definition4(XsdSchema schema4) {
		DefaultWsdl11Definition defaultWsdl11Definition = new DefaultWsdl11Definition();
		defaultWsdl11Definition.setPortTypeName("InstaDataExchange"); // any name we can give
		defaultWsdl11Definition.setLocationUri("/ws"); // same url we provide which mapped to servlet
		defaultWsdl11Definition.setTargetNamespace("http://tempuri.org/"); // target name url which is on xsd
		defaultWsdl11Definition.setSchema(schema4);
		defaultWsdl11Definition.setCreateSoap11Binding(true);
		return defaultWsdl11Definition;

	}

	// no used only for java xml tag base generation
	@Bean
	public XsdSchema schema4() {
		return new SimpleXsdSchema(new ClassPathResource("InstaDataE.xsd"));
	}

	// @Bean
	// public SaajSoapMessageFactory messageFactory1() {
	// SaajSoapMessageFactory messageFactory = new SaajSoapMessageFactory();
	// messageFactory.setSoapVersion(SoapVersion.SOAP_11);
	// return messageFactory;
	// }

	@Bean
	public RestTemplate restTemplate() throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		HttpComponentsClientHttpRequestFactory customHttpRequestFactory = customHttpRequestFactory();
		RestTemplate restTemplate = new RestTemplate(customHttpRequestFactory);
		return restTemplate;
	}

	@Bean
	@ConfigurationProperties(prefix = "custom.rest.connection")
	public HttpComponentsClientHttpRequestFactory customHttpRequestFactory()
			throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

		SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy)
				.build();

		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);

		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();

		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

		requestFactory.setHttpClient(httpClient);

		return new HttpComponentsClientHttpRequestFactory();
	}
	

}
