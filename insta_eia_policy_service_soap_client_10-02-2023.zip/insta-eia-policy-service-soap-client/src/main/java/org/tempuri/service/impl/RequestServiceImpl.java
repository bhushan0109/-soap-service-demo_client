package org.tempuri.service.impl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.tempuri.service.EiaService;

//@Service
@Component
public class RequestServiceImpl {

	private static Logger logger = LogManager.getLogger(RequestServiceImpl.class);
	@Value("${file.load.path.property}")
	private Path fileLoadPath;

	private final String LOCALHOST_IPV4 = "127.0.0.1";
	private final String LOCALHOST_IPV6 = "0:0:0:0:0:0:0:1";

	public String getClientIp(HttpServletRequest request) {
		logger.info("in getClientIp");
		String ipAddress = request.getHeader("X-Forwarded-For");
		if (StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("Proxy-Client-IP");
		}

		if (StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("WL-Proxy-Client-IP");
		}

		if (StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getRemoteAddr();
			if (LOCALHOST_IPV4.equals(ipAddress) || LOCALHOST_IPV6.equals(ipAddress)) {
				try {
					InetAddress inetAddress = InetAddress.getLocalHost();
					ipAddress = inetAddress.getHostAddress();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
			}
		}

		if (!StringUtils.isEmpty(ipAddress) && ipAddress.length() > 15 && ipAddress.indexOf(",") > 0) {
			ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
		}
		logger.info("exit getClientIp");
		return ipAddress;
	}

	public String getPropertiesValue(String key) {
		logger.info("in getPropertiesValue");

		String value = "";
		Map<String, String> map = new HashMap<>();

		Properties props = new Properties();
		FileInputStream in = null;
		String policyBaseUrl = null;
		String nirBaseUrl = null;
		try {
			// in = new FileInputStream("/app/nir/nir-properties/insta-eia.properties");
			logger.info("URL_fileLoadPath ==> " + fileLoadPath.toString());
			in = new FileInputStream(fileLoadPath.toString());
			props.load(in);
			in.close();
			nirBaseUrl = props.getProperty("nir.base.url");
			policyBaseUrl = props.getProperty("policy.base.url");
		} catch (FileNotFoundException e) {
			logger.info("NIR insta soap WAR : FileNotFoundException for insta-eia.properties");
			e.printStackTrace();
		} catch (IOException e) {
			logger.info("NIR insta soap WAR : IOException for insta-eia.properties");
			e.printStackTrace();
		} finally {
			in = null;
		}

		map.put("nirBaseUrl", nirBaseUrl);
		map.put("policyBaseUrl", policyBaseUrl);

		for (Map.Entry<String, String> entry : map.entrySet()) {
			if (entry.getKey().equalsIgnoreCase(key)) {
				value = (entry.getValue());
			}
		}
		logger.info("return getPropertiesValue ==>" + value);
		logger.info("exit getPropertiesValue");
		return value;
	}

}
