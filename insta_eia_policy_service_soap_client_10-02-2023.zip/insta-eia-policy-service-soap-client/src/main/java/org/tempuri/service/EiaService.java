package org.tempuri.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.tempuri.otherdto.EiaRequest;
import org.tempuri.otherdto.EiaResponse;
import org.tempuri.otherdto.InstaDataExchangeDetailsResponse;
import org.tempuri.otherdto.InstaDataExchangeReq;
import org.tempuri.otherdto.InstaDataExchangeRequest;
import org.tempuri.otherdto.SecuredWebServiceHeader;
import org.tempuri.service.impl.RequestServiceImpl;

@Service
public class EiaService {

	private static Logger logger = LogManager.getLogger(EiaService.class);
	
	@Value("${itrexImageZipFileKBSizeMin}")
	private long itrexImageZipFileKBSizeMin;
	
	@Value("${itrexImageZipFileKBSizeMax}")
	private long itrexImageZipFileKBSizeMax;

	@Autowired
	RestTemplate restTemplate;
	@Autowired
	RequestServiceImpl requestServiceImpl;

	public EiaResponse saveEia(EiaRequest request, SecuredWebServiceHeader securedWebServiceHeader,
			HttpServletRequest req) throws Exception {
		EiaResponse eIAAccDetails = new EiaResponse();
		String TRID = request.getTRID();
		try {
			String eIANo = request.getEIANo().trim();
			String partnerIp = requestServiceImpl.getClientIp(req);
			logger.info("partnerIP ==>" + partnerIp);

			byte[] bytes = request.getFileContent();
			String encodeBase64String = Base64.encodeBase64String(bytes);
			logger.info("soapEncodingString request encoded string==>" + encodeBase64String);
			byte[] zipData = Base64.decodeBase64(encodeBase64String);
			String realvalue = extractZipEntries(zipData);
			if (!realvalue.equalsIgnoreCase("false")) {
				String requestxml = realvalue;
				logger.info("itrex EIA Request xml file=>" + requestxml);
				String uid = securedWebServiceHeader.getUsername();
				String pwd = securedWebServiceHeader.getPassword();
				try {
					String nirBaseUrlValue = requestServiceImpl.getPropertiesValue("nirBaseUrl");
					String eiaApiName = nirBaseUrlValue + "onlineEiaAccountOpeningByPartnerITrex.html";
					logger.info("EIA URL ==>" + eiaApiName);
					String url = eiaApiName + "?requestxml=" + requestxml + "&uid=" + uid + "&pwd=" + pwd + "&TRID="
							+ TRID + "&eIANo=" + eIANo + "&partnerIp=" + partnerIp;
					HttpHeaders httpHeaders = new HttpHeaders();
					httpHeaders.add(HttpHeaders.AUTHORIZATION, "urAccessToken");
					@SuppressWarnings({ "rawtypes", "unchecked" })
					HttpEntity httpEntity = new HttpEntity(httpHeaders);
					ResponseEntity<String> commonResponse = restTemplate.exchange(url, HttpMethod.POST, httpEntity,
							String.class);
					String responsexml = commonResponse.getBody();
					logger.info("End NIR WAR eIAAccDetails response ==>" + commonResponse.getBody());
					JSONObject json = XML.toJSONObject(responsexml); 
					JSONObject jsonObject = json.getJSONObject("EIA_Acc_Details");
					eIAAccDetails.setSTATUS(jsonObject.getString("STATUS"));
					String status = jsonObject.getString("STATUS");
					if (status.equalsIgnoreCase("S")) {
						eIAAccDetails.setTRID(TRID);
					} else {
						eIAAccDetails.setTRID(TRID);
					}
					eIAAccDetails.setERRORDESC(jsonObject.getString("ERROR_DESC"));
				} catch (Exception e) {
					e.printStackTrace();

					eIAAccDetails.setTRID(TRID);
					eIAAccDetails.setSTATUS("E");
					eIAAccDetails.setERRORDESC("Technical Issue Found");
					logger.info("Technical Issue Found while nir war calling");
				}
			} else {

				eIAAccDetails.setTRID("");
				eIAAccDetails.setSTATUS("E");
				eIAAccDetails.setERRORDESC("Only upload .xml in zip File");
			}
		} catch (Exception e) {
			e.printStackTrace();

			eIAAccDetails.setTRID(TRID);
			eIAAccDetails.setSTATUS("E");
			eIAAccDetails.setERRORDESC("Technical Issue Found");
			logger.info("Technical Issue Found in Soap Service");
		}
		logger.info("End FINAL eIAAccDetails response ==>" + eIAAccDetails.toString());
		return eIAAccDetails;

	}

	public InstaDataExchangeDetailsResponse getInstaDataExchange(InstaDataExchangeRequest instaDataExchangeRequest,
			SecuredWebServiceHeader securedWebServiceHeader, HttpServletRequest httpRequest) {
		InstaDataExchangeDetailsResponse instaDataExchangeDetailsResponse = new InstaDataExchangeDetailsResponse();
		InstaDataExchangeReq instaDataExchangeReq = new InstaDataExchangeReq();
		byte[] getImageContentbytes = instaDataExchangeRequest.getImageContent();

		String TRID = instaDataExchangeRequest.getTRID();
		String filePath = instaDataExchangeRequest.getFilePath();
		String fileType = instaDataExchangeRequest.getFileType();
		String partnerIp = requestServiceImpl.getClientIp(httpRequest);
		String uid = securedWebServiceHeader.getUsername();
		String pwd = securedWebServiceHeader.getPassword();
		logger.info("partnerIP ==>" + partnerIp);
		long imagelengthZipbyte = 0;
		if(getImageContentbytes != null) {
		imagelengthZipbyte = getImageContentbytes.length;
		}else {
			
			getImageContentbytes= new byte[0];
		}
		logger.info("imagelengthZip size==>" + imagelengthZipbyte);
		if (imagelengthZipbyte != 0) {
			long imagelengthZipKb = (imagelengthZipbyte / 1024);
			logger.info("imagelengthZipmegabytes kb size is valid==>" + imagelengthZipKb);
		/*	long imagelengthZipmegabytes = (kilobytes / 1024);*/

			if (imagelengthZipKb > itrexImageZipFileKBSizeMin && imagelengthZipKb <= itrexImageZipFileKBSizeMax) {
				logger.info("imagelengthZipmegabytes size is valid==>" + imagelengthZipKb);
			} else {
				logger.info("Document upload size is not valid, upload ImageContent zip size should be min 10 KB and max 5120 KB");
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
				String dateString = sdf.format(new Date());
				instaDataExchangeDetailsResponse.setTRID(TRID);
				instaDataExchangeDetailsResponse.setResponseTimeStamp(dateString);
				instaDataExchangeDetailsResponse.setSTATUS("E");
				instaDataExchangeDetailsResponse.setResult("");
				instaDataExchangeDetailsResponse
						.setERRORDESC("Document upload size is not valid, upload ImageContent zip size should be min 10 KB and max 5120 KB");
				return instaDataExchangeDetailsResponse;
			}
		}
		String encodeBase64Stringimg = Base64.encodeBase64String(getImageContentbytes);
		byte[] zipDataimg = Base64.decodeBase64(encodeBase64Stringimg);
		byte[] bytes = instaDataExchangeRequest.getFileContent();
		String encodeBase64String = Base64.encodeBase64String(bytes);

		logger.info("soapEncodingString request encoded string==>" + encodeBase64String);

		try {
			byte[] zipData = Base64.decodeBase64(encodeBase64String);
			String realvalue = extractZipEntries(zipData);
			if (!realvalue.equalsIgnoreCase("false")) {
				String requestxml = realvalue;
				logger.info("itrex policy Request xml file=>" + requestxml);
				try {
					String policyBaseUrlValue = requestServiceImpl.getPropertiesValue("policyBaseUrl");
					String policyApiname = policyBaseUrlValue + "Creation/";
					logger.info("itrex policyApiName ==>" + policyApiname);
					HttpHeaders requestHeaders = new HttpHeaders();
					requestHeaders.setContentType(MediaType.APPLICATION_JSON);
					instaDataExchangeReq.setTrid(TRID);
					instaDataExchangeReq.setAuthenticatedToken("");
					instaDataExchangeReq.setUsername(uid);
					instaDataExchangeReq.setPassword(pwd);
					instaDataExchangeReq.setFileContent(requestxml);
					instaDataExchangeReq.setImageContent(zipDataimg);
					instaDataExchangeReq.setFileType(fileType);
					instaDataExchangeReq.setFilePath("");
					instaDataExchangeReq.setPartnerIp(partnerIp);
					HttpEntity<InstaDataExchangeReq> requestEntity = new HttpEntity<>(instaDataExchangeReq,
							requestHeaders);
					ResponseEntity<String> commonResponse = restTemplate.exchange(policyApiname, HttpMethod.POST,
							requestEntity, String.class);
					String responsexml = commonResponse.getBody();
					logger.info("End NIR policy Insta_DataExchange_Details response ==>" + commonResponse.getBody());
					JSONObject json = XML.toJSONObject(responsexml);
					JSONObject jsonObject = json.getJSONObject("Insta_DataExchange_Details");
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
					instaDataExchangeDetailsResponse.setSTATUS(jsonObject.getString("status"));
					String status = jsonObject.getString("status");
					if (status.equalsIgnoreCase("S")) {
						instaDataExchangeDetailsResponse.setResult(jsonObject.getString("result"));
					} else {
						instaDataExchangeDetailsResponse.setResult("");
					}
					instaDataExchangeDetailsResponse.setTRID(TRID);
					instaDataExchangeDetailsResponse.setERRORDESC(jsonObject.getString("error_desc"));

					String dateString = sdf.format(new Date());
					instaDataExchangeDetailsResponse.setTRID(TRID);
					instaDataExchangeDetailsResponse.setResponseTimeStamp(dateString);
				} catch (Exception e) {
					e.printStackTrace();
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
					String dateString = sdf.format(new Date());
					instaDataExchangeDetailsResponse.setTRID(TRID);
					instaDataExchangeDetailsResponse.setResponseTimeStamp(dateString);
					instaDataExchangeDetailsResponse.setSTATUS("E");
					instaDataExchangeDetailsResponse.setResult("");
					instaDataExchangeDetailsResponse.setERRORDESC("Technical Issue Found");
					logger.info("Technical Issue Found while policy url called");
				}
			} else {
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
				String dateString = sdf.format(new Date());
				instaDataExchangeDetailsResponse.setTRID(TRID);
				instaDataExchangeDetailsResponse.setResponseTimeStamp(dateString);
				instaDataExchangeDetailsResponse.setSTATUS("E");
				instaDataExchangeDetailsResponse.setResult("");
				instaDataExchangeDetailsResponse.setERRORDESC("Only upload .xml in zip File");
			}
		} catch (Exception e) {
			e.printStackTrace();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
			String dateString = sdf.format(new Date());
			instaDataExchangeDetailsResponse.setTRID(TRID);
			instaDataExchangeDetailsResponse.setResponseTimeStamp(dateString);
			instaDataExchangeDetailsResponse.setSTATUS("E");
			instaDataExchangeDetailsResponse.setResult("");
			instaDataExchangeDetailsResponse.setERRORDESC("Technical Issue Found");
			logger.info("Technical Issue Found in only soap service side");
		}

		logger.info("End FINAL instaDataExchangeDetailsResponse  ==>" + instaDataExchangeDetailsResponse.toString());
		return instaDataExchangeDetailsResponse;

	}

	public String extractZipEntries(byte[] bytes) throws IOException {
		ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(bytes));
		ZipEntry entry = null;
		StringBuilder builder = new StringBuilder();
		while ((entry = zipStream.getNextEntry()) != null) {
			String entryName = entry.getName();
			String s3 = "";
			int index = entryName.lastIndexOf('.');
			if (index > 0) {
				String extension = entryName.substring(index + 1);
				logger.info("File extension is " + extension);
				if (!extension.equalsIgnoreCase("xml")) {
					logger.info("this file is not .xml file" + extension);
					s3 = "false";
					builder.append(s3);
				} else {
					logger.info("entry file name ==>" + entryName);
					byte[] byteBuff = new byte[9096];
					int bytesRead = 0;

					while ((bytesRead = zipStream.read(byteBuff)) != -1) {
						s3 = new String(byteBuff, 0, bytesRead);
						builder.append(s3);
					}
					zipStream.closeEntry();
				}
			}
		}
		zipStream.close();
		return builder.toString();
	}

}