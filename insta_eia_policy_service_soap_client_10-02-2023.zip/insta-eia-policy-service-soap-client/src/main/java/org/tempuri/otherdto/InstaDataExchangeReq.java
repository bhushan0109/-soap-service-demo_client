package org.tempuri.otherdto;

import java.util.Arrays;


public class InstaDataExchangeReq {
	public String trid;
	public String fileType;
	public String fileContent;
	public byte[] imageContent;
	public String filePath;

	public String username;
	public String password;
	public String authenticatedToken;
	public String partnerIp;
	

	public String getPartnerIp() {
		return partnerIp;
	}

	public void setPartnerIp(String partnerIp) {
		this.partnerIp = partnerIp;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAuthenticatedToken() {
		return authenticatedToken;
	}

	public void setAuthenticatedToken(String authenticatedToken) {
		this.authenticatedToken = authenticatedToken;
	}

	public String getTrid() {
		return trid;
	}

	public void setTrid(String trid) {
		this.trid = trid;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getFileContent() {
		return fileContent;
	}

	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}

	public byte[] getImageContent() {
		return imageContent;
	}

	public void setImageContent(byte[] imageContent) {
		this.imageContent = imageContent;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	@Override
	public String toString() {
		return "InstaDataExchangeReq [trid=" + trid + ", fileType=" + fileType + ", fileContent=" + fileContent
				+ ", imageContent=" + Arrays.toString(imageContent) + ", filePath=" + filePath + ", username="
				+ username + ", password=" + password + ", authenticatedToken=" + authenticatedToken + ", partnerIp="
				+ partnerIp + "]";
	}

}
