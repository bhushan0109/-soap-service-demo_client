package org.tempuri.endpoint;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.ws.WebServiceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.transport.context.TransportContext;
import org.springframework.ws.transport.context.TransportContextHolder;
import org.springframework.ws.transport.http.HttpServletConnection;
import org.tempuri.otherdto.EiaRequest;
import org.tempuri.otherdto.EiaResponse;
import org.tempuri.otherdto.InstaDataExchangeDetailsResponse;
import org.tempuri.otherdto.InstaDataExchangeRequest;
import org.tempuri.otherdto.SecuredWebServiceHeader;
import org.tempuri.service.EiaService;
import org.tempuri.service.impl.RequestServiceImpl;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@Endpoint
@CrossOrigin(origins = "*")
public class EiaServiceEndPoint {
	private static Logger logger = LogManager.getLogger(EiaServiceEndPoint.class);
	private static final String NAMESPACE_GET_EIA = "http://tempuri.org/";

	@Autowired
	private EiaService service;

	@javax.annotation.Resource
	WebServiceContext wsContext;

	@Autowired
	RequestServiceImpl requestServiceImpl;

	// http://localhost:8082/ws/UnieIA.wsdl
	// url-servlet path-bean name .wsdl
	@PayloadRoot(namespace = NAMESPACE_GET_EIA, localPart = "EiaRequest")
	@ResponsePayload
	public EiaResponse saveEIA(MessageContext messageContext) throws Exception {
		logger.info("EiaRequest end point called  succesfully");
		EiaResponse eiaResponse = new EiaResponse();
		try {
			TransportContext ctx = TransportContextHolder.getTransportContext();
			HttpServletRequest req = ((HttpServletConnection) ctx.getConnection()).getHttpServletRequest();
			SoapMessage message = (SoapMessage) messageContext.getRequest();
			SoapHeader soapHeader = message.getSoapHeader();
			SoapBody soapBody = message.getSoapBody();
			Source bodySource = soapBody.getPayloadSource();
			DOMSource bodyDomSource = (DOMSource) bodySource;
			// =============================================================
			logger.info("EiaRequest unmarshaller started==>");
			// now xml body object convert to java object using Unmarshaller
			JAXBContext context = JAXBContext.newInstance(EiaRequest.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();

			EiaRequest eiaRequest = (EiaRequest) unmarshaller.unmarshal(bodyDomSource);
			logger.info("EiaRequest unmarshaller end==> " + eiaRequest.toString());
			// =============================================================

			logger.info("securedWebServiceHeader unmarshaller started==>");
			// =============================================================
			Map<String, String> extractUserDefinedHeaders = extractUserDefinedHeaders(soapHeader);
			SecuredWebServiceHeader securedWebServiceHeader = new SecuredWebServiceHeader();
			String Username = extractUserDefinedHeaders.get("Username");
			securedWebServiceHeader.setUsername(Username);
			String Password = extractUserDefinedHeaders.get("Password");
			securedWebServiceHeader.setPassword(Password);
			String AuthenticatedToken = extractUserDefinedHeaders.get("AuthenticatedToken");
			securedWebServiceHeader.setAuthenticatedToken(AuthenticatedToken);
			logger.info("securedWebServiceHeader request==>" + securedWebServiceHeader.toString());
			logger.info("securedWebServiceHeader unmarshaller end==>");
			if (Username != null || Password != null) {

				eiaResponse = service.saveEia(eiaRequest, securedWebServiceHeader, req);
			} else {
				eiaResponse.setTRID(eiaRequest.getTRID());
				eiaResponse.setSTATUS("E");
				eiaResponse.setERRORDESC("Username And Password Should Not Be Empty");
				logger.info("Username And Password Should Not Be Empty");

			}
		} catch (Exception e) {
			e.printStackTrace();
			eiaResponse.setTRID("");
			eiaResponse.setSTATUS("E");
			eiaResponse.setERRORDESC("Technical Issue Found while marshaling");
			logger.info("Technical Issue Found while marshaling");
		}

		return eiaResponse;
	}

	// http://localhost:8082/ws/InstaDataExchange.wsdl
	// url-servlet path-bean name .wsdl
	@PayloadRoot(namespace = NAMESPACE_GET_EIA, localPart = "InstaDataExchangeRequest")
	// ---------------------------------------------- above local part is customer
	// request
	@ResponsePayload
	public InstaDataExchangeDetailsResponse instaDataExchange(MessageContext messageContext) throws Exception {
		InstaDataExchangeDetailsResponse instaDataExchangeDetailsResponse = new InstaDataExchangeDetailsResponse();
		logger.info("InstaDataExchangeRequest end point called  succesfully");
		try {
			TransportContext ctx = TransportContextHolder.getTransportContext();
			HttpServletRequest req = ((HttpServletConnection) ctx.getConnection()).getHttpServletRequest();
			SoapMessage message = (SoapMessage) messageContext.getRequest();
			SoapHeader soapHeader = message.getSoapHeader();
			SoapBody soapBody = message.getSoapBody();
			Source bodySource = soapBody.getPayloadSource();
			DOMSource bodyDomSource = (DOMSource) bodySource;
			// =============================================================

			// now xml body object convert to java object using Unmarshaller
			JAXBContext context = JAXBContext.newInstance(InstaDataExchangeRequest.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();

			InstaDataExchangeRequest instaDataExchangeRequest = (InstaDataExchangeRequest) unmarshaller
					.unmarshal(bodyDomSource);
			logger.info("instaDataExchangeRequest unmarshaller end==> " + instaDataExchangeRequest.toString());
			// =============================================================

			Map<String, String> extractUserDefinedHeaders = extractUserDefinedHeaders(soapHeader);
			SecuredWebServiceHeader securedWebServiceHeader = new SecuredWebServiceHeader();
			String Username = extractUserDefinedHeaders.get("Username");
			securedWebServiceHeader.setUsername(Username);
			String Password = extractUserDefinedHeaders.get("Password");
			securedWebServiceHeader.setPassword(Password);
			String AuthenticatedToken = extractUserDefinedHeaders.get("AuthenticatedToken");
			securedWebServiceHeader.setAuthenticatedToken(AuthenticatedToken);
			logger.info("securedWebServiceHeader request==>" + securedWebServiceHeader);
			if (Username != null || Password != null) {

				instaDataExchangeDetailsResponse = service.getInstaDataExchange(instaDataExchangeRequest,
						securedWebServiceHeader, req);
			} else {
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
				String dateString = sdf.format(new Date());
				instaDataExchangeDetailsResponse.setTRID(instaDataExchangeRequest.getTRID());
				instaDataExchangeDetailsResponse.setResponseTimeStamp(dateString);
				instaDataExchangeDetailsResponse.setSTATUS("E");
				instaDataExchangeDetailsResponse.setResult("");
				instaDataExchangeDetailsResponse.setERRORDESC("Username And Password Should Not Be Empty");
				logger.info("Username And Password Should Not Be Empty");

			}
		} catch (Exception e) {
			e.printStackTrace();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss");
			String dateString = sdf.format(new Date());
			instaDataExchangeDetailsResponse.setTRID("");
			instaDataExchangeDetailsResponse.setResponseTimeStamp(dateString);
			instaDataExchangeDetailsResponse.setSTATUS("E");
			instaDataExchangeDetailsResponse.setResult("");
			instaDataExchangeDetailsResponse.setERRORDESC("Technical Issue Found while marshaling");
			logger.info("Technical Issue Found while marshaling");
		}

		return instaDataExchangeDetailsResponse;
	}

	public Map<String, String> extractUserDefinedHeaders(SoapHeader soapHeader) {
		Map<String, String> headers = new HashMap<String, String>();

		Iterator<?> elementIter = soapHeader.examineAllHeaderElements();
		while (elementIter.hasNext()) {
			Object element = elementIter.next();
			if (!(element instanceof SoapHeaderElement)) {
				continue;
			}
			javax.xml.transform.Result result = ((SoapHeaderElement) element).getResult();
			// Result result = ((SoapHeaderElement) element).getResult();
			if (!(result instanceof DOMResult)) {
				continue;
			}

			NodeList nodeList = ((DOMResult) result).getNode().getChildNodes();
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				String nodeName = null;
				if (node.hasChildNodes()) {
					String[] split = node.getNodeName().split(":");
					if (split.length > 0) {
						nodeName = split[split.length - 1];
					} else {
						nodeName = split[0];
					}
					String nodeValue = node.getFirstChild().getNodeValue();
					headers.put(nodeName, nodeValue);
				}
			}
		}
		return headers;

	}

}