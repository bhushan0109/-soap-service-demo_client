package com.ndml;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@Component
@XmlRootElement(name = "pass")
public class Request {

	    protected String inputXml;
	    protected String pan;
	    protected String userName;
	    protected String posCode;
	    protected String password;
	    protected String passKey;
		public String getInputXml() {
			return inputXml;
		}
		public void setInputXml(String inputXml) {
			this.inputXml = inputXml;
		}
		public String getPan() {
			return pan;
		}
		public void setPan(String pan) {
			this.pan = pan;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getPosCode() {
			return posCode;
		}
		public void setPosCode(String posCode) {
			this.posCode = posCode;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getPassKey() {
			return passKey;
		}
		public void setPassKey(String passKey) {
			this.passKey = passKey;
		}
	    
	    
}
