package com.ndml.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.net.ssl.TrustManager;
import javax.xml.soap.MimeHeaders;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.core.SoapActionCallback;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.ws.transport.http.HttpsUrlConnectionMessageSender;
import org.springframework.xml.transform.StringSource;

import com.ndml.config.UnTrustworthyTrustManager;
import com.ndml.insta.EiaRequest;
import com.ndml.insta.EiaResponse;
import com.ndml.insta.InstaDataExchangeDetailsResponse;
import com.ndml.insta.InstaDataExchangeRequest;
import com.ndml.insta.SecuredWebServiceHeader;
import com.ndml.insta.Repository.UtilDao;
import com.ndml.insta.Repository.WhtpMsgDtlsRepository1;
import com.ndml.insta.util.ModifyXMLFile;

@Service
public class SoapClient extends WebServiceGatewaySupport {

	@Autowired
	private Jaxb2Marshaller marshaller;

	private WebServiceTemplate webServiceTemplate;

	@Value("${soap.endpointb.url}")
	private String endpointUri;
	
	@Value("${life.file}")
	private String lifefile;

	@Autowired
	WhtpMsgDtlsRepository1 whtpMsgDtlsRepository1;

	public List<InstaDataExchangeDetailsResponse> saveInstaPolicy(InstaDataExchangeRequest instaDataExchangeRequest)
			throws IOException {

		List<InstaDataExchangeDetailsResponse> list = new ArrayList<InstaDataExchangeDetailsResponse>();

		String zipFileName = "nir_dev_life_policy_file.zip"; // common file to edit
		List<Object[]> findBatchListEIA = whtpMsgDtlsRepository1.findBatchListEIA(); // get list of eia and acc id from db
		for (Object[] objects : findBatchListEIA) {
			InstaDataExchangeDetailsResponse instaDataExchangeDetailsResponse = new InstaDataExchangeDetailsResponse();
			InstaDataExchangeRequest instaDataExchangeRequest1 = new InstaDataExchangeRequest();
			String EiaNumber = (String) objects[0];
			//String Trid = (String) objects[1];
			SimpleDateFormat YYYYMMDDHHMMSS_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");
			String Trid = YYYYMMDDHHMMSS_FORMAT.format(new Date())+EiaNumber;
			
			System.out.println(EiaNumber + " " + Trid);

			ModifyXMLFile modifyXMLFile = new ModifyXMLFile();
			String xmlfileEditAndGenerate = modifyXMLFile.xmlfileEditAndGenerate(EiaNumber,lifefile.toString()); // edit xml and xml add into zip
			
			File xmlFile = new File(xmlfileEditAndGenerate);
			Path xmlpath = xmlFile.toPath();
			try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFileName));
					FileInputStream fis = new FileInputStream(xmlpath.toFile());) {

				ZipEntry zipEntry = new ZipEntry(xmlpath.getFileName().toString());
				zos.putNextEntry(zipEntry);

				byte[] buffer = new byte[1024];
				int len;
				while ((len = fis.read(buffer)) > 0) {
					zos.write(buffer, 0, len);
				}
				zos.closeEntry();
			}

			File updatedxmlFile = new File(zipFileName);
			byte[] data = FileUtils.readFileToByteArray(updatedxmlFile);  // zip data converted into bytes

			instaDataExchangeRequest1.setFileContent(data);
			instaDataExchangeRequest1.setFileType("401");  //401 for life
			instaDataExchangeRequest1.setTRID(Trid);
			instaDataExchangeRequest1.setImageContent(new byte[0]);

			webServiceTemplate = new WebServiceTemplate(marshaller);
			HttpsUrlConnectionMessageSender sender = new HttpsUrlConnectionMessageSender();
			sender.setTrustManagers(new TrustManager[] { new UnTrustworthyTrustManager() });
			webServiceTemplate.setMessageSender(sender);

			instaDataExchangeDetailsResponse = (InstaDataExchangeDetailsResponse) webServiceTemplate
					.marshalSendAndReceive(endpointUri, instaDataExchangeRequest1, new SoapRequestHeaderModifier());
			list.add(instaDataExchangeDetailsResponse);
		}
		return list;
	}

	public EiaResponse getEia(EiaRequest request) {
		webServiceTemplate = new WebServiceTemplate(marshaller);
		HttpsUrlConnectionMessageSender sender = new HttpsUrlConnectionMessageSender();
		sender.setTrustManagers(new TrustManager[] { new UnTrustworthyTrustManager() });
		webServiceTemplate.setMessageSender(sender);
		return (EiaResponse) webServiceTemplate.marshalSendAndReceive(endpointUri, request,
				new SoapRequestHeaderModifier());

	}

}
