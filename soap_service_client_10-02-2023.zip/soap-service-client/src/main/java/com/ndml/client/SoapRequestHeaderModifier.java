package com.ndml.client;

import java.io.IOException;
import java.util.Base64;

import javax.xml.namespace.QName;
import javax.xml.soap.MimeHeaders;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;

import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.soap.SoapEnvelope;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.saaj.SaajSoapMessage;
import org.springframework.xml.transform.StringSource;

import com.ndml.insta.SecuredWebServiceHeader;

public class SoapRequestHeaderModifier implements WebServiceMessageCallback {

	@Override
	public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {

		try {
			// SoapMessage soapMessage = (SoapMessage)message;
			// SoapHeader header = soapMessage.getSoapHeader();
			SecuredWebServiceHeader SecuredWebServiceHeader = new SecuredWebServiceHeader();
			SecuredWebServiceHeader.setUsername("iTrex123==");
			SecuredWebServiceHeader.setPassword("bithrexdg==");
			SecuredWebServiceHeader.setAuthenticatedToken("?");

			try {
				SoapMessage soapMessage = (SoapMessage) message;
				SoapHeader header = soapMessage.getSoapHeader();
				StringSource headerSource = new StringSource(
						"<tem:SecuredWebServiceHeader xmlns:tem=\"http://tempuri.org\">\r\n " + "       <Username>"
								+ SecuredWebServiceHeader.getUsername() + "</Username>\r\n"
								+ "         <!--Optional:-->\r\n" + "         <Password>"
								+ SecuredWebServiceHeader.getPassword() + "</Password>\r\n"
								+ "         <!--Optional:-->\r\n"
								+ "         <AuthenticatedToken>?</AuthenticatedToken>\r\n"
								+ "      </tem:SecuredWebServiceHeader>\r\n" + "" + "");
				Transformer transformer = TransformerFactory.newInstance().newTransformer();
				transformer.transform(headerSource, header.getResult());
			} catch (Exception e) {
			}

		} catch (Exception e) {
			// exception handling
		}
	}

	public SoapRequestHeaderModifier() {
		super();
		// TODO Auto-generated constructor stub
	}

}
