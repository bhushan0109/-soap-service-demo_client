package com.ndml.insta.Repository;
import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "whtp_msg_dtls")
public class WhtpMsgDtls implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	/*@GeneratedValue(strategy=GenerationType.AUTO)*/
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="wmd_id")
	private long wmdId;

	@Column(name="wmd_wst_temp_id")
	private long wmdWstTempId;
	@Column(name="wmd_msg_id")
	private String wmdMsgId;
	@Column(name="wmd_cont")
	private String wmdCont;
	@Column(name="wmd_sent_to")
	private long wmdSentTo;
	@Column(name="wmd_sent_from")
	private long wmdSentFrom;
	@Column(name="wmd_sent_usr_id")
	private String wmdSentUsrId;
	@Column(name="wmd_sent_usr_typ")
	private String wmdSentUsrTyp;
	@Column(name="wmd_sent")
	private String wmdSent;
	@Column(name="wmd_del")
	private String wmdDel;
	@Column(name="wmd_seen")
	private String wmdSeen;
	@Column(name="wmd_del_datetime")
	private Timestamp wmdDelDatetime;
	@Column(name="wmd_seen_datetime")
	private Timestamp wmdSeenDatetime;
	@Column(name="wmd_grp_id")
	private long wmdGrpId;
	@Column(name="wmd_grp_name")
	private String wmdGrpName;
	@Column(name="wmb_res_id")
	private long wmbResId;
	@Column(name="wmb_res_name")
	private String wmbResName;
	@Column(name="wmb_res_desc")
	private String wmbResDesc;
	@Column(name="wmd_crt_date")
	private Timestamp wmdCrtDate;
	@Column(name="wmd_upd_date")
	private Timestamp wmdUpdDate;
	@Column(name="wmd_upd_by")
	private String wmdUpdBy;
	@Column(name="wmd_crt_by")
	private String wmdCrtBy;
	
	
	public long getWmdId() {
		return wmdId;
	}
	public void setWmdId(long wmdId) {
		this.wmdId = wmdId;
	}
	public long getWmdWstTempId() {
		return wmdWstTempId;
	}
	public void setWmdWstTempId(long wmdWstTempId) {
		this.wmdWstTempId = wmdWstTempId;
	}
	public String getWmdMsgId() {
		return wmdMsgId;
	}
	public void setWmdMsgId(String wmdMsgId) {
		this.wmdMsgId = wmdMsgId;
	}
	public String getWmdCont() {
		return wmdCont;
	}
	public void setWmdCont(String wmdCont) {
		this.wmdCont = wmdCont;
	}
	public long getWmdSentTo() {
		return wmdSentTo;
	}
	public void setWmdSentTo(long wmdSentTo) {
		this.wmdSentTo = wmdSentTo;
	}
	public long getWmdSentFrom() {
		return wmdSentFrom;
	}
	public void setWmdSentFrom(long wmdSentFrom) {
		this.wmdSentFrom = wmdSentFrom;
	}
	public String getWmdSentUsrId() {
		return wmdSentUsrId;
	}
	public void setWmdSentUsrId(String wmdSentUsrId) {
		this.wmdSentUsrId = wmdSentUsrId;
	}
	public String getWmdSentUsrTyp() {
		return wmdSentUsrTyp;
	}
	public void setWmdSentUsrTyp(String wmdSentUsrTyp) {
		this.wmdSentUsrTyp = wmdSentUsrTyp;
	}
	public String getWmdSent() {
		return wmdSent;
	}
	public void setWmdSent(String wmdSent) {
		this.wmdSent = wmdSent;
	}
	public String getWmdDel() {
		return wmdDel;
	}
	public void setWmdDel(String wmdDel) {
		this.wmdDel = wmdDel;
	}
	public String getWmdSeen() {
		return wmdSeen;
	}
	public void setWmdSeen(String wmdSeen) {
		this.wmdSeen = wmdSeen;
	}
	public Timestamp getWmdDelDatetime() {
		return wmdDelDatetime;
	}
	public void setWmdDelDatetime(Timestamp wmdDelDatetime) {
		this.wmdDelDatetime = wmdDelDatetime;
	}
	public Timestamp getWmdSeenDatetime() {
		return wmdSeenDatetime;
	}
	public void setWmdSeenDatetime(Timestamp wmdSeenDatetime) {
		this.wmdSeenDatetime = wmdSeenDatetime;
	}
	public long getWmdGrpId() {
		return wmdGrpId;
	}
	public void setWmdGrpId(long wmdGrpId) {
		this.wmdGrpId = wmdGrpId;
	}
	public String getWmdGrpName() {
		return wmdGrpName;
	}
	public void setWmdGrpName(String wmdGrpName) {
		this.wmdGrpName = wmdGrpName;
	}
	public long getWmbResId() {
		return wmbResId;
	}
	public void setWmbResId(long wmbResId) {
		this.wmbResId = wmbResId;
	}
	public String getWmbResName() {
		return wmbResName;
	}
	public void setWmbResName(String wmbResName) {
		this.wmbResName = wmbResName;
	}
	public String getWmbResDesc() {
		return wmbResDesc;
	}
	public void setWmbResDesc(String wmbResDesc) {
		this.wmbResDesc = wmbResDesc;
	}
	public Timestamp getWmdCrtDate() {
		return wmdCrtDate;
	}
	public void setWmdCrtDate(Timestamp wmdCrtDate) {
		this.wmdCrtDate = wmdCrtDate;
	}
	public Timestamp getWmdUpdDate() {
		return wmdUpdDate;
	}
	public void setWmdUpdDate(Timestamp wmdUpdDate) {
		this.wmdUpdDate = wmdUpdDate;
	}
	public String getWmdUpdBy() {
		return wmdUpdBy;
	}
	public void setWmdUpdBy(String wmdUpdBy) {
		this.wmdUpdBy = wmdUpdBy;
	}
	public String getWmdCrtBy() {
		return wmdCrtBy;
	}
	public void setWmdCrtBy(String wmdCrtBy) {
		this.wmdCrtBy = wmdCrtBy;
	}
	public WhtpMsgDtls() {
		super();
		// TODO Auto-generated constructor stub
	}
	public WhtpMsgDtls(long wmdId, long wmdWstTempId, String wmdMsgId, String wmdCont, long wmdSentTo, long wmdSentFrom,
			String wmdSentUsrId, String wmdSentUsrTyp, String wmdSent, String wmdDel, String wmdSeen,
			Timestamp wmdDelDatetime, Timestamp wmdSeenDatetime, long wmdGrpId, String wmdGrpName, long wmbResId,
			String wmbResName, String wmbResDesc, Timestamp wmdCrtDate, Timestamp wmdUpdDate, String wmdUpdBy,
			String wmdCrtBy) {
		super();
		this.wmdId = wmdId;
		this.wmdWstTempId = wmdWstTempId;
		this.wmdMsgId = wmdMsgId;
		this.wmdCont = wmdCont;
		this.wmdSentTo = wmdSentTo;
		this.wmdSentFrom = wmdSentFrom;
		this.wmdSentUsrId = wmdSentUsrId;
		this.wmdSentUsrTyp = wmdSentUsrTyp;
		this.wmdSent = wmdSent;
		this.wmdDel = wmdDel;
		this.wmdSeen = wmdSeen;
		this.wmdDelDatetime = wmdDelDatetime;
		this.wmdSeenDatetime = wmdSeenDatetime;
		this.wmdGrpId = wmdGrpId;
		this.wmdGrpName = wmdGrpName;
		this.wmbResId = wmbResId;
		this.wmbResName = wmbResName;
		this.wmbResDesc = wmbResDesc;
		this.wmdCrtDate = wmdCrtDate;
		this.wmdUpdDate = wmdUpdDate;
		this.wmdUpdBy = wmdUpdBy;
		this.wmdCrtBy = wmdCrtBy;
	}
	@Override
	public String toString() {
		return "WhtpMsgDtls [wmdId=" + wmdId + ", wmdWstTempId=" + wmdWstTempId + ", wmdMsgId=" + wmdMsgId
				+ ", wmdCont=" + wmdCont + ", wmdSentTo=" + wmdSentTo + ", wmdSentFrom=" + wmdSentFrom
				+ ", wmdSentUsrId=" + wmdSentUsrId + ", wmdSentUsrTyp=" + wmdSentUsrTyp + ", wmdSent=" + wmdSent
				+ ", wmdDel=" + wmdDel + ", wmdSeen=" + wmdSeen + ", wmdDelDatetime=" + wmdDelDatetime
				+ ", wmdSeenDatetime=" + wmdSeenDatetime + ", wmdGrpId=" + wmdGrpId + ", wmdGrpName=" + wmdGrpName
				+ ", wmbResId=" + wmbResId + ", wmbResName=" + wmbResName + ", wmbResDesc=" + wmbResDesc
				+ ", wmdCrtDate=" + wmdCrtDate + ", wmdUpdDate=" + wmdUpdDate + ", wmdUpdBy=" + wmdUpdBy + ", wmdCrtBy="
				+ wmdCrtBy + "]";
	}
	
	
}
