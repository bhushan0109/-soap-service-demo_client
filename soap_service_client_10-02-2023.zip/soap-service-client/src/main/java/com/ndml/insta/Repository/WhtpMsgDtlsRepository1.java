package com.ndml.insta.Repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public interface WhtpMsgDtlsRepository1 extends JpaRepository<WhtpMsgDtls,Long>{

	@Query(value = "SELECT c.CEA_EIA_ACCT_ID,c.CEA_ACK_ID FROM NIR.CRIP_EIA_ACCT c \r\n" + 
			"		  ORDER BY c.CEA_CRT_DATE desc limit 100", nativeQuery = true)
	public List<Object[]> findBatchListEIA(); 
	
}
