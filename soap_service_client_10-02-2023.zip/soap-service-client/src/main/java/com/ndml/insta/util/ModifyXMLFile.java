package com.ndml.insta.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ModifyXMLFile {

	public String xmlfileEditAndGenerate(String eiaNumber, String lifefile) {
		String filePath = lifefile;
		
		System.out.println("lifefile name "+lifefile );
		String writeXMLFile = null;
		File xmlFile = new File(filePath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();

			// parse xml file and load into document
			Document xmlDoc = dBuilder.parse(xmlFile);

			xmlDoc.getDocumentElement().normalize();
			updateElementValue(xmlDoc, eiaNumber);
			writeXMLFile = writeXMLFile(xmlDoc, eiaNumber);
			// update Element value
			// // delete element
			// deleteElement(xmlDoc);
			//
			// // add new element
			// addElement(xmlDoc);

			// write the updated xmlDocument to file or console

		} catch (SAXException | ParserConfigurationException | IOException | TransformerException e1) {
			e1.printStackTrace();
		}
		return writeXMLFile;
	}

	public void addElement(Document xmlDoc) {
		NodeList users = xmlDoc.getElementsByTagName("User");
		Element emp = null;

		// loop for each user
		for (int i = 0; i < users.getLength(); i++) {
			emp = (Element) users.item(i);
			Element salaryElement = xmlDoc.createElement("salary");
			salaryElement.appendChild(xmlDoc.createTextNode("10000"));
			emp.appendChild(salaryElement);
		}
	}

	public void deleteElement(Document xmlDoc) {
		NodeList users = xmlDoc.getElementsByTagName("User");
		Element user = null;
		// loop for each user
		for (int i = 0; i < users.getLength(); i++) {
			user = (Element) users.item(i);
			Node genderNode = user.getElementsByTagName("gender").item(0);
			user.removeChild(genderNode);
		}

	}

	public void updateElementValue(Document doc, String EiaNumber) {
		NodeList users = doc.getElementsByTagName("Policy_Detail");
		Element user = null;
		// loop for each user
		for (int i = 0; i < users.getLength(); i++) {
			user = (Element) users.item(i);
			Node name = user.getElementsByTagName("eIA_Accnt_Number").item(0).getFirstChild();
			// name.setNodeValue(name.getNodeValue().toUpperCase());
			name.setNodeValue(EiaNumber);
		}

		for (int i = 0; i < users.getLength(); i++) {
			user = (Element) users.item(i);
			NodeList PolicyParticularBeanChildNode = user.getElementsByTagName("Policy_Particular").item(0)
					.getChildNodes();

			Element user1 = null;
			// loop for each user
			for (int j = 0; j < PolicyParticularBeanChildNode.getLength(); j++) {

				if (PolicyParticularBeanChildNode.getLength() > 0) {

						if (!PolicyParticularBeanChildNode.item(j).getNodeName().equalsIgnoreCase("#text")) {
							if (PolicyParticularBeanChildNode.item(j).getNodeName().equalsIgnoreCase("Policy_Number")) {
								SimpleDateFormat YYYYMMDDHHMMSS_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");
								String dateformate = YYYYMMDDHHMMSS_FORMAT.format(new Date());
								PolicyParticularBeanChildNode.item(j).setTextContent(EiaNumber+dateformate);
							}

							// user1 = (Element) users1.item(j);
							// Node name1 =
							// user1.getElementsByTagName("Policy_Number").item(0).getFirstChild();
							// // name.setNodeValue(name.getNodeValue().toUpperCase());
							// name1.setNodeValue(EiaNumber);
						}
					
				}
			}
		}
	}

	public String writeXMLFile(Document xmlDoc, String EiaNumber)
			throws TransformerFactoryConfigurationError, TransformerConfigurationException, TransformerException {
		// long currentTimeMillis = System.currentTimeMillis();

		SimpleDateFormat YYYYMMDDHHMMSS_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");
		String dateformate = YYYYMMDDHHMMSS_FORMAT.format(new Date());

		String updatedFileName = EiaNumber + "_" + dateformate + "+life_p.xml";
		xmlDoc.getDocumentElement().normalize();
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(xmlDoc);
		StreamResult result = new StreamResult(new File(updatedFileName));
		transformer.setOutputProperty(OutputKeys.VERSION, "yes");
		transformer.transform(source, result);
		System.out.println("XML file updated successfully");
		return updatedFileName;
	}
}