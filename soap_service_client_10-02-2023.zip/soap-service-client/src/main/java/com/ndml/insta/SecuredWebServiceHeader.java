package com.ndml.insta;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "Username", "Password", "AuthenticatedToken" })
@XmlRootElement(name = "SecuredWebServiceHeader")
public class SecuredWebServiceHeader {

	@XmlElement(name = "Username", required = true)
	protected String Username;

	@XmlElement(name = "Password", required = true)
	protected String Password;

	@XmlElement(name = "AuthenticatedToken", required = true)
	protected String AuthenticatedToken;


	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getAuthenticatedToken() {
		return AuthenticatedToken;
	}

	public void setAuthenticatedToken(String authenticatedToken) {
		AuthenticatedToken = authenticatedToken;
	}

	@Override
	public String toString() {
		return "SecuredWebServiceHeader [Username=" + Username + ", Password=" + Password + ", AuthenticatedToken="
				+ AuthenticatedToken + "]";
	}

}
