package com.ndml.insta.Repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UtilDao {
	
	@Autowired
	WhtpMsgDtlsRepository1 whtpMsgDtlsRepository1;
	
//	public List<String> getEIAlist() {
//		Query query = null;
//		List<String> eiaList = null;
//		Session session = sessionFactory.getCurrentSession();
//		Transaction tx = session.beginTransaction();
//		
//		query = session.createQuery("select ceaEiaAcctId from CripEiaAcct DESC LIMIT 15 ");
//		eiaList = query.list();
//		tx.commit();
//		return eiaList;
//	}
	
//	  @PersistenceContext
//	  private EntityManager entityManager;
	
//	public List<Object[]>  findBatchListEIA() {
//		
//		List<Object[]> list = userRepository.findBatchListEIA();
//		System.out.println(list);
//		return list;
//		
//	}
	
public List<Object[]>  findBatchListEIA() {
		
		whtpMsgDtlsRepository1.count();
		//System.out.println(list);
		return null;
		
	}

}
