package com.ndml.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.client.SoapClient;
import com.ndml.insta.EiaRequest;
import com.ndml.insta.EiaResponse;
import com.ndml.insta.InstaDataExchangeDetailsResponse;
import com.ndml.insta.InstaDataExchangeRequest;
import com.ndml.insta.Repository.WhtpMsgDtlsRepository1;

@RestController
public class SoapController {

	@Autowired
	private SoapClient client;

	@Autowired
	WhtpMsgDtlsRepository1 whtpMsgDtlsRepository1;

	@GetMapping("/")
	public String greeting() {
		return "soap client is Running.........";

	}

	@PostMapping("insta/policy")
	public List<InstaDataExchangeDetailsResponse> saveInstaPolicy(
			@RequestBody InstaDataExchangeRequest instaDataExchangeRequest) throws IOException {
		return client.saveInstaPolicy(instaDataExchangeRequest);
	}
	
	@PostMapping("insta/policy1")
	public List<InstaDataExchangeDetailsResponse> saveInstaPolicy1(
			@RequestBody InstaDataExchangeRequest instaDataExchangeRequest) throws IOException {
		return client.saveInstaPolicy(instaDataExchangeRequest);
	}
	
	@PostMapping("insta/policy2")
	public List<InstaDataExchangeDetailsResponse> saveInstaPolicy2(
			@RequestBody InstaDataExchangeRequest instaDataExchangeRequest) throws IOException {
		return client.saveInstaPolicy(instaDataExchangeRequest);
	}


	@PostMapping("/insta/eia")
	public EiaResponse getEia(@RequestBody EiaRequest request) {

		return client.getEia(request);
	}

}
