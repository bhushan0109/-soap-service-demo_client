package com.nsdl.soapdemo.endpoint;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.springframework.ws.soap.SoapBody;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.nsdl.soapdemo.api.add.AddRequest;
import com.nsdl.soapdemo.api.add.Result;
import com.nsdl.soapdemo.api.geteia.EiaRequest;
import com.nsdl.soapdemo.api.geteia.EiaResponse;
import com.nsdl.soapdemo.api.loaneligibility.Acknowledgement;
import com.nsdl.soapdemo.api.loaneligibility.CustomerRequest;
import com.nsdl.soapdemo.eiaxml.dto.SecuredWebServiceHeader;
import com.nsdl.soapdemo.service.LoanEligibilityService;


@Endpoint
public class LoanEligibilityindicatorEndpoint {
	private static final String NAMESPACE_ADD = "http://www.nsdl.com/soapdemo/api/add";
	private static final String NAMESPACE = "http://www.nsdl.com/soapdemo/api/loanEligibility";
	private static final String NAMESPACE_GET_EIA = "http://www.nsdl.com/soapdemo/api/getEIA";

	// ----------------------------- this above url in xsd file copy that one first
	// paste above
	@Autowired
	private LoanEligibilityService service;


	// http://localhost:8080/ws/getEIA.wsdl
	// url-servlet path-bean name .wsdl
	@PayloadRoot(namespace = NAMESPACE_GET_EIA, localPart = "EiaRequest")
	// ---------------------------------------------- above local part is customer
	// request
	@ResponsePayload
	public EiaResponse getEIA(MessageContext messageContext) throws IOException, JAXBException, TransformerException {

		SoapMessage message = (SoapMessage) messageContext.getRequest();
		SoapHeader soapHeader = message.getSoapHeader();
		SoapBody soapBody = message.getSoapBody();
		Source bodySource = soapBody.getPayloadSource();
		DOMSource bodyDomSource = (DOMSource) bodySource;
		// =============================================================
		
		// now xml body object convert to java object using Unmarshaller
		JAXBContext context = JAXBContext.newInstance(EiaRequest.class);
		Unmarshaller unmarshaller = context.createUnmarshaller();

		EiaRequest eiaRequest = (EiaRequest) unmarshaller.unmarshal(bodyDomSource);
		System.out.println(eiaRequest);
		// =============================================================

		Map<String, String> extractUserDefinedHeaders = extractUserDefinedHeaders(soapHeader);
		System.out.println("extractUserDefinedHeaders" + extractUserDefinedHeaders);
		SecuredWebServiceHeader securedWebServiceHeader =new SecuredWebServiceHeader();
		String userID = extractUserDefinedHeaders.get("UserID");
		securedWebServiceHeader.setUserID(userID);
		String password = extractUserDefinedHeaders.get("Password");
		securedWebServiceHeader.setPassword(password);
		String AuthenticatedToken = extractUserDefinedHeaders.get("AuthenticatedToken");
		securedWebServiceHeader.setAuthenticatedToken(AuthenticatedToken);
		System.out.println("securedWebServiceHeader "+securedWebServiceHeader);
		return service.getEia(eiaRequest,securedWebServiceHeader);
	}

	public Map<String, String> extractUserDefinedHeaders(SoapHeader soapHeader) {
		Map<String, String> headers = new HashMap<String, String>();

		Iterator<?> elementIter = soapHeader.examineAllHeaderElements();
		while (elementIter.hasNext()) {
			Object element = elementIter.next();
			if (!(element instanceof SoapHeaderElement)) {
				continue;
			}
			javax.xml.transform.Result result = ((SoapHeaderElement) element).getResult();
			// Result result = ((SoapHeaderElement) element).getResult();
			if (!(result instanceof DOMResult)) {
				continue;
			}

			NodeList nodeList = ((DOMResult) result).getNode().getChildNodes();
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				if (node.hasChildNodes()) {
					String nodeName = node.getNodeName();
					String nodeValue = node.getFirstChild().getNodeValue();
					headers.put(nodeName, nodeValue);
					System.out.println(nodeName + ", " + nodeValue);
				}
			}
		}
		return headers;

	}
	
	// http://localhost:8080/ws/loanEligibility.wsdl
	// part > url-servlet path-bean name .wsdl
	@PayloadRoot(namespace = NAMESPACE, localPart = "CustomerRequest")
	// ---------------------------------------------- above local part is customer
	// request
	@ResponsePayload
	public Acknowledgement getLoanStatus(@RequestPayload CustomerRequest request) {
		System.out.println();
		return service.checkLoanEligibility(request);
	}

	// http://localhost:8080/ws/addition.wsdl
	// url-servlet path-bean name .wsdl
	@PayloadRoot(namespace = NAMESPACE_ADD, localPart = "AddRequest")
	// ---------------------------------------------- above local part is customer
	// request
	@ResponsePayload
	public Result getLoanStatus(@RequestPayload AddRequest request) {
		return service.addition(request);
	}

}