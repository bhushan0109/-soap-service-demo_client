package com.nsdl.soapdemo.eiaxml.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "SecuredWebServiceHeader")
public class SecuredWebServiceHeader {

	@XmlElement(required = true)
	protected String UserID;

	@XmlElement(required = true)
	protected String Password;
	@XmlElement(required = true)
	protected String AuthenticatedToken;

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getAuthenticatedToken() {
		return AuthenticatedToken;
	}

	public void setAuthenticatedToken(String authenticatedToken) {
		AuthenticatedToken = authenticatedToken;
	}

	@Override
	public String toString() {
		return "SecuredWebServiceHeader [UserID=" + UserID + ", Password=" + Password + ", AuthenticatedToken="
				+ AuthenticatedToken + "]";
	}

}
