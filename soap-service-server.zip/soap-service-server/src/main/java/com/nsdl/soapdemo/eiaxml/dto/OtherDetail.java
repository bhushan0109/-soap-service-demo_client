package com.nsdl.soapdemo.eiaxml.dto;

public class OtherDetail {
	private Integer dOBProof;
	private Integer iDProof;
	private Integer addressProof;
	private Integer correspondenceAddressProof;

	public Integer getdOBProof() {
		return dOBProof;
	}

	public void setdOBProof(Integer dOBProof) {
		this.dOBProof = dOBProof;
	}

	public Integer getiDProof() {
		return iDProof;
	}

	public void setiDProof(Integer iDProof) {
		this.iDProof = iDProof;
	}

	public Integer getAddressProof() {
		return addressProof;
	}

	public void setAddressProof(Integer addressProof) {
		this.addressProof = addressProof;
	}

	public Integer getCorrespondenceAddressProof() {
		return correspondenceAddressProof;
	}

	public void setCorrespondenceAddressProof(Integer correspondenceAddressProof) {
		this.correspondenceAddressProof = correspondenceAddressProof;
	}

	@Override
	public String toString() {
		return "OtherDetail [dOBProof=" + dOBProof + ", iDProof=" + iDProof + ", addressProof=" + addressProof
				+ ", correspondenceAddressProof=" + correspondenceAddressProof + "]";
	}

}
