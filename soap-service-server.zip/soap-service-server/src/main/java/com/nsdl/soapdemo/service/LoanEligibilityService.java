package com.nsdl.soapdemo.service;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.nsdl.soapdemo.api.add.AddRequest;
import com.nsdl.soapdemo.api.add.Result;
import com.nsdl.soapdemo.api.geteia.EiaRequest;
import com.nsdl.soapdemo.api.geteia.EiaResponse;
import com.nsdl.soapdemo.api.loaneligibility.Acknowledgement;
import com.nsdl.soapdemo.api.loaneligibility.CustomerRequest;
import com.nsdl.soapdemo.eiaxml.dto.SecuredWebServiceHeader;
//import com.nsdl.soapdemo.eiaxml.dto.Item;
//import com.nsdl.soapdemo.eiaxml.dto.StaXParser;


@Service
public class LoanEligibilityService {

	@Value("${file.path.eia.zip}")
	private  String filePath;

	public Acknowledgement checkLoanEligibility(CustomerRequest request) {
		Acknowledgement acknowledgement = new Acknowledgement();
		List<String> mismatchCriteriaList = acknowledgement.getCriteriaMismatch();

		if (!(request.getAge() > 30 && request.getAge() <= 60)) {
			mismatchCriteriaList.add("Person age should in between 30 to 60");
		}
		if (!(request.getYearlyIncome() > 200000)) {
			mismatchCriteriaList.add("minimum income should be more than 200000");
		}
		if (!(request.getCibilScore() > 500)) {
			mismatchCriteriaList.add("Low CIBIL Score please try after 6 month");
		}

		if (mismatchCriteriaList.size() > 0) {
			acknowledgement.setApprovedAmount(0);
			acknowledgement.setIsEligible(false);
		} else {
			acknowledgement.setApprovedAmount(500000);
			acknowledgement.setIsEligible(true);
			mismatchCriteriaList.clear();
		}
		return acknowledgement;

	}

	public Result addition(AddRequest request) {
		Result result = new Result();
		int sum = 0;

		sum = request.getNum1() + request.getNum2();
		result.setResult(sum);
		return result;

	}

	public EiaResponse getEia(EiaRequest request, SecuredWebServiceHeader securedWebServiceHeader) throws IOException {
		EiaResponse eiaResponse = new EiaResponse();
		String soapEncodingString = request.getSoapEncodingString();
		byte[] zipData = Base64.decodeBase64(soapEncodingString);
		String value = extractZipEntries(zipData);
		System.out.println(value);

		eiaResponse.setResponse("");
		return eiaResponse;
	}

//	public static void main(String[] args) throws IOException {
//		/// old String soapEncodingString = "UEsDBBQAAAAIAHVxM1UwkYB3sQMAAIANAAAHAAAAeG1sLnhtbO1XXW+jOBR9X2n/A8r7xiEkaSu5nnFI06AkgEgymu4LosFtUMFmDRlN9tevTRLAgbSjVR+HJ99zjj/u5fpegF9+JrH2g/AsYvS+o3d7HY3QLQsj+nrf2aynf912vqA//4DEwj7ebv0JyYMoziQ0jWLiz0gQEl6aUYgGEJyHEuUsAXIwCXLiOy/+I6GEB3nEKOr39KGuGz0IWkgxxd4nErzcWofgCgPBxZlc4Rijhe6oEaAmHmiF4DwUZOWUVjxQLGqKI70yfpDb1c1Ssz6kxHkRlFRURrVGmtoMDXq9wWDUN/Q7CI5IKbBotucB3RLfTFJ68M0Q6SIWLXA55Rwnj2xJlOYtETwzJ+dAwzt5rjjaBjRXQyIYm8kVSl76dQmV2hLS7CAh950Vi4mIPs9yzeUsZRnhnVKtabCgfKlFYzx+gKAG1GTLKAxjUsCgji+Cs3gVJAEElV3fI8h3hPuzffYc0LC5iMgumRdLCE6jGjdxxki/u9XF04dAWjXSxTbCK+zO9Zu7/hwCadfojTVR9sFhyEmWyciIyIgcTAJKaF6Px1G1iCjRkW15+BtezzYu9vDStRYQlFzbjD6aOwtsW5qrOaW03yo10LcH+xEvFo7jlVJDlS5krJYBfwMqbkb5Aa1nzmTjbv6eYQgKQJGscpF1yBABO47U+WxPc36Q9eA8VHjXsn2ThQSNboej3i0EJVALJTjF8np4TcaFlTLxQsWd+R3jz4mxyZJkT6NtUYsvC0WhWJOYpDtGxWXdJ8+EX3iG49z/QLJkzycCDW9GI73XvxkNIajBinyKv18s4PIoCfjBJ4k8HSW74M34SrMw7m5ZN6IQqILL8xFOZdEsSOX+gne9h6ClHI4D+uarhbbCizpljCCorJrEKYpWSSknGctGsEOP2qPmOXgCwQmoSYqMmTvmzGpkz3F30ZRkapShHhhDYzAcGhC00ddmywYnG0ITvJyxtEyvyDHQoKzpyjymnzWeL3ry0QcQXHB152QfjGMS+uaO/LMn6ABBA6teTOtbgHif7xiP/hUzPJKKTBe1WLzZH8pOtXa02nhP+H83qJaOo0CitSi26CXgE5vJavrkrZ/Wn1Xefpe3D2vX3S/ULo/ExVbZLkrRDQSKfVXpF6Xh3aJnP8zw/Ku9miy6ptO17Os174Oq1gjKNA5e0RMELWh14T6+Wqfy1tzNmvjiQ5G9yKJSjpt5fyKG5WtsKtUvAL8x8V1evZnVkSqj8rbFlVozqBMQtP55FJ/jyh/Lf1BLAQIfABQAAAAIAHVxM1UwkYB3sQMAAIANAAAHACQAAAAAAAAAIAAAAAAAAAB4bWwueG1sCgAgAAAAAAABABgAACc/pAPM2AEAJz+kA8zYAQAnP6QDzNgBUEsFBgAAAAABAAEAWQAAANYDAAAAAA==";
//		String soapEncodingString ="UEsDBBQAAAAIAMuah00wkYB3qgMAAIANAAAHAAAAeG1sLnhtbO1XXZOaMBR970z/g+N7jYi6uzNp2oh1ZVRgUDvdvjCsZFdmIaEBO7W/vgki4UPbTqd9K0+555ybj8vNvQDffYujzlfC05DRt12t1+92CN2xIKTPb7vbzezNbfcdev0KEhN7eLfzpiTzwyiV0CyMiDcnfkB4aYYBGkJQDHOUsxjIwdTPiGc/efeEEu5nYjk06GsjTdP7ELRJ6WIdYgk2l9YguMIUK6s9OeJgjEpdoRFgRzzQDMB5KMjCP0dyTExqiC09M36Uy1VMpdkcE2I/CUoqlKHmSBKLoWG/PxyOB7p2J6aRiBKYND1wn+6IZ8QJPXpGgDQRizZcupRBdMmOhEnWjKBizocDtdOd9xWFO59m1ZDkjMXkDCUvz9WAlLaEOpYfk7fdNYuIiD5Ps47DWcJSwru5utDnlCe1aIInHyBQQFW2CoMgIjkMqvjSP4vXfuxDUNq1NfxsT7g3P6SPPg3ak4jsknmxguA0qnJTe4K0u1tNPAMIhFUlHWwhvMbOQru5GywgEHaV3prT2jo4CDhJ0yIyIgdjnxKaneOhVMuQEg1Zpos/4s1862AXrxxzCcGZu+gxQAt7iS2z43TsUjq4KNXRxw/WPV4ubdstpXpdupSxWvn8BdRxI8yOaDO3p1tn+3mOIZBAXbLORNYhXQQsHzX82YFm/CjrQTGs845peQYLCBrfjsb9WwgKoPZKQRHL6+E1GBdWwsQLFXfmf4z/TowNFscHGu7yWlwvFOfyRyKS7BkVl/UQPxLeOBmOMu8XkhV7LAg0uhmPtf7gZjyCQMF1+Qx/akzg8DD2+dEjsdwdJXv/RX9P0yDq7VgvpBDUBK39EU5FQE8kqAXkyunP9IVyOPHpi1crtAo/1Sl9DEFpVSV2XrRKCtTcZSPYo/vOfce18VTMkAOFRKXQwjbm5il7mqvLBilTowz1UB/pw9FIF5O16avessHJhtACWx4r03DzHAMtypytjVP6mZPFsi8fTaRunasdTvbBKCKBZ+zJlwNBRwgamNIXE7Wb+SHbMx5+Fx4uSUSmi1os3uxXcqU/rbfuA/7jBnWh44BGowGN3gL+YjNZzx7czcPmf3n7t+WtUqTufqN2uSTKl0r3YYJuIKja15VeXhp+WvSsD3O8eG+tp8ueYfdMq1Hzfr+qtYIyi/xn9KC8FFq5cL++WkV5a69mTj3xocieZFEpx+28L4hR+RrbyvoXgNdy/BnfuJlqS8pQp20cpdEMFCHhS38eAm7+sfwAUEsBAj8AFAAAAAgAy5qHTTCRgHeqAwAAgA0AAAcAJAAAAAAAAAAgAAAAAAAAAHhtbC54bWwKACAAAAAAAAEAGACy48YSNI7UAcLxZVYzjtQBwvFlVjOO1AFQSwUGAAAAAAEAAQBZAAAAzwMAAAAA";
//		byte[] zipData = Base64.decodeBase64(soapEncodingString);
//		String value = extractZipEntries(zipData);
//		System.out.println(value);
//	}

	public  String extractZipEntries(byte[] bytes) throws IOException {

		ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(bytes));
		ZipEntry entry = null;
		while ((entry = zipStream.getNextEntry()) != null) {
			Date date = new Date();  
		    SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy");  
		    String strDate= formatter.format(date);  
			String entryName = entry.getName();

			File file = new File(filePath+strDate+"/" + System.currentTimeMillis()+entryName);  //  //server path
//			File file = new File("/eIAxmlsFiles/"+strDate+"/" + System.currentTimeMillis()+entryName);  // local host path
			// Will create parent directories if not exists
			boolean bool = file.getParentFile().mkdirs();
			if (bool ) {
				file.createNewFile();

			} else {
				file.createNewFile();
			}
			FileOutputStream out = new FileOutputStream(file, false);

			byte[] byteBuff = new byte[4096];
			int bytesRead = 0;
			while ((bytesRead = zipStream.read(byteBuff)) != -1) {
				out.write(byteBuff, 0, bytesRead);
			}
			out.close();
			zipStream.closeEntry();
		}
		zipStream.close();
		return "success";
	}

	// public static ZipEntry extractZipEntries(byte[] bytes) throws IOException {
	//
	// ZipInputStream zipStream = new ZipInputStream(new
	// ByteArrayInputStream(bytes));
	// ZipEntry entry = null;
	// while ((entry = zipStream.getNextEntry()) != null) {
	//
	// String entryName = entry.getName();
	//
	// FileOutputStream out = new FileOutputStream(entryName);
	//
	// byte[] byteBuff = new byte[4096];
	// int bytesRead = 0;
	// while ((bytesRead = zipStream.read(byteBuff)) != -1) {
	// out.write(byteBuff, 0, bytesRead);
	//
	// }
	//
	// out.close();
	// zipStream.closeEntry();
	// }
	// zipStream.close();
	// return entry;
	// }
	
//	public static void main(String[] args) {
//		  StaXParser read = new StaXParser();
//	        List<Item> readConfig = read.readConfig("D:\\config2.xml");
//	        for (Item item : readConfig) {
//	            System.out.println(item);
//	        }
//	}
}
