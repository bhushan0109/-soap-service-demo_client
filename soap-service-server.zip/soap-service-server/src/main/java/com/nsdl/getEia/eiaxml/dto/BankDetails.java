package com.nsdl.getEia.eiaxml.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BankDetails {
	private Integer bankAccountNumber;
    private Integer bankName;
    private String branch;
    private String bankIFSCCode;
    private String cancelledCheque;
    private String otherBankName;
    private Integer bankAccountType;
    private String city;
    private String bankMICRCode;
}
