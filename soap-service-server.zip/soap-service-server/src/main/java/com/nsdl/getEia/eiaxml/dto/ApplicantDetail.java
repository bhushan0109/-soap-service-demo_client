package com.nsdl.getEia.eiaxml.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Data
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApplicantDetail {
	 private BankDetails bankDetails;
	    private AuthorizedRepresentative authorizedRepresentative;
	    private Integer noOfApplicant;
	    private Applicant applicant;
	    private OtherDetail otherDetail;
}
