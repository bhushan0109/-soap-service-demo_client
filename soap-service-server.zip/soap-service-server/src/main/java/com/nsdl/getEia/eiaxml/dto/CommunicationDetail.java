package com.nsdl.getEia.eiaxml.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CommunicationDetail {

	private String telephoneNumber;
	private Integer relationship;
	private String relationshipOther;
	private String primaryEmail;
	private Integer mobNumber;

}
