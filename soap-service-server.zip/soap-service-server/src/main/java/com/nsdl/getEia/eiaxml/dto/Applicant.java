package com.nsdl.getEia.eiaxml.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Data
@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Applicant {
	
	private String firstName;
    private String middleName;
    private String uID;
    private List<Address_> address = new ArrayList<Address_>();
    private CommunicationDetail_ communicationDetail;
    private String lastName;
    private Integer dOB;
    private String gender;
    private String pAN;
    private String fatherHusbandName;
    private String name;

}
