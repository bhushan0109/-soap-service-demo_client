# spring-boot-soap-ws-consumer
How to Consume Soap Webservices using WebServiceTemplate and Spring Boot 

19-09-2022

add required dependency

<version>2.0.1.RELEASE</version>

dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-web-services</artifactId>
	<version>2.2.0.RELEASE</version>
</dependency>

add plugin

<build>
		<plugins>
			<plugin>
				<groupId>org.springframework.boot</groupId>
				<artifactId>spring-boot-maven-plugin</artifactId>
			</plugin>
			<plugin>
				<groupId>org.jvnet.jaxb2.maven2</groupId>
				<artifactId>maven-jaxb2-plugin</artifactId>
				<version>0.13.2</version>
				<executions>
					<execution>
						<goals>
							<goal>generate</goal>
						</goals>
					</execution>
				</executions>
				<configuration>
					<generatePackage>com.javatechie.spring.soap.api.loaneligibility</generatePackage>
					<generateDirectory>${project.basedir}/src/main/java</generateDirectory>
					<schemaDirectory>${project.basedir}/src/main/resources/wsdl</schemaDirectory>
					<schemaIncludes>
						<include>*.wsdl</include>
					</schemaIncludes>
				</configuration>
			</plugin>
		</plugins>
	</build>
==============================================================================================
step
src/main/resources
create folder wsdl
in that folder create loanEligibility.wsdl
now paste that wsdl file data in .wsdl file
using server url hit on browser
http://localhost:8080/ws/loanEligibility.wsdl

after the generating the binding classes help of jaxb2 pluging
maven build
clean install
maven update

now we need marsheler
java object convert to xml

Jaxb2Marshaller marshaller

now we need client
@Autowired
	private Jaxb2Marshaller marshaller;    //it used for java object to xml

	private WebServiceTemplate template;  // call far extrnal url like rest template

	public Acknowledgement getLoanStatus(CustomerRequest request) {
		template = new WebServiceTemplate(marshaller);
		Acknowledgement acknowledgement = (Acknowledgement) template.marshalSendAndReceive("http://localhost:8080/ws",
				request);
		return acknowledgement;
	}
===============================================================
now controller to calling api


example request json amd xml
================================body========
.xml
<?xml version="1.0" encoding="UTF-8" ?>
<customerName>RAHUL</customerName>
<age>23</age>
<yearlyIncome>500000</yearlyIncome>
<cibilScore>720</cibilScore>
<employmentMode>GOVT</employmentMode>

=================================body==================
{
 "customerName":"bhushan",
    "age":"45",
    "yearlyIncome":"800000",
    "cibilScore":"800",
    "employmentMode":"govt"

}

