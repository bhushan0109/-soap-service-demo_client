package com.nsdl.soapdemo.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nsdl.soapdemo.api.client.SoapClinet;
import com.nsdl.soapdemo.api.loaneligibility.Acknowledgement;
import com.nsdl.soapdemo.api.loaneligibility.CustomerRequest;


@SpringBootApplication
@RestController
public class SoapControleer {
	
	@Autowired
	private SoapClinet clinet;
	
	//@PostMapping("/getLoanStatus")
	@RequestMapping(value = "/getLoanStatus", method = RequestMethod.POST,produces={"application/json","application/xml"},
    consumes={"application/json", "application/xml"})
	public Acknowledgement invokeSoapClientToGetLoanStatus(@RequestBody CustomerRequest request) {
		return clinet.getLoanStatus(request);
	}


}
